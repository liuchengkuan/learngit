import ElementBo from './ElementBo';
class TableEleBo extends ElementBo{
  tableRow=0; //表格组件的行数
  tableCol=0; //表格组件的列数
  tr=[];//表格中的数据
  col=null;
  isNewTable=true;//新建的表格
  isCreate=true;
}
export default TableEleBo;
