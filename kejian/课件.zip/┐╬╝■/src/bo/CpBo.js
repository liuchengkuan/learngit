/**
 * 课件定义对象
 * auto zz 
 */

class CpBo {
  id = null;
  name = null;
}

export default CpBo;
