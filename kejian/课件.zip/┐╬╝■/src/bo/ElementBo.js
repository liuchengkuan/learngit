/**
 * 编辑区元素的数据对象
 */

class ElementBo {
  id = null;
  type = null;
  x = null;
  y = null;
  width = null;
  height = null;
  rotate = 0; // 旋转角度 0-359 顺时针 number
  tw = null;  // 文本控件中，文本区域的宽度
  th = null;  // 文本控件中，文本区域的高度
  fill = '#50a0f9'; // 填充
  isSelected = false; //默认是未选中
  fontWeight = 'normal';
  stroke = '#000';
  strokeStyle = '';
  strokeWidth = 0; // 边框宽度 number
  strokeRadius = 0; // 圆角
  opacity = 1;
  tableRow=0; //表格组件的行数
  tableCol=0; //表格组件的列数
  tr=[];//表格中的数据
  col=null;
  isNewTable=true;//新建的表格
  isCreate=true;
  txtContent=null;//文本控件的内容
  txtIsblur=false;
}

export default ElementBo;
