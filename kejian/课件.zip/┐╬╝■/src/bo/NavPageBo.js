
/**
* 导航面板数据对象用来和后台、页面对象等交互
*/

class NavPageBo {
  id = '';
  seq = 0;
  className = '';
  url=null;
}

export default NavPageBo;



