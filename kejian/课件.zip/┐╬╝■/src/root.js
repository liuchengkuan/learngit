import { h, render, Component, cloneElement } from 'preact';
import MainView from './views/MainView';
import './styles/root.css';
import './root.html';

import Marquee from 'views/editAreaPage/Marquee';

setTimeout(function () {
  new Marquee();
}, 1);

render(<MainView />, document.body);