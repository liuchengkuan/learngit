import CpUtil from '../utils/CpUtil.js';
import RootStore from './RootStore';
import LayoutStore from './LayoutStore';
import NavPageBo from '../bo/NavPageBo';
const uuid = CpUtil.uuid;

let _navePageList = [];

// 确保传入参数是数字
let someToNumber = function(obj) {
  obj.x && (obj.x = parseInt(obj.x));
  obj.y && (obj.y = parseInt(obj.y));
};

// 获取位置
let findPointById = function(id) {
  for (var i in _navePageList) {
    var tempData = _navePageList[i];
    if (tempData.id == id) {
      return i;
    }
  }
  return 0;
};

let findNavePageData = function(id) {

  for (var i in _navePageList) {
    var tempData = _navePageList[i];
    if (tempData.id == id) {
      return tempData;
    }
  }
  return null;
};

/**
 *导航元素数据确定类
 *auto 庄召
 */
class NavPageStore extends RootStore {

  getState = function() {   
    return _navePageList;
  };
  refresh = function() {
    this.emit();
  };
  //添加一个导航面板
  addNavePage = function(newData) {
    // 生成组件对象
    // _navePageList[newData.id] = newData;
    _navePageList.push(newData);
    // 测试复制粘贴时用的区分数据
     /*var navPageBo = new NavPageBo();
      navPageBo.id = uuid();
      navPageBo.seq = 2,
      navPageBo.className = 'navPageSelected';
      navPageBo.url = 'images/icons.png';
      _navePageList.push(navPageBo);*/
    this.emit();
  };
  //根据id删除一个面板
  deleteNavePage = function(id) {
    /*if(id in _navePageList) {
      delete _navePageList[id];
    }*/

    for (var i in _navePageList) {
      var tempData = _navePageList[i];
      if (tempData.id == id) {
        _navePageList.splice(i, 1) //移除当前对象
      }
    }
    this.emit();
  };

  //根据id更新一个面板
  updataNavePage = function(id, updateData) {
    someToNumber(updateData);
    /*if (id in _navePageList) {
      Object.keys(updateData).forEach(function(key) {
        _navePageList[id][key] = updateData[key];
      });
      this.emit();
    }*/


    for (var i in _navePageList) {
      var tempData = _navePageList[i];
      if (tempData.id == id) {
        Object.keys(updateData).forEach(function(key) {
          tempData[key] = updateData[key];
        });

        this.emit();
      }
    }
  };

  updataSeqByPoint = function() {

    for (var i in _navePageList) {
      var tempData = _navePageList[i];
      tempData.seq = parseInt(i) + 1;
    }
    this.emit();
  };
  getSelectNav = function(){
    var selectData=null;
    for (var i in _navePageList) {
      var tempData= _navePageList[i];
      if (tempData.className == "navPageSelected") {
        selectData = _navePageList[i];
        break;
      }
    }
    return selectData;
  }
  //改变元素位置，当移动的时候
  changeDataPoint = function(currId, targetId) {
    try {
      var currPoint = findPointById(currId);
      var targetPoint = findPointById(targetId);
      var moveData = findNavePageData(currId);
      _navePageList.splice(currPoint, 1);
      _navePageList.splice(targetPoint, 0, moveData);
      this.emit();
    } catch (e) {
      alert(e);
    }
  };

  getNavePageList = function() {
    return _navePageList;
  };
  getNavePageListSize = function() {
    var objLen = 0;
    for (var i in _navePageList) {
      objLen++;
    }
    return objLen;

  };
  setNavePageList = function(navePageList) {
    _navePageList = navePageList;
  };

  //根据id获取一个元素数据
  getNavePageData = function(id) {
    //return _navePageList[id];
    return findNavePageData(id);
  };
  //重新加载导航数据
  refreshData= function(navePageList) {
    _navePageList = navePageList;
    this.emit();
  };
}

export default new NavPageStore();
