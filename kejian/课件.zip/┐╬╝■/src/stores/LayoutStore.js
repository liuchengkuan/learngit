/**
 * 画布布局类
 * author 马君保
 */

import RootStore from './RootStore';

const defaultLayout = {
  top: 60,
  left: 200,
  right: 270,
  minHeight: 650,
  mixWidth: 1000,
  editAreaWidth: 927,
  editAreaHeight: 698,
  editAreaCursor: 'default',
  scale: 1
}

let _layout = defaultLayout;


class LayoutStore extends RootStore {
  getState = () => {
    return _layout;
  };
  
  updataLayout = (config) => {
    for(let key in config) {
      _layout[key] = config[key];
      // 不得不写 框架BUG
      if(key == 'scale') {
        $(".edit-area-canvas").css('transform', `scale(${config[key]})`);
      }
    }
    this.emit();
  };
}

export default new LayoutStore();