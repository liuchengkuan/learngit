/**
 * 编辑区类
 * author 马君保
 */

import RootStore from './RootStore';
import LayoutStore from './LayoutStore';

/**
 * 表示编辑区的类
 * @extends {RootStore}
 */
class EditAreaStore extends RootStore {

  _canvasList = [];

  /**
   * 在画布中添加新元素
   * @param  {object} newData 新元素属性对象
   * @return {undefined}
   * 
   * 
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-12
   */
  addCanvas = (newData) => {
    this._someValueToNumber(newData);
    this._canvasList.push(newData)
    this.selectCanvasById(newData.id);

    this.emit();
  };

  /**
   * 选中指定ID的第一个元素
   * @param  {number|string} id 元素ID
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @deprecated 2016-12-12
   */
  selectCanvasById = (id) => {
    if (!id) return;
    for (let i in this._canvasList) {
      let tempData = this._canvasList[i];
      if (tempData.id == id) {
        tempData.isSelected = true;
      } else {
        tempData.isSelected = false;
      }
    }
    this.emit();
  };

  /**
   * 选中指定ID的第一个元素；当多选时，忽略传入ID，保持原有选择
   * @param  {number|string} id 元素ID
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @deprecated 2016-12-06
   */
  selectCanvas = (id) => {
    if (!id) return;
    let _notSelect = true;
    // 判断是否被选中
    if (this.getCanvasById(id).isSelected == true) {
      _notSelect = false;
    };

    if (_notSelect) {
      this.selectCanvasById(id);
    }

    this.emit();
  };

  /**
   * 选中在矩形范围内的所有元素
   * @param  {object} rectObj 矩形对象
   * @param  {number} rectObj.width 矩形宽度
   * @param  {number} rectObj.height 矩形高度
   * @param  {number} rectObj.x 矩形x点
   * @param  {number} rectObj.y 矩形y点
   * @param  {number} rectObj.canvasLeft 画布与左侧导航区的距离
   * @param  {number} rectObj.canvasTop 画布与顶部菜单栏的距离
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-20
   */
  selectCanvasByRect = (rectObj) => {
    let { width, height, x, y } = rectObj;
    let x2 = x + width,
      y2 = y + height;
    for (let i in this._canvasList) {
      let tempData = this._canvasList[i];
      let computedX = tempData.x;
      let computedY = tempData.y;
      let computedX2 = computedX + tempData.width;
      let computedY2 = computedY + tempData.height;
      if (x <= computedX && x2 >= computedX2 && y <= computedY && y2 >= computedY2) {
        tempData.isSelected = true;
      } else {
        tempData.isSelected = false;
      }
    }
    this.emit();
  };

  /**
   * 取消画布中选中的元素
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-23
   */
  cancelSelected = () => {
    for (let i in this._canvasList) {
      let tempData = this._canvasList[i];
      tempData.isSelected = false;
    }
    this.emit();
  };

  /**
   * 获取选中的元素
   * @return {array} 元素数组
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-23
   */
  getCanvasBySelected = () => {
    let _selected = [];
    for (let i in this._canvasList) {
      let tempData = this._canvasList[i];
      if (tempData.isSelected == true) { _selected.push(tempData) };
    }
    return _selected;
  };

  /**
   * 获取选中的元素的ID
   * @return {array} 元素ID数组
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-23
   */
  getCanvasIdBySelected = () => {
    let _selectedId = [];
    let _selected = this.getCanvasBySelected();
    for (let i in _selected) {
      _selectedId.push(_selected[i].id)
    }
    return _selectedId;
  };


  /**
   * 根据id获取对应的元素
   * @param  {number|string} id 元素ID
   * @return {object|undefined} 查找到的对象，若无返回undefined
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-24
   */
  getCanvasById = (id) => {
    for (let i in this._canvasList) {
      let tempData = this._canvasList[i];
      if (tempData.id == id) {
        return tempData;
      }
    }
  };



  /**
   * 获取画布中所有的元素
   * @return {object|undefined} 所有页面元素
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-24
   */
  getCanvasList = function () {
    return this._canvasList;
  };

  /**
   * 改变选中元素的样式
   * @param {object} updateData 元素的新值
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-24
   */
  updataSelectedCanvasByVaule = (updateData) => {
    let _selected = this.getCanvasBySelected();
    for (let i in _selected) {
      let nowCanvas = _selected[i];
      // 只改变选中的组件样式
      if (nowCanvas.isSelected === true) {
        this._someValueToNumber(updateData);
        Object.keys(updateData).forEach(function (key) {
          nowCanvas[key] = updateData[key];
        });
      }
    }
    this.emit();
  };

  /**
   * 根据id改变对应的元素
   * @param {number|string} id 元素的ID
   * @param {object} updateData 元素的新值
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-24
   */
  updataCanvasById = (id, updateData) => {
    if (!id) return;
    let _selected = this._canvasList;
    for (let i in _selected) {
      let nowCanvas = _selected[i];
      if (nowCanvas.id == id) {
        this._someValueToNumber(updateData);
        Object.keys(updateData).forEach(function (key) {
          nowCanvas[key] = updateData[key];
        });
        this.emit();
      }
    }
  };

/**
   * 根据id改变对应的元素
   * @param {number|string} id 元素的ID
   * @param {object} updateData 元素的新值
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-24
   */
  updataDataById = (id, updateData) => {
    if (!id) return;
    let _selected = this._canvasList;
    for (let i in _selected) {
      let nowCanvas = _selected[i];
      if (nowCanvas.id == id) {
        this._someValueToNumber(updateData);
        Object.keys(updateData).forEach(function (key) {
          nowCanvas[key] = updateData[key];
        });
      }
    }
  };
  // 删除选中的元素
  deleteCanvas = () => {

  };

  // 更新选中的元素
  /**
   * @param  {object} diffData 元素的旧值
   * @param  {object} diffData 元素的新值
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-26
   */
  updataSelectedCanvasByDiff = (diffData) => {
    let _selected = this.getCanvasBySelected();
    console.log();
    for (let i in _selected) {
      let nowCanvas = _selected[i];
      this._someValueToNumber(diffData);
      Object.keys(diffData).forEach(function (key) {
        nowCanvas[key] = diffData[key];
      });
    }
    this.emit();
  };
  /**
  *重新复制表格数据
  */
  updateTableData = (tableEleBo, isRender) => {
    var table = this.getCanvasById(tableEleBo.id);
    table.tableRow = tableEleBo.tableRow;
    table.tableCol = tableEleBo.tableCol;
    table.tr = tableEleBo.tr;
    table.isNewTable = false;
    //console.log(tableEleBo.height);
    table.width = tableEleBo.width;
    table.height = tableEleBo.height;
    table.col = tableEleBo.col;
    table.isCreate = tableEleBo.isCreate;
    //可以不实时渲染，只要改变存储的数据就行
    isRender ? this.emit() : null;
  }


  /**
   * 把元素从当前位置移动到第一个位置
   *
   * @author Ma Junbao <mlive@live.cn>
   * @deprecated 2017-03-16
   */
  front = () => {
    let selectedEle = this.getCanvasBySelected();
    for (let i = 0; i < selectedEle.length; i++) {
      this._swapItems(this._canvasList, this._canvasList.indexOf(selectedEle[i]), this._canvasList.length - 1);
    }
    this.emit();
  }

  /**
   * 把元素从当前位置移动到最后一个位置
   *
   * @author Ma Junbao <mlive@live.cn>
   * @deprecated 2017-03-16
   */
  end = () => {
    let selectedEle = this.getCanvasBySelected();
    for (let i = 0; i < selectedEle.length; i++) {
      this._swapItems(this._canvasList, this._canvasList.indexOf(selectedEle[i]), 0);
    }
    this.emit();
  }

  /**
   * 把元素从当前位置移动到上一个位置
   *
   * @author Ma Junbao <mlive@live.cn>
   * @deprecated 2017-03-16
   */
  prev = () => {
    let selectedEle = this.getCanvasBySelected();
    for (let i = 0; i < selectedEle.length; i++) {
      let index1 = this._canvasList.indexOf(selectedEle[i]);
      let index2 = Math.max(index1 - 1, 0);

      console.log(index2)
      this._swapItems(this._canvasList, index1, index2);
    }
    this.emit();
  }

  /**
   * 把元素从当前位置移动到下一个位置
   *
   * @author Ma Junbao <mlive@live.cn>
   * @deprecated 2017-03-16
   */
  next = () => {
    let selectedEle = this.getCanvasBySelected();
    for (let i = 0; i < selectedEle.length; i++) {
      let index1 = this._canvasList.indexOf(selectedEle[i]);
      let index2 = Math.min(index1 + 1, this._canvasList.length - 1);
      this._swapItems(this._canvasList, index1, index2);
    }
    this.emit();
  }

  getState = () => {
    return this._canvasList;
  };


  /*
   * 私有方法
   */

  // 确保传入参数是数字
  _someValueToNumber = function (obj) {
    obj.x && (obj.x = parseInt(obj.x));
    obj.y && (obj.y = parseInt(obj.y));
    obj.width && (obj.width = parseInt(obj.width));
    obj.height && (obj.height = parseInt(obj.height));
  };

  _swapItems = function (arr, index1, index2) {
    arr[index1] = arr.splice(index2, 1, arr[index1])[0];
  };
}

export default new EditAreaStore();
