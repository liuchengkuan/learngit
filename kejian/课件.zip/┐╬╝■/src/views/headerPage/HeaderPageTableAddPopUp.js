import { h } from 'preact';
import HeaderPageService from './HeaderPageService';
export default function(props) {
  return (
          <div className="add-table-popup hidden" id="add-table-popup">
            <div className="head-info">插入表格</div>
            <div className="td-line-info">
              <span className="count-info">行数:<input type="text" id="tableRowNum" className="input-txt" value="1"/></span>
              <span className="table-count">
                <i className="table-count-icon" onClick={HeaderPageService.plusTableRow}></i>
                <i className="table-count-icon  table-count-plus" onClick={HeaderPageService.subTableRow}></i>
              </span>
            </div>
            <div className="td-line-info">
              <span className="count-info"> 列数:<input type="text" id="tableColNum" className="input-txt" value="1"/></span>
              <span className="table-count">
                <i className="table-count-icon" onClick={HeaderPageService.addTableCol}></i>
                <i className="table-count-icon  table-count-plus" onClick={HeaderPageService.subTableCol}></i>
              </span>
            </div>
             <div className="td-line-info">
              <a className="button-txt" onClick={HeaderPageService.cancelAddTable}>取消</a>
              <a className="button-txt" onClick={HeaderPageService.addTable}>插入 </a>
            </div>
         </div>
  )
};