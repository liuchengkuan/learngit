import EditAreaStore from '../../stores/EditAreaStore';
import ElementBo from '../../bo/ElementBo';
import TableEleBo from '../../bo/TableEleBo';
import CpUtil from '../../utils/CpUtil';
import LayoutStore from '../../stores/LayoutStore';
import EditAreaPageService from '../editAreaPage/EditAreaPageService';
import NavPageService from '../navPage/NavPageService';
import CpBo from '../../bo/CpBo';

import ColorPicker from 'views/components/ColorPicker.js';

const uuid = CpUtil.uuid;
//创建表格的列数
var tableCol=0;
//创建表格的行数
var tableRow=0;
//表格弹出框内鼠标移动动态变化的标志
var mouseover=false;
//点击事件时是点击页面需要弹框的元素还是其他元素
var clickFlag=true;
//显示或隐藏形状的弹出层
function showorOrHideShapePopUp() {
  try {
  	if($('#shapePopUpDiv').hasClass('hidden')){
 		$('#shapePopUpDiv').removeClass('hidden');
  	}else{
  		$('#shapePopUpDiv').addClass('hidden');
  	}
   
    
  } catch (e) {
    console.error(e);
  }
}
//显示或隐藏表格的弹出层
function showorOrHideTablePopUp() {
  try {
  	if($('#tablePopUp').hasClass('hidden')){
 		$('#tablePopUp').removeClass('hidden');
  	}else{
  		$('#tablePopUp').addClass('hidden');
  	}
  } catch (e) {
    console.error(e);
  }
}
function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}
const HeaderPageService = {
	//头部导航栏图形按钮点击事件
	shapeIconClick: function(event) {
    	try {
    		$('#tablePopUp').addClass('hidden');
     		showorOrHideShapePopUp();
        clickFlag=false;
    	} catch (e) {
      		console.error(e);
    	}
  	},
  	//头部导航栏表格按钮点击事件
  	tableIconClick:function(event){
 
		try {
			$('#shapePopUpDiv').addClass('hidden');
			var span=$("#tablePopUpSpan").find("span");
  			span.removeClass('on');
  			tableCol=0;
  			tableRow=0;
  			$("#heeaderTableText").text(tableRow+'*'+tableCol+'表格');
     		showorOrHideTablePopUp();
     		mouseover=true;
        clickFlag=false;
    	} catch (e) {
      		console.error(e);
    	}
  	},
  	
  	tablePopUponMouseover:function(event){
  		if(mouseover){
        var mouseSpanEle=$(getEvetTarget(event));
        var spanId=mouseSpanEle.attr("id");
        tableRow=parseInt(spanId.split("_")[0]);
        tableCol=parseInt(spanId.split("_")[1]);
  			var span=$("#tablePopUpSpan").find("span");
  			span.removeClass('on');
  			//改变弹出层的选中的td
  			for(var i=0;i<span.length;i++){ 
          var currSpanId=$(span[i]).attr("id");
          var currRow=parseInt(currSpanId.split("_")[0]);
          var currCol=parseInt(currSpanId.split("_")[1]);
  				if(currRow<=tableRow&&currCol<=tableCol){
  					$(span[i]).addClass("on");
  				}
  			}
  			$("#heeaderTableText").text(tableRow+'*'+tableCol+'表格');
  			//console.log(tableCol +' '+tableRow);
  		}
  	},
  	//表格弹出框的每个表格鼠标点击事件
  	tablePopUponTdClick:function(){
  		if(mouseover){
  			mouseover=false;
  		}else{
  			mouseover=true;
  		}
      showorOrHideTablePopUp();
      if(tableCol!=0&&tableRow!=0){
          var elementBo = new ElementBo();
          elementBo.type = "table";
          elementBo.id = uuid();
          elementBo.width = 400;
          elementBo.height = parseInt(tableRow)*44;
          elementBo.tableRow=tableRow;
          elementBo.tableCol=tableCol;
          elementBo.x = parseInt(LayoutStore.getState().editAreaWidth) / 2 - parseInt(elementBo.width) / 2;
          elementBo.y = parseInt(LayoutStore.getState().editAreaHeight) / 2 - parseInt(elementBo.height) / 2;
          EditAreaStore.addCanvas(elementBo);
      }
  		   
  	},
    //鼠标在选择表格行列范围内移出事件
  	tablePopUpMouseOut:function(e){
      if(e.layerY<=40||e.layerY>239||e.layerX<0||e.layerX>240){
        //console.log(111);
        var span=$("#tablePopUpSpan").find("span");
        span.removeClass('on');
        tableCol=0;
        tableRow=0;
        $("#heeaderTableText").text(tableRow+'*'+tableCol+'表格');
      }
  	},
    //点击页面空白地方隐藏弹出框
    hiddenAllPopUp:function(){
      if(!$('#shapePopUpDiv').hasClass('hidden')&&clickFlag){
        $('#shapePopUpDiv').addClass('hidden');
      }
      if(!$('#tablePopUp').hasClass('hidden')&&clickFlag){
        $('#tablePopUp').addClass('hidden');
      }
      $('#navEleRmenu').css('visibility', 'hidden');
      $('#menu').css('visibility', 'hidden');
      //$("#tableSelected").css('visibility', 'hidden');
      $("#filemenu").css('visibility', 'hidden');
      clickFlag=true;
    },
    //在图形弹出框内点击时修改clickFlag为true
    changeClickFlag:function(){
      clickFlag=false;
    },
    showAddTableView:function(){
      $("#tableRowNum").val(1);
      $("#tableColNum").val(1);
     $("#add-table-popup").removeClass("hidden");
     $('#tablePopUp').addClass('hidden');
    },
    cancelAddTable:function(){
      $("#add-table-popup").addClass("hidden");
    },
    plusTableRow:function(){
      var row=parseInt($("#tableRowNum").val());
      $("#tableRowNum").val(row+1);
      tableRow=row+1;
    },
    subTableRow:function(){
      var row=parseInt($("#tableRowNum").val());
      if(row==1){
          return;
      }
      $("#tableRowNum").val(row-1);
      tableRow=row-1;
    },
    addTableCol:function(){
      var col=parseInt($("#tableColNum").val());
      $("#tableColNum").val(col+1);
      tableCol=col+1;
    },
    subTableCol:function(){
      var col=parseInt($("#tableColNum").val());
      if(col==1){
        return;
      }
      $("#tableColNum").val(col-1);
      tableCol=col-1;
    },
    addTable:function(){
      tableRow=$("#tableRowNum").val();
      tableCol=$("#tableColNum").val();
      HeaderPageService.cancelAddTable();
      var elementBo = new ElementBo();
      elementBo.type = "table";
      elementBo.id = uuid();
      elementBo.width = 400;
      elementBo.height = parseInt(tableRow)*38.5;
      elementBo.tableRow=tableRow;
      elementBo.tableCol=tableCol;
      elementBo.x = parseInt(LayoutStore.getState().editAreaWidth) / 2 - parseInt(elementBo.width) / 2;
      elementBo.y = parseInt(LayoutStore.getState().editAreaHeight) / 2 - parseInt(elementBo.height) / 2;
      EditAreaStore.addCanvas(elementBo);
    },
    preView:function(){ //预览
       // EditAreaPageService.screenshot();

       //颜色板使用时实例
       let colorPicker = new ColorPicker("#FF00FF");
       colorPicker.on('click',function(data){ //定义事件以及绑定的自定义回调函数
                alert(data);
       });
       var e = window.event || arguments[0];
       // console.log(e);
       colorPicker.show(e);
    },
    
    //课件创建，打开，保存，预览等相关操作-----------------------start
    //创建课件
    createCp:function(){

      var cpBo =  new CpBo();
      cpBo.id='1';
      cpBo.name='测试';
      var cpBoStr = JSON.stringify(cpBo)
      CP.createCp(cpBoStr);
     
    }
    //课件创建，打开，保存，预览等相关操作-----------------------end
}
export default HeaderPageService;