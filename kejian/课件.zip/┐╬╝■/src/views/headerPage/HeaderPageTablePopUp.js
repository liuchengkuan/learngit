import { h } from 'preact';
import HeaderPageService from './HeaderPageService';
export default function(props) {
  let create100Span= () =>{
    let span=[];
    for(var i=1;i<=9;i++){
      for(var j=1;j<=10;j++){
          var id=i+"_"+j+"_tSpan";
          span.push(<span id={id} className="header-table-icon" onmouseleave={HeaderPageService.tablePopUpMouseOut} onmouseover={HeaderPageService.tablePopUponMouseover} onClick={HeaderPageService.tablePopUponTdClick}></span>);
      }  
    };
    return span;
}
  return (
    <div className="header-page-popup hidden" id="tablePopUp" onmouseleave={HeaderPageService.tablePopUpMouseOut} onclick={HeaderPageService.changeClickFlag}>
          <span className="popup-point"></span>
          <div className="header-table-text" id="heeaderTableText">0*0表格</div>
          <div className="header-table" id="tablePopUpSpan" onmouseleave={HeaderPageService.tablePopUpMouseOut}>
           {create100Span()}
          </div>
          <div className="header-table-add" onClick={HeaderPageService.showAddTableView}>
           <span className="header-table-add-icon">插入表格...</span>
          </div>
        </div>
  )
};