import { h } from 'preact';

export default function(props) {
  return (
    <div className="header-page-group">
      {props.children}
    </div>
  )
};
