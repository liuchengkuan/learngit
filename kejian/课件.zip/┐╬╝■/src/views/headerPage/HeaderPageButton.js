import { h } from 'preact';

export default function(props) {
  return (
    <div onClick={props.onClick} className="header-page-button">
      <a className={'header-page-button-icon-'+props.icon}></a>
      <span className='header-page-button-text'>{props.text}</span>
    </div>
  )
};
