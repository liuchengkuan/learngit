import { h } from 'preact';
import HeaderPageGroup from './HeaderPageGroup';
import HeaderPageButton from './HeaderPageButton';
import HeaderPageSelect from './HeaderPageSelect';
import HeaderPageTool from './HeaderPageTool';
import HeaderPageTableAddPopUp from './HeaderPageTableAddPopUp';
import HeaderPageService from './HeaderPageService';
import HeaderPageShapePopUp from './HeaderPageShapePopUp';
import HeaderPageTablePopUp from './HeaderPageTablePopUp';
import EditAreaPageService from '../editAreaPage/EditAreaPageService';
import LayoutStore from 'stores/LayoutStore';
import EditAreaStore from 'stores/EditAreaStore';
import TxtService from 'views/components/txt/TxtService';

function HeaderPage(props) {
  let testAdd = (e) => {
    let ele = e.target.value;
    switch (ele) {
      case '1':
        EditAreaPageService.addEle('testLine')
        break;
      default:

    }
  }
  let clickFileButton = (e) =>{
      e.stopPropagation();
      $("#filemenu").css("visibility","visible");
  }
  let switchLayoutRight = () => {
    LayoutStore.updataLayout({
      right: LayoutStore.getState().right ? 0 : 270
    });
  }

  return (
    <div className="header-page">
      <a onClick={() => { TxtService.demo() }}>siusi</a>
      <input type="button" value="测试" onClick={() => { TxtService.demo() }}/>
      <a href="#" onClick={() => { TxtService.demo() }}>hello</a>

      <HeaderPageGroup>
        <HeaderPageButton icon="file" text="文件" onClick={clickFileButton}/>
        <div id="filemenu" class="rmenu cp-view">
          <div class="menuitems">
            <a><i class="menu-icon ricon-add"></i>新建</a>
            <a><i class="menu-icon ricon-open"></i>打开</a>
          </div>
        </div>
        <HeaderPageButton icon="save" text="新建课件" onClick={HeaderPageService.createCp} />
        <HeaderPageButton icon="save" text="保存" />
        <HeaderPageButton icon="preview" text="预览" onClick={HeaderPageService.preView} />
      </HeaderPageGroup>
      {" "}
      <HeaderPageGroup>
        <HeaderPageTool icon="text" text="文字" onClick={() => { EditAreaPageService.addEle('txt') }} />
        <HeaderPageTool icon="shape" text="形状" onClick={HeaderPageService.shapeIconClick} />
        <HeaderPageShapePopUp />
        <HeaderPageTool icon="table" text="表格" onClick={HeaderPageService.tableIconClick} />
        <HeaderPageTablePopUp />
        <HeaderPageTool icon="template" text="教学模版" />
        <HeaderPageTool icon="study" text="教学模版" />
        <HeaderPageTool icon="test" text="互动试题" />
        <HeaderPageTool icon="file" text="插入文件" />
        <HeaderPageTool icon="resource" text="调用资源" />
      </HeaderPageGroup>
      {" "}
      <HeaderPageGroup>
        <HeaderPageButton icon="style" text="格式" onClick={switchLayoutRight} />
        <HeaderPageButton icon="doc" text="文稿" onClick={function () { console.log(EditAreaStore.getState()) }} />
      </HeaderPageGroup>
      <HeaderPageTableAddPopUp></HeaderPageTableAddPopUp>
    </div>
  )

}

export default HeaderPage;
