import { h } from 'preact';

export default function(props) {
  return (
    <div onClick={props.onClick} className="header-page-tool">
      <a className={'header-page-tool-icon-'+props.icon}></a>
      <span className='header-page-tool-text'>{props.text}</span>
    </div>
  )
};
