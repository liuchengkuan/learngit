import { h } from 'preact';
import EditAreaPageService from '../editAreaPage/EditAreaPageService';
import HeaderPageService from './HeaderPageService';

export default function (props) {
  return (
    <div className="header-page-popup hidden" id="shapePopUpDiv" onclick={HeaderPageService.changeClickFlag}>
      <span className="popup-point"></span>
      <div className="header-popup-text">线条</div>
      <div className="header-popup-icon">
        <span className="header-popup-tool-icon header-popup-icon-line"></span>
        <span className="header-popup-tool-icon header-popup-icon-arrow"></span>
        <span className="header-popup-tool-icon header-popup-icon-double-arrow"></span>
        <span className="header-popup-tool-icon header-popup-icon-curve"></span>
      </div>
      <div className="header-popup-text">图形</div>
      <div className="header-popup-icon">
        <span className="header-popup-tool-icon header-popup-icon-square1" onClick={() => { EditAreaPageService.addEle('rect') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-square1" onClick={() => { EditAreaPageService.addEle('square') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-square2" onClick={() => { EditAreaPageService.addEle('roundedRectangle') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-square3" onClick={() => { EditAreaPageService.addEle('circle') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-square3" onClick={() => { EditAreaPageService.addEle('ellipse') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-square4" onClick={() => { EditAreaPageService.addEle('isocelesTriangle') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-square5" onClick={() => { EditAreaPageService.addEle('triangle') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-square6" onClick={() => { EditAreaPageService.addEle('equilateralTriangle') }}></span>
      </div>
      <div className="header-popup-text">提示组件</div>
      <div className="header-popup-icon">
        <span className="header-popup-tool-icon header-popup-icon-hint1"></span>
        <span className="header-popup-tool-icon header-popup-icon-hint2"></span>
      </div>

      <div className="header-popup-text">其它</div>
      <div className="header-popup-icon">
        <span className="header-popup-tool-icon header-popup-icon-other1" onClick={() => { EditAreaPageService.addEle('rhombus') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-other2" onClick={() => { EditAreaPageService.addEle('hexagon') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-other3" onClick={() => { EditAreaPageService.addEle('pentagon') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-other4" onClick={() => { EditAreaPageService.addEle('oblique') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-other5" onClick={() => { EditAreaPageService.addEle('trapezoid') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-other6" onClick={() => { EditAreaPageService.addEle('start') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-other7" onClick={() => { EditAreaPageService.addEle('right') }}></span>
        <span className="header-popup-tool-icon header-popup-icon-other8" onClick={() => { EditAreaPageService.addEle('cross') }}></span>

      </div>
    </div>
  )
};