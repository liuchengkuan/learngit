import { h } from 'preact';

export default function(props) {
  let setEditAreaScale = (e) => {
    let scale = e.target.value || '100';
    switch(scale) {
      case 'auto': 
        break;
      case '25':
      case '50':
      case '25':
      case '75':
      case '100':
      case '125':
      case '150':
      case '200':
        props.onUpdataLayout({
          'scale': parseFloat(scale/100)
        });
        break;
    }
  }

  return (
    <div className="header-page-button">
      <select onChange={setEditAreaScale}>
        <option value="auto">auto</option>
        <option value="25">25%</option>
        <option value="50">50%</option>
        <option value="75">75%</option>
        <option value="100" selected>100%</option>
        <option value="125">125%</option>
        <option value="150">150%</option>
        <option value="200">200%</option>
      </select>
      <span className='header-page-button-text'>{props.text}</span>
    </div>
  )
};
