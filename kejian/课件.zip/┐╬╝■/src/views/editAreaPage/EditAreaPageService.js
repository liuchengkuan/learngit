import EditAreaStore from '../../stores/EditAreaStore';
import ElementBo from '../../bo/ElementBo';
import CpUtil from '../../utils/CpUtil';
import LayoutStore from '../../stores/LayoutStore';
import TxtService from '../components/txt/TxtService';
import NavPageService from '../navPage/NavPageService';
import HeaderPageService from '../headerPage/HeaderPageService';
const uuid = CpUtil.uuid;
/**
 * 编辑区业务类
 * @auto 庄召
 */

const EditAreaPageService = {

  //初始执行函数
  init: function () {

    /*try {
      
    } catch (e) {
      console.error(e);
    }*/

  },
  // 添加组件，文本、图形其它
  // 目前只做初次添加组件
  addEle: function (vtype) {
    try {
      var elementBo = new ElementBo();
      elementBo.type = vtype;
      elementBo.id = uuid();
      elementBo.width = 150;
      elementBo.height = 150;

      // if(vtype.indexOf("ine")>0){
      //   elementBo.fill='#000000';
      //   elementBo.strokeWidth=1;
      //   elementBo.height = 4;
      // }
      // if(elementBo.type == 'testLine') {
      //   elementBo.strokeWidth = 2;
      //   elementBo.height = elementBo.strokeWidth + 2;
      // }

      switch (elementBo.type) {
        case 'txt':
          elementBo.width = 150, elementBo.height = 30;
          elementBo.fill="";
          break;
        case 'equilateralTriangle':
          elementBo.width = (elementBo.height * Math.sqrt(3) * 2) / 3;
          break;
        case 'cross':
        case 'right':
          elementBo.strokeWidth = 10;
          break;
        default:
          break;
      }

      elementBo.x = parseInt(LayoutStore.getState().editAreaWidth) / 2 - parseInt(elementBo.width) / 2;
      elementBo.y = parseInt(LayoutStore.getState().editAreaHeight) / 2 - parseInt(elementBo.height) / 2;

      EditAreaStore.addCanvas(elementBo);
      HeaderPageService.hiddenAllPopUp();
    } catch (e) {
      console.error(e);
    }
  },
  /* // 添加组件，表格
   addTableEle: function(vtype) {
     try {
 
       var tableEleBo = new TableEleBo();
       tableEleBo.type = vtype;
       tableEleBo.id = uuid();
       tableEleBo.width = 150;
       tableEleBo.height = 150;
       tableEleBo.col=2;
       tableEleBo.row=3;
       tableEleBo.x = parseInt(LayoutStore.getState().editAreaWidth) / 2 - parseInt(tableEleBo.width) / 2;
       tableEleBo.y = parseInt(LayoutStore.getState().editAreaHeight) / 2 - parseInt(tableEleBo.height) / 2;
 
       EditAreaStore.addCanvas(tableEleBo);
     } catch (e) {
       console.error(e);
     }
   },*/
  // 表格td点击事件
  tableTdClick: function (event) {
    try {
      var ele = event.srcElement ? event.srcElement : event.target;
      var input = $(ele).find('input');
      if (input.is(':focus')) return;
      var span = $(ele).find('span');
      input.removeClass('hidden');
      input.val(span.text());
      input.focus();
      span.addClass('hidden');
    } catch (e) {
      console.error(e);
    }
  },
  //input框输入结束
  inputBlur: function (event) {
    try {
      var ele = event.srcElement ? event.srcElement : event.target;
      var inputEle = $(ele);
      inputEle.addClass('hidden');
      var span = inputEle.parents('td').find('span');
      span.text(inputEle.val());
      span.removeClass('hidden');
    } catch (e) {
      console.error(e);
    }

  },
  //当设置文本框的样式的时候可能触发文本其它样式的变化，如大小的变化。调用这个方法重新计算
  setTxtStyleBychangePrp: function (id) {

    var paretEle = $('#' + id);
    var currTxtAreaEle = paretEle.children(".txt_AreaText");
    // TxtService.command('bold');

    TxtService.setTxtSize(currTxtAreaEle, paretEle);

  },

  //测试方法用别删除
  demo: function () {


    try {
      html2canvas($('.edit-area-canvas')[0], {
        onrendered: function (canvas) {
          var url = canvas.toDataURL();
          NavPageService.setUrlCurrOperSel(url);
        }
      });
    } catch (e) {
      alert('生成导航面板信息异常:' + e);
    }
  },
  screenshot: function () {  //截图
    try {
      $.get("./bundle.css",  //读取css内容
        function(data,status){
           var h = $('#mainEditArea').height();
           var w = $('#mainEditArea').width();
           var content = [];
           content.push('<style type="text/css">');
           content.push(data);
           content.push('</style>');
           content.push($('.edit-area-canvas')[0].outerHTML);
           rasterizeHTML.drawHTML(content.join("")).then(function (renderResult) { //renderResult={image :,svg :,errors :}
                // console.log($(renderResult.image).css('height'));
                // console.log($(renderResult.image).css('width'));
                // console.log(renderResult.svg);
                // NavPageService.setUrlCurrOperSel(renderResult.image.src);//添加截图
                
                var canvas = document.getElementById("canvasDemo");
                var context = canvas.getContext('2d');
                context.drawImage(renderResult.image);
                var url = canvas.toDataURL();
                NavPageService.setUrlCurrOperSel(url);

           });
       });
    } catch (e) {
      alert('截图异常:' + e);
    }
  }

}

export default EditAreaPageService;
