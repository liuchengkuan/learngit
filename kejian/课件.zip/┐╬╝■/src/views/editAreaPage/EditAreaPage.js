import { render, h, Component } from 'preact';
import Shape from '../components/shape/Shape';
import EditAreaPageService from './EditAreaPageService';
import NavPageService from '../navPage/NavPageService';
import HeaderPageService from '../headerPage/HeaderPageService';

class EditAreaPage extends Component {
  canvasStyle = {
    width: this.props.layout.editAreaWidth,
    height: this.props.layout.editAreaHeight,
    top: '50%',
    left: '50%',
    overflow: 'visible',
    background: '#fff',
    marginLeft: this.props.layout.editAreaWidth / -2,
    marginTop: this.props.layout.editAreaHeight / -2,
    cursor: this.props.layout.editAreaCursor,
    transform: `scale(${this.props.layout.scale})`,
    transition: 'transform 0.3s'
  }

  componentDidUpdate() {
    // try {
    //   html2canvas($('.edit-area-canvas')[0], {
    //     onrendered: function(canvas) {
    //       var url = canvas.toDataURL();
    //       NavPageService.setUrlCurrOperSel(url);
    //     }
    //   });
    // } catch (e) {
    //    alert('生成导航面板信息异常:'+e);
    // }
  }

  render(props, state) {
    return (
      <div id='mainEditArea' className="edit-area-page">
        <div className="cp-view edit-area-canvas" style={this.canvasStyle}>
          {
            Object.keys(props.canvas).map((item) => {
              return <Shape {...props} {...props.canvas[item]} />
            })
          }
        </div>
      </div>
    )
  }
}

// function EditAreaPage(props) {
//   let canvasStyle = {
//     width: props.layout.editAreaWidth,
//     height: props.layout.editAreaHeight,
//     top: '50%',
//     left: '50%',
//     overflow: 'visible',
//     background: '#fff',
//     marginLeft: props.layout.editAreaWidth / -2,
//     marginTop: props.layout.editAreaHeight / -2,
//     cursor: props.layout.editAreaCursor,
//     transform: `scale(${props.layout.scale})`
//   }

//   return (
//     <Marquee {...props}>
//       <div id='mainEditArea' className="edit-area-page">
//         <div className="cp-view edit-area-canvas" style={canvasStyle}>
//           {
//             Object.keys(props.canvas).map((item) => {
//               return <Shape {...props} {...props.canvas[item]} />
//             })
//           }
//         </div>

//           <div className="add-table-popup">
//             <div className="head-info">插入表格</div>
//             <div className="td-line-info">
//               <span className="count-info">行数:<input type="text" className="input-txt" value="3"/></span>
//               <span className="table-count">
//                 <i className="table-count-icon"></i>
//                 <i className="table-count-icon  table-count-plus"></i>
//               </span>
//             </div>
//             <div className="td-line-info">
//               <span className="count-info"> 列数:<input type="text" className="input-txt" value="3"/></span>
//               <span className="table-count">
//                 <i className="table-count-icon"></i>
//                 <i className="table-count-icon  table-count-plus"></i>
//               </span>
//             </div>
//              <div className="td-line-info">
//               <a className="button-txt">取消</a>
//               <a className="button-txt">插入 </a>
//             </div>
//          </div>
//       </div>
//     </Marquee>
//   )
// }

export default EditAreaPage;
