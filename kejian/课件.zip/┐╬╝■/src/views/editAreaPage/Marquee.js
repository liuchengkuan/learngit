import LayoutStore from 'stores/LayoutStore';
import EditAreaStore from 'stores/EditAreaStore';

class Marquee {
  constructor() {
    this.state = {
      canvasPosition: {
        x: 0,
        y: 0
      },
      originalCursorPosition: {
        x: 0,
        y: 0
      },
      marqueeRect: {
        x: 0,
        y: 0,
        width: 0,
        height: 0
      }
    }
    this.block = {
      domElement: $('#mainEditArea')
    }
    this.render();
    this.bind();
    this.layout();
  }

  render() {
    this.domElement = $('<div>');
  }
  destroy() {
    this.domElement.remove();
  }
  bind() {
    this.onMouseDown = this.onMouseDown.bind(this);
    this.onMouseMove = this.onMouseMove.bind(this);
    this.onMouseUp = this.onMouseUp.bind(this);
    this.block.domElement.on('mousedown', this.onMouseDown);
  }
  show() {
    this.domElement.appendTo(this.block.domElement).css('visibility', 'visible');
  }
  hide() {
    this.domElement.css({
      visibility: 'hidden',
      width: 0,
      height: 0,
      top: 0,
      left: 0
    });
  }
  layout() {
    this.domElement.css({
      width: this.state.marqueeRect.width,
      height: this.state.marqueeRect.height,
      left: this.state.marqueeRect.centerX,
      top: this.state.marqueeRect.centerY,
      backgroundColor: 'rgba(0,0,0,0.2)',
      position: 'absolute'
    })
  }
  deviationScale(data) {
    let scale = LayoutStore.getState().scale;
    if (scale !== 1) {
      data.width = data.width / scale;
      data.height = data.height / scale;
      data.x = data.x / scale;
      data.y = data.y / scale;
    }
  }
  onMouseDown(e) {
    if(e.which === 1) {
      EditAreaStore.cancelSelected();

      $(document).on('mousemove', this.onMouseMove);
      $(document).on('mouseup', this.onMouseUp);

      let canvasOffset = $('.edit-area-canvas').offset();

      this.state.canvasPosition.x = canvasOffset.left;
      this.state.canvasPosition.y = canvasOffset.top;

      this.state.originalCursorPosition.x = e.clientX;
      this.state.originalCursorPosition.y = e.clientY;

      this.show();
    }
  }
  onMouseMove(e) {
    this.state.marqueeRect.clientX = Math.min(this.state.originalCursorPosition.x, e.clientX);
    this.state.marqueeRect.clientY = Math.min(this.state.originalCursorPosition.y, e.clientY);
    this.state.marqueeRect.centerX = this.state.marqueeRect.clientX - LayoutStore.getState().left;
    this.state.marqueeRect.centerY = this.state.marqueeRect.clientY - LayoutStore.getState().top;
    this.state.marqueeRect.x = this.state.marqueeRect.clientX - this.state.canvasPosition.x;
    this.state.marqueeRect.y = this.state.marqueeRect.clientY - this.state.canvasPosition.y;
    this.state.marqueeRect.width = Math.abs(e.clientX - this.state.originalCursorPosition.x);
    this.state.marqueeRect.height = Math.abs(e.clientY - this.state.originalCursorPosition.y);

    this.layout();

    // 修正旋转偏移量
    this.deviationScale(this.state.marqueeRect);
    EditAreaStore.selectCanvasByRect(this.state.marqueeRect);
  }
  onMouseUp(e) {
    $(document).off('mousemove', this.onMouseMove);
    $(document).off('mouseup', this.onMouseUp);

    this.hide();
  }
}

export default Marquee;