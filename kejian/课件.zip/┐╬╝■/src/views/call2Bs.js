/**
* 前台暴露
*/
const  ExternalInterface  = {
  addCallback: function(funcName,method) {
    
       window[funcName]=method;
  }
}




//window.ExternalInterface = ExternalInterface;
window.EI = ExternalInterface;

function demo(str){
  alert(str);
  //Cef.AlertMessage("hi");

 alert( CP.strMessage());
}

EI.addCallback('demo',demo);
export default ExternalInterface;