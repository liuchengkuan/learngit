import { h, render, Component } from 'preact';
import Outer from './appLayout/Outer';
import Top from './appLayout/top';
import Left from './appLayout/Left';
import Center from './appLayout/Center';
import Right from './appLayout/Right';

import LayoutStore from '../stores/LayoutStore';
import EditAreaStore from '../stores/EditAreaStore';
import NavPageStore from '../stores/NavPageStore';

import Event from './components/base/Event';

const getState = {
  layout: LayoutStore.getState(), // 界面布局数据
  canvas: EditAreaStore.getState(), // 画布数据,
  navePageList: NavPageStore.getState(), // 左侧导航数据
}

const getStores = {
  getCanvasById: EditAreaStore.getCanvasById, //根据id获取组件，类似于getElementById
  getCanvasBySelected: EditAreaStore.getCanvasBySelected,
  getCanvasIdBySelected: EditAreaStore.getCanvasIdBySelected,
  getAllCanvasBySelected: null, //获取选中的全部组件，返回id数组

  onUpdataLayout: LayoutStore.updataLayout, //更新页面布局
  onUpdataCanvasById: EditAreaStore.updataCanvasById, //更新一个组件
  onUpdataSelectedCanvasByValue: EditAreaStore.updataSelectedCanvasByVaule, //更新选中的组件，参数是计算值
  onUpdataSelectedCanvasByDiff: EditAreaStore.updataSelectedCanvasByDiff, //更新选中的组件，参数是差值
  onAddCanvas: EditAreaStore.addCanvas, //添加一个组件
  onDeleteCanvas: EditAreaStore.deleteCanvas, //删除选中的组件
  onSelectCanvas: EditAreaStore.selectCanvas, //选中一个组件
  onSelectCanvasByRect: EditAreaStore.selectCanvasByRect, //选中矩形内的组件
  onCancelSelected: EditAreaStore.cancelSelected, // 取消选中的组件
}

class MainView extends Component {
  componentDidMount() {
    LayoutStore.addChangeListener(this._onChange);
  }

  componentWillUnmount() {
    LayoutStore.removeChangeListener(this._onChange)
  }

  render({ props = {...getStores, ...getState } }) {
    return (
      <Outer {...props} >
        <Top {...props} />
        <Left {...props} />
        <Center {...props} />
        <Right {...props} />
      </Outer>
    );
  }

  _onChange = () => {
    this.setState(getState);
  }
}

export default MainView;
