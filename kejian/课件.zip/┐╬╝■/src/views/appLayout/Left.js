import {h} from 'preact';
import NavPage from '../navPage/NavPage';
import DragCore from '../components/base/DragCore';
const style = {
  bottom: 0,
  left: 0
}

function Left(props) {
  let onNavPageResize = (data) => {
    // 导航宽度 150~300
    let navWidth = props.layout.left + data.dx;
    let minWidth = 150,maxWidth = 300;
    navWidth < minWidth && (navWidth = minWidth);
    navWidth > maxWidth && (navWidth = maxWidth);
    props.onUpdataLayout({
      left: navWidth
    });
  }

  let onNavPageResizeStart = (data) => {
    
  }

  let onNavPageResizeStop = (data) => {
    
  }

  return (
    <div className="cp-view" style={{...style, width: props.layout.left, top: props.layout.top}}>
      <NavPage {...props} />
      <DragCore onDrag={onNavPageResize} onDragStart={onNavPageResizeStart} onDragStop={onNavPageResizeStop} >
        <div className="nav-page-resize"></div>
      </DragCore>
    </div>
  )
}

export default Left;