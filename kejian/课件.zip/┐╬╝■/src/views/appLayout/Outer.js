import { h } from 'preact';
import NavPageService from '../navPage/NavPageService';
import HeaderPageService from '../headerPage/HeaderPageService';
import TableService from '../components/table/TableService';
function Outer(props) {
  return (
    <div onclick={HeaderPageService.hiddenAllPopUp}>
      {props.children}

      {/*右击菜单 */}
      <div id="menu" class="rmenu cp-view">
        <div class="menuitems">
          <a onclick={NavPageService.addNavePageByNewMenu}><i class="menu-icon ricon-add"></i>新建幻灯片</a>
          <a onclick={NavPageService.delNavPageByRightClick}><i class="menu-icon ricon-delete"></i>删除幻灯片</a>
          <a onclick={NavPageService.pasteNavPage}><i class="menu-icon ricon-copy"></i>粘贴</a>
        </div>
      </div>
      <div id="navEleRmenu" class="rmenu cp-view">
        <div class="menuitems">
          <a onclick={NavPageService.addNavePageByNewMenu}><i class="menu-icon ricon-add"></i>新建幻灯片</a>
          <a onclick={NavPageService.delNavPageByRightClick}><i class="menu-icon ricon-delete"></i>删除幻灯片</a>
          <a onclick={NavPageService.copyCurrNavPage}><i class="menu-icon ricon-copy"></i>拷贝</a>
          <a onclick={NavPageService.cutCurrNavPage}><i class="menu-icon ricon-copy"></i>剪切</a>
          <a onclick={NavPageService.pasteNavPage}><i class="menu-icon ricon-copy"></i>粘贴</a>
          {/*<a onclick={NavPageService.delNavPageByRightClick}><i class="menu-icon ricon-delete"></i>删除幻灯片</a>*/}
        </div>
      </div>

      <div id="tableRCMenu" class="rmenu cp-view">
        <div class="menuitems">
          <a onclick={TableService.combineTd}><i class="menu-icon ricon-add"></i>合并单元格</a>
          <a onclick={TableService.revertTd}><i class="menu-icon ricon-delete"></i>拆分单元格</a>
          <a onclick={TableService.insertTrBefore}><i class="menu-icon ricon-copy"></i>上方插入行</a>
          <a onclick={TableService.insertTrAfter}><i class="menu-icon ricon-copy"></i>下方插入行</a>
          <a onclick={TableService.insertColBefore}><i class="menu-icon ricon-copy"></i>左侧插入列</a>
          <a onclick={TableService.insertColAfter}><i class="menu-icon ricon-copy"></i>右侧插入列</a>
          <a onclick={TableService.deleteChoiceRow}><i class="menu-icon ricon-copy"></i>删除行</a>
          <a onclick={TableService.deleteChoiceCol}><i class="menu-icon ricon-copy"></i>删除列</a>
          {/*<a onclick={NavPageService.delNavPageByRightClick}><i class="menu-icon ricon-delete"></i>删除幻灯片</a>*/}
        </div>
      </div> 
      <div id="moveHelp"></div>
      <div id="moveHelpDiv"></div>  
      <div id="tableSelected"></div> 
    </div>
  )
}

export default Outer;
