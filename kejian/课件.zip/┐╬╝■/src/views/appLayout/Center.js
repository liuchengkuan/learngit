import {h} from 'preact';
import EditAreaPage from '../editAreaPage/EditAreaPage';
function Center(props) {
  

  let style = {
    bottom: 0,
    top: props.layout.top,
    right: props.layout.right,
    left: props.layout.left,
    cursor: props.layout.editAreaCursor
  }

  return (
    <div className="cp-view" style={style}>
      <EditAreaPage {...props} />
    </div>
  )
}

export default Center;