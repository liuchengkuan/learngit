import {h, cloneElement} from 'preact';
import HeaderPage from '../headerPage/HeaderPage';
const style = {
  top: 0,
  right: 0,
  bottom: 0,
  left: 0
}

function Top(props) {
  return (
    <div className="cp-view" style={{...style, height: props.layout.top, overflow: 'visible'}}>
      <HeaderPage {...props} />
    </div>
  )
}

export default Top;