import CpUtil from '../../utils/CpUtil';
import NavPageStore from '../../stores/NavPageStore';
import NavPageBo from '../../bo/NavPageBo';

const uuid = CpUtil.uuid;

//公共变量区-----------------start

var currSelNavId_ByRilghtClick = null; //右击选择元素的id
//移动导航元素使用
var nvaPageEleMove = false;
var nvaPageEleMoveStart = false;
var startNavPageEle = null;


var currOperNavId; // 当前操作的面板id..........重要!

var copyNavPageData=null;
//在导航上右击时的对应的y轴坐标
var rightClickY;
//右击是在导航栏的非nav区域
var leftDivClick=false;
//右击是在导航栏navPage区域
var navClick=false;
//是否是粘贴的标志
var isCopy=false;
//公共变量区-----------------end

//内部函数区域-------------------------start

// 获取所有导航元素，范放在这儿是防止查询条件变化
function getAllNavPageEle() {
  return $('#leftMainDiv').children();
}

function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}

function hideAllRMenu() {
  try {
    $('#menu').css('visibility', 'hidden');
    $('#navEleRmenu').css('visibility', 'hidden');
  } catch (e) {
    console.error(e);
  }


}

//获取当前处于选中态的元素
function getSelNavPage() {

}

function showRMenu_NavPageBody(event) {

  event.stopPropagation();
  var menu = document.getElementById('navEleRmenu');
  try {
    var divHeight=$("#navEleRmenu").outerHeight();
    var rightedge = event.clientX;
    var bottomedge = event.clientY;
    var windowHeight=$(window).height();
    //当点击位置加弹出框高度大于页面窗口高度，弹出框在鼠标上方显示
    if(bottomedge+divHeight>windowHeight){
        bottomedge=bottomedge-divHeight;
        menu.style.top = bottomedge + "px";
    }else{
       menu.style.top = bottomedge + "px";
    }
    menu.style.left = rightedge + "px";
    

    $('#navEleRmenu').css('visibility', 'visible');
  } catch (e) {
    console.error(e);
  }
}


function setCuurSel(eleId) {
  currOperNavId = eleId;
  try {
    //数据驱动方式改变
    var navePageList = NavPageStore.getNavePageList();
    for (var i in navePageList) {
      var tempNavPageData = navePageList[i];
      var tempId = tempNavPageData.id;
      if (eleId == tempId) {
        tempNavPageData.className = 'navPageSelected';
      } else {
        tempNavPageData.className = 'navPage';
      }
      NavPageStore.updataNavePage(tempId, tempNavPageData);
    }
  } catch (e) {
    console.error("setCuurSel异常:" + e);
  }
}

//设置所有的都是未选中
function setNoSel() {
  var navePageList = NavPageStore.getNavePageList();

  for (var i in navePageList) {
    var tempNavPageData = navePageList[i];
    var tempId = tempNavPageData.id;
    tempNavPageData.className = 'navPage';

    NavPageStore.updataNavePage(tempId, tempNavPageData);
  }

}


//删除状态时候重新计算seq
function setNavPageEleSeqByDel(currSeq) {
  /* getAllNavPageEle().each(function() {
    var tempSeq = $(this).attr("seq");
    
    if(tempSeq>currSeq){
      $(this).attr("seq",tempSeq-1);
      $(this).children(".navPageLeft").html(tempSeq-1);
    }
  });*/
  try {
    //数据驱动方式改变现实seq
    var navePageList = NavPageStore.getNavePageList();
    for (var i in navePageList) {
      var tempNavPageData = navePageList[i];
      var tempSeq = tempNavPageData.seq;
      var id = tempNavPageData.id;

      if (tempSeq > currSeq) {
        tempNavPageData.seq = tempSeq - 1;
        NavPageStore.updataNavePage(id, tempNavPageData);
      }
    }
  } catch (e) {
    console.error("setNavPageEleSeqByDel异常:" + e);
  }

}
//重新设置所有数据的seq
function changeAllseq(navePageList){
  try {
    for (var i=0;i<navePageList.length;i++) {
      var temp=navePageList[i];
      temp.seq=parseInt(i)+1;
      navePageList[i]=temp;
    }
  } catch (e) {
    console.error("setNavPageEleSeqByDel异常:" + e);
  }
}


// 根据实际的物理顺序重新编码顺序号
function refreshNavPageEleSeqByWL() {

  NavPageStore.updataSeqByPoint();

  /*var seq = 1;
  getAllNavPageEle().each(function() {
    $(this).attr("seq", seq);
    $(this).children(".navPageLeft").html(seq);
  
  });*/
}

function setNavPageEleMoveFalse() {
  nvaPageEleMove = false;
  nvaPageEleMoveStart = false;
  startNavPageEle = null;
  $('#leftMainDiv').css("cursor", "");
}



//内部函数区域-------------------------end

/**
 * 导航面板业务类
 * @auto 庄召
 */
const NavPageService = {

  //初始执行函数
  init: function() {

    try {
      NavPageService.addNavePage();
      //$('#leftMainDiv').bind('contextmenu',this.showLeftRMenu);
      $('#leftMainDiv').get(0).oncontextmenu = function() {
        var evt = window.event || arguments[0];
        evt.stopPropagation();
        evt.preventDefault();
      }

      $('#leftDiv').get(0).oncontextmenu = NavPageService.showLeftRMenu;
    } catch (e) {
      console.error(e);
    }
  },
  initPageChildEle: function() {

  },
  addNavePage: function() {

    try {
      var navPageBo = new NavPageBo();
      navPageBo.id = uuid();
      navPageBo.seq = 1;
      navPageBo.className = 'navPageSelected';
      navPageBo.url = 'images/eg.jpg';
      NavPageStore.addNavePage(navPageBo);
      setCuurSel(navPageBo.id);
    } catch (e) {
      console.error(e);
    }
  },
  addNavePageByNewMenu: function(url) {
    setNoSel();
    NavPageService.hideLeftRMenu();
    var navPageList=NavPageStore.getNavePageList();
    var tempseq;
    var newNavPageEleId = uuid();
    var navPageBo = new NavPageBo();
    navPageBo.id = uuid();
    navPageBo.className = 'navPageSelected';
    navPageBo.url = url||'images/eg.jpg';
    if(leftDivClick){
      tempseq = NavPageStore.getNavePageListSize() + 1;
    }else{
      var currData=NavPageStore.getNavePageData(currOperNavId);
      tempseq=currData.seq;
    }
    navPageBo.seq = tempseq;
    navPageList.splice(tempseq, 0, navPageBo);
    changeAllseq(navPageList);
    NavPageStore.refreshData(navPageList);
  },
  //显示左边右键菜单
  showLeftRMenu: function() {
    //setAllNavPageEleNoSel();
    NavPageService.hideNavEleRmenu();
    var evt = window.event || arguments[0];
    evt.stopPropagation();
    rightClickY=evt.y;
    var menu = document.getElementById('menu');
    try {

      var evt = window.event || arguments[0];
      evt.stopPropagation();
      var divHeight=$("#navEleRmenu").outerHeight();
      var rightedge = evt.clientX;
      var bottomedge = evt.clientY;
      var windowHeight=$(window).height();
      menu.style.left = rightedge + "px";
      //当点击位置加弹出框高度大于页面窗口高度，弹出框在鼠标上方显示
      if(bottomedge+divHeight>windowHeight){
          bottomedge=bottomedge-divHeight;
          menu.style.top = bottomedge + "px";
      }else{
          menu.style.top = bottomedge + "px";
      }
      //currSelNavId_ByRilghtClick = currNavPageEle.attr('id');
      leftDivClick=true;
      navClick=false;
      $('#menu').css('visibility', 'visible');
    } catch (e) {
      console.error(e);
    }

    return false;

  },
  hideLeftRMenu: function() {
    $('#menu').css('visibility', 'hidden');

  },
  hideNavEleRmenu: function() {
    $('#navEleRmenu').css('visibility', 'hidden');

  },
  //导航元素点击事件
  navPageEleClick: function(e) {
    hideAllRMenu();
    /*try {
      hideAllRMenu();
      e.stopPropagation();
      var currNavPageEle = e.srcElement ? e.srcElement : e.target;
      currNavPageEle = $(currNavPageEle).parent().parent();
      setCuurSel(currNavPageEle);
    } catch (e) {
      console.error("navPageEleClick异常:" + e);
    }
    */
  },
  //在右边导航栏上点击
  navPageClick: function(e){
    hideAllRMenu();
  },
  //元素上右击
  navPageRClick: function(event) {
    hideAllRMenu();
    var currNavPageEle = getEvetTarget(event);
    currNavPageEle = $(currNavPageEle).parent().parent();

    currSelNavId_ByRilghtClick = currNavPageEle.attr('id');

    setCuurSel(currSelNavId_ByRilghtClick);
    leftDivClick=false;
    navClick=true;
    // currSelNavEleByRilghtClick = currNavPageEle; 


    showRMenu_NavPageBody(event);
    return false;
  },

  //点击删除菜单删除当前的导航元素
  delNavPageByRightClick: function() {

    hideAllRMenu();

    try {
      var navPageSelectData=NavPageStore.getSelectNav();
      if (navPageSelectData != null) {
        //var currNavPageData = NavPageStore.getNavePageData(currSelNavId_ByRilghtClick);
        var currSeq = navPageSelectData.seq;

        //$(currSelNavEleByRilghtClick).remove();
        //通过数据驱动方式删除
        NavPageStore.deleteNavePage(navPageSelectData.id);


        //重新编码顺序号
        setNavPageEleSeqByDel(currSeq);

        currSelNavId_ByRilghtClick=null;
      }
    } catch (e) {
      console.error('delNavPageByRightClick异常:' + e);
    }

  },

  //导航元素移动事件
  navPageElemousedown: function(event) {
    try {
      hideAllRMenu();
      event.stopPropagation();
      event.preventDefault();
      var currNavPageEle = getEvetTarget(event);
      currNavPageEle = $(currNavPageEle).parent().parent();
      setCuurSel(currNavPageEle.attr('id'));
    } catch (e) {
      console.error("navPageEleClick异常:" + e);
    }

    nvaPageEleMove = true;

    var currNavPageEle = getEvetTarget(event);
    currNavPageEle = $(currNavPageEle).parent().parent();

    startNavPageEle = currNavPageEle;
  },

  navPageElemouseup: function() {

    var e = window.event || arguments[0];
    // e.stopPropagation();

    var currNavPageEle = getEvetTarget(e);
    currNavPageEle = $(currNavPageEle).parent().parent();

    //满足移动条件
    if (startNavPageEle != null && nvaPageEleMoveStart) {
      // console.error(currNavPageEle.attr('id'));
      //判断移动的位置和当前是否是一个
      if (currNavPageEle.attr('id') != $(startNavPageEle).attr('id')) {
        var seq = currNavPageEle.attr('seq');
        var startSeq = $(startNavPageEle).attr('seq');
        var currId = currNavPageEle.attr('id');
        var startId = $(startNavPageEle).attr('id');

        if (seq > startSeq) {


          //$(startNavPageEle).insertAfter(currNavPageEle);
          //通过改变数据位置实现
          NavPageStore.changeDataPoint(startId, currId);
        }
        if (seq < startSeq) {
          // $(startNavPageEle).insertBefore(currNavPageEle);
          //通过改变数据位置实现
          NavPageStore.changeDataPoint(startId, currId);

        }
        refreshNavPageEleSeqByWL();
      }
      setNavPageEleMoveFalse();
    }
  },
  navPageElemousemove: function() {
    if (nvaPageEleMove == true && nvaPageEleMoveStart == false) {
      nvaPageEleMoveStart = true;
      return;
    }
    if (nvaPageEleMoveStart == true) {

      $('#leftMainDiv').css("cursor", "move");
    }
  },
  leftMainDivmouseUp: function() {
    //满足移动条件
    if (startNavPageEle != null) {
      $('#leftMainDiv').append($(startNavPageEle));
      refreshNavPageEleSeqByWL();
    }

    setNavPageEleMoveFalse();

  },
  leftMainDivClk: function() {

    NavPageStore.addNavePage({});
    //this.hideMenu();
    //console.log(Const.objMethod )
    // Const.objMethod.onAddCanvas({type: 'txt'});

    //EditAreaStore.addCanvas({type: 'txt'});
    /* let d = new Canvasbo
    let c = new Canvasbo
    d.fill = 'red';
  
    console.log(d,c)
    EditAreaActions.addCanvas({type: 'txt'});*/
  },
  //设置当前操作的导航面板的内容
  setUrlCurrOperSel: function(url) {
    var tempData = NavPageStore.getNavePageData(currOperNavId);
    if(tempData==null){
    }else{
    }
    tempData.url = url;
    NavPageStore.updataNavePage(tempData.id, tempData);
  },
  //复制当前的节点
  copyCurrNavPage:function(){
    var currData=NavPageStore.getNavePageData(currOperNavId);
    copyNavPageData=currData;
    isCopy=true;
    hideAllRMenu();
  },
 //剪切当前的节点
  cutCurrNavPage:function(){
    var currData=NavPageStore.getNavePageData(currOperNavId);
    copyNavPageData=currData;
    isCopy=false;
    hideAllRMenu();
  },
  //粘贴导航节点
  pasteNavPage:function(e){
    hideAllRMenu();
    //当需要粘贴的数据没有设置时直接返回
    if(copyNavPageData==null){
      return false;
    }
    var navPageList=NavPageStore.getNavePageList();
     var navPageBo = new NavPageBo();
     navPageBo.id = uuid();
     //navPageBo.className = 'navPage';
     navPageBo.url = copyNavPageData.url;
     //将新添加的设置为选中
    navPageBo.className = 'navPageSelected';
    //判断是在导航栏内点击还是在某个导航块内点击
    if(leftDivClick){
      //这部分时当在导航栏最顶端点击时做特殊处理
      if(rightClickY<75){
          navPageBo.seq=0;
          //当为剪切时先删除选择元素在插入元素
          if(!isCopy){
            navPageList.splice(0,1);
            currOperNavId=navPageBo.id;
          }
          setNoSel();
          //navPageBo.className = 'navPageSelected';
          navPageList.splice(0, 0, navPageBo); 
          changeAllseq(navPageList);
         NavPageStore.refreshData(navPageList);
      }else{
        navPageBo.seq=navPageList.length+1;
        if(!isCopy){
            navPageList.splice(copyNavPageData.seq-1,1);
            currOperNavId=navPageBo.id;
          }
        setNoSel();
        //navPageBo.className = 'navPageSelected';
        navPageList.splice(navPageList.length, 0, navPageBo);
        changeAllseq(navPageList);
        NavPageStore.refreshData(navPageList);
      }
    }else{
      var currData=NavPageStore.getNavePageData(currOperNavId);
      var seq=currData.seq;
      if(!isCopy){
            navPageList.splice(copyNavPageData.seq-1,1);
            currOperNavId=navPageBo.id;
            setNoSel();
           // navPageBo.className = 'navPageSelected';
            navPageList.splice(seq-1, 0, navPageBo);
      changeAllseq(navPageList);
      }else{
      setNoSel();
     
      navPageList.splice(seq, 0, navPageBo);
      changeAllseq(navPageList);
      }
      NavPageStore.refreshData(navPageList);
    }
    //var num=parseInt((mouseHeight-60-15)/104);
    //console.log(num);
  }

}

export default NavPageService;
