import { h } from 'preact';
import NavPageService from './NavPageService';

function NavPageChildEle(props) {

  function eleoncontextmenu(event) {

    event.preventDefault(); //阻止事件
    NavPageService.navPageRClick(event);

  }

  return (
    <div id={props.id} seq={props.seq} className={props.className} onContextMenu={eleoncontextmenu} 
      onClick={NavPageService.navPageEleClick} onMouseDown={NavPageService.navPageElemousedown}
      onMouseUp={NavPageService.navPageElemouseup} >
      <div className="navPageLeft">{props.seq}</div>
      <div className="navPageContent">
        <img src={props.url}/>
      </div>
    </div>
  )
}

export default NavPageChildEle;
