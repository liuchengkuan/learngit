import { h, render, Component } from 'preact';
import NavPageService from './NavPageService';
import NavPageChildEle from './NavPageChildEle';

//导航面板布局类
class NavPage extends Component {
  componentDidMount() {
    setTimeout(NavPageService.init, 0)
  }

  render(props, state) {
    return (
      <div id="leftDiv" className="nav-page" onClick={NavPageService.navPageClick}>
        <div id="leftMainDiv" onmousemove={NavPageService.navPageElemousemove} onmouseup={NavPageService.leftMainDivmouseUp} >
          {
            Object.keys(props.navePageList).map((item) => {
              return <NavPageChildEle {...props} {...props.navePageList[item]} />
            })
          }
        </div>
      </div>
    )
  }
}

export default NavPage;
