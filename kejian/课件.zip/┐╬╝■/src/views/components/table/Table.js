import { h, render, Component } from 'preact';
import Transform from '../shape/Transform';
import TableService from './TableService';
class Table extends Component {
  //初始执行函数
  componentDidMount() {
    setTimeout(this.init, 0);
  }
  componentDidUpdate() {
    setTimeout(this.init, 0);
  }
  init = () => {
    /*var eleId = this.props.id;
    var txtEle = $('#eleId').children(".txt_AreaText");
    txtEle[0].style.height = 'auto';
    txtEle[0].crollTop = 0; 
    txtEle.css('width',this.props.tw);
    //txtEle.css('height',this.props.th);
    txtEle.css('height', txtEle[0].scrollHeight + 'px');*/
    this.props.isCreate?TableService.createTableByStoreData(this.props):null;

  }

  onResizeStop = (data) => {
    let tableId = this.props.id + "table";
    let tableDom = $('#'+tableId);
    let tableDomH = tableDom.height() + 1;
    let tableDOmW = tableDom.width() + 1;
    let resizeH = this.props.height;
    let resizeW = this.props.width;
    if(tableDomH > resizeH || tableDOmW > resizeW){
      this.props.onUpdataCanvasById(this.props.id, {
        height: tableDomH,
        width: tableDOmW
      })
    }
  }

  render(props) {
    return (
      <Transform {...props} hideRotate={true} dragPadding="6" onResizeStop={this.onResizeStop}>
        <table class="tableView" id={ props.id + "table" } style={ { width: props.width, height: props.height,opacity:props.opacity} }>
        </table>
      </Transform>
    )

  }
}
export default Table;