var reg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/;
/*RGB颜色转换为16进制*/
function colorHex (color){
     var that = color;
     if(/^(rgb|RGB)/.test(that)){
          var aColor = that.replace(/(?:\(|\)|rgb|RGB)*/g,"").split(",");
          var strHex = "#";
          for(var i=0; i<aColor.length; i++){
               var hex = Number(aColor[i]).toString(16);
               if(hex === "0"){
                    hex += hex;    
               }
               strHex += hex;
          }
          if(strHex.length !== 7){
               strHex = that;    
          }
          return strHex;
     }else if(reg.test(that)){
          var aNum = that.replace(/#/,"").split("");
          if(aNum.length === 6){
               return that;    
          }else if(aNum.length === 3){
               var numHex = "#";
               for(var i=0; i<aNum.length; i+=1){
                    numHex += (aNum[i]+aNum[i]);
               }
               return numHex;
          }
     }else{
          return that;    
     }
};

function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}

//颜色列表
var colorArr = [
                  "#000000","#000000","#000000","#003300","#006600","#009900","#00CC00","#00FF00","#330000","#333300","#336600","#339900","#33CC00","#33FF00","#660000","#663300","#666600","#669900","#66CC00","#66FF00",
                  "#333333","#000000","#000033","#003333","#006633","#009933","#00CC33","#00FF33","#330033","#333333","#336633","#339933","#33CC33","#33FF33","#660033","#663333","#666633","#669933","#66CC33","#66FF33",
                  "#666666","#000000","#000066","#003366","#006666","#009966","#00CC66","#00FF66","#330066","#333366","#336666","#339966","#33CC66","#33FF66","#660066","#663366","#666666","#669966","#66CC66","#66FF66",
                  "#999999","#000000","#000099","#003399","#006699","#009999","#00CC99","#00FF99","#330099","#333399","#336699","#339999","#33CC99","#33FF99","#660099","#663399","#666699","#669999","#66CC99","#66FF99",
                  "#CCCCCC","#000000","#0000CC","#0033CC","#0066CC","#0099CC","#00CCCC","#00FFCC","#3300CC","#3333CC","#3366CC","#3399CC","#33CCCC","#33FFCC","#6600CC","#6633CC","#6666CC","#6699CC","#66CCCC","#66FFCC",
                  "#FFFFFF","#000000","#0000FF","#0033FF","#0066FF","#0099FF","#00CCFF","#00FFFF","#3300FF","#3333FF","#3366FF","#3399FF","#33CCFF","#33FFFF","#6600FF","#6633FF","#6666FF","#6699FF","#66CCFF","#66FFFF",
                  "#FF0000","#000000","#990000","#993300","#996600","#999900","#99CC00","#99FF00","#CC0000","#CC3300","#CC6600","#CC9900","#CCCC00","#CCFF00","#FF0000","#FF3300","#FF6600","#FF9900","#FFCC00","#FFFF00",
                  "#00FF00","#000000","#990033","#993333","#996633","#999933","#99CC33","#99FF33","#CC0033","#CC3333","#CC6633","#CC9933","#CCCC33","#CCFF33","#FF0033","#FF3333","#FF6633","#FF9933","#FFCC33","#FFFF33",
                  "#0000FF","#000000","#990066","#993366","#996666","#999966","#99CC66","#99FF66","#CC0066","#CC3366","#CC6666","#CC9966","#CCCC66","#CCFF66","#FF0066","#FF3366","#FF6666","#FF9966","#FFCC66","#FFFF66",
                  "#FF0000","#000000","#990099","#993399","#996699","#999999","#99CC99","#99FF99","#CC0099","#CC3399","#CC6699","#CC9999","#CCCC99","#CCFF99","#FF0099","#FF3399","#FF6699","#FF9999","#FFCC99","#FFFF99",
                  "#00FFFF","#000000","#9900CC","#9933CC","#9966CC","#9999CC","#99CCCC","#99FFCC","#CC00CC","#CC33CC","#CC66CC","#CC99CC","#CCCCCC","#CCFFCC","#FF00CC","#FF33CC","#FF66CC","#FF99CC","#FFCCCC","#FFFFCC",
                  "#FF00FF","#000000","#9900FF","#9933FF","#9966FF","#9999FF","#99CCFF","#99FFFF","#CC00FF","#CC33FF","#CC66FF","#CC99FF","#CCCCFF","#CCFFFF","#FF00FF","#FF33FF","#FF66FF","#FF99FF","#FFCCFF","#FFFFFF"
               ];

/**
    面板类
*/
class ColorPicker {
    selectColor; //选择的颜色
    
    /**
      构造函数
      @color 面板初始化颜色
    */
    constructor(color = '#ffffff') {
      this._render();
      this.selectColor = color;
      this._displayColor();
      this._bindEvent();
    }
    
    //生成颜色版
    _render() {
        //如果不存在，创建div
        var c = [];
        c.push('<div id="new-color-picker">');
        c.push('  <div class="selectColorRow">');
        c.push('    <div id="new-color-picker-dislpay" > </div>');
        c.push('     <div id="new-color-picker-input"> ');
        c.push('       <input type="text" name="" />  ');
        c.push('    </div>');
        c.push('   </div>');

        c.push('   <div class="simpleColorChooser" >');
        var l = colorArr.length;
        for(let i=0;i<l;i++)
        {
           c.push(`     <div class="simpleColorCell" style="background:${colorArr[i]};" ></div>`);
        }
        c.push('   </div>');    
        c.push('</div>'); 
        this.$colorPickerDiv = $(c.join(''));
    }

    /**
     显示颜色版
    */
    show(e) {
       var _this = this;
       // console.log(e.pageX,e.pageY);
       var positin = this.getPosition(e);
       $('body').append(this.$colorPickerDiv);
       //显示位置
       this.$colorPickerDiv.css({
           position:'fixed',
           left:positin.x,
           top:positin.y
       });
       this.$colorPickerDiv.show(function(){ //显示之后进行监听
            $(document).bind("click",_this.blurHide);
       });
    }

    /**
       销毁对象
    */
    destroy() {
       $('.simpleColorCell',this.$colorPickerDiv).unbind(); //取消所有的事件
       this.$colorPickerDiv.remove();
       $(document).unbind("click");
    }
    
    /**
      根据事件获取鼠标定位
    */
    getPosition(e) {
      return {
           x:e.pageX,
           y:e.pageY
      }
    }

    /**
      点击颜色板以外的区域隐藏颜色板
      @para e 事件
      @author ymx
      @date 2017-3-29
    */
    blurHide = (e)=>{  //=>改变this指向 
          // console.log('this is    ',this);
          var target = $(getEvetTarget(e));  
          if(target.closest(this.$colorPickerDiv).length == 0){
             this._hide();
          } 
    }

    //隐藏颜色版
    _hide  () {
        // console.log('this is    ',this);
        // var _this = this;
        this.destroy();
    }

    /**
      绑定一些事件
    */
    _bindEvent = ()=>{
       var _this = this; //this指向问题
       $('.simpleColorCell',_this.$colorPickerDiv).mouseover(function(){
            _this.selectColor = $(this).css('background-color');
            _this._displayColor();
       });
    };

    /**
      显示颜色和颜色值
    */
    _displayColor = ()=>{
        $('#new-color-picker-dislpay',this.$colorPickerDiv).css('background-color',this.selectColor);
        $('#new-color-picker-input input',this.$colorPickerDiv).val(colorHex(this.selectColor));
    }

    /**
     添加事件
  */
  on(eventType, callBack) {
    let _this = this;
    typeof callBack === 'function' && 
    //点击某个颜色后执行回调函数
    $('.simpleColorCell',_this.$colorPickerDiv).on(eventType,function(e){
          _this._hide();
          callBack(colorHex(_this.selectColor));//回调
    })
  }

  /**
    取消事件
  */
  off(eventType) {
    let _this = this;
    typeof callBack === 'function' && 
    $('.simpleColorCell',_this.$colorPickerDiv).off(eventType);
  }

}

//导出对外界接口，相当于public,其余的是private
export default ColorPicker;