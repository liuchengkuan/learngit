import EditAreaStore from 'stores/EditAreaStore';
import CpUtil from 'utils/CpUtil';
import CpConst from 'utils/CpConst';


// 修正了宽高
function xz_add(value) {
  return value + CpConst.txt_help_width * 2;

}

function xz_del(value) {
  return value - CpConst.txt_help_width * 2;

}
/**
 * 文本框业务类
 * @auto 庄召
 */
const TxtService = {

  //移动改变大小的时候。
  setTxtSizeByTransform: function (tempData) {
    var id = tempData.id;
    var paretEle = $('#' + id);
    var currTxtAreaEle = paretEle.children(".txt_AreaText");
    //var len = currTxtAreaEle.width();

    var targetW = xz_del(tempData.width);
    var targetH = xz_del(tempData.height);
    paretEle.width(targetW);
    paretEle.height(targetH);


    var text = currTxtAreaEle.val();
    //console.log("当前值:"+text);
    var len = CpUtil.findvisualLength(text, currTxtAreaEle);
    if (len <= targetW) {
      var tempLen = len + 20;
      if (tempLen < 20) {
        tempLen = 20;
      }

      if (tempLen > targetW - CpConst.txt_help_width) {
        tempLen = targetW - CpConst.txt_help_width;
      }

      currTxtAreaEle.css('width', tempLen + 'px');
      tempData.tw = tempLen;
    } else {
      var tempLen = targetW - CpConst.txt_help_width;
      currTxtAreaEle.css('width', tempLen + 'px');
    }
    console.log(currTxtAreaEle);
    currTxtAreaEle.css('height', 'auto');
    currTxtAreaEle[0].scrollTop = 0;

    currTxtAreaEle.css('height', currTxtAreaEle[0].scrollHeight + 'px');
    tempData.th = currTxtAreaEle[0].scrollHeight;
    //tempData.height = xz_add(paretEle.height());
  },
  //设置文本框宽和高
  setTxtSize: function (currTxtAreaEle, paretEle) {

    try {
      var id = paretEle.attr('id');
      var tempData = EditAreaStore.getCanvasById(id);


      //小于父亲 
      var text = currTxtAreaEle.val();
      //console.log("当前值:"+text);
      var len = CpUtil.findvisualLength(text, currTxtAreaEle);
      // console.log("文本长度:"+len);
      var txtParntWidth = paretEle.css('width').replace('px', '');
      if (len <= txtParntWidth) {
        // console.log("改变大小:"+CpConst.txt_help_width);

        var tempLen = len + 20;
        if (tempLen < 20) {
          tempLen = 20;
        }

        if (tempLen > txtParntWidth - CpConst.txt_help_width) {
          tempLen = txtParntWidth - CpConst.txt_help_width;
        }

        currTxtAreaEle.css('width', tempLen + 'px');
        // console.log("目标宽度:"+tempLen);
        tempData.tw = tempLen;
        tempData.width = xz_add(paretEle.width());

      }
      console.log(currTxtAreaEle);
      currTxtAreaEle.css('height', 'auto');

      //currTxtAreaEle[0].scrollTop = 0;

      currTxtAreaEle.css('height', currTxtAreaEle[0].scrollHeight + 'px');
      tempData.th = currTxtAreaEle[0].scrollHeight;

      // 文本输入区域笔外网区域小了.解决拖动改变大小后，父窗体不跟随子窗体大小变化问题，原因不清楚
      if (paretEle.height() < currTxtAreaEle.height()) {
        paretEle.height(currTxtAreaEle.height());
      }
      tempData.height = xz_add(paretEle.height());
      //console.log("tempData.height:"+tempData.height +">>"+currTxtAreaEle.height());

      EditAreaStore.updataCanvasById(id, tempData);
    } catch (e) {
      alert("setTxtSize异常:" + e);
    }
  },

  command: function (commandName, commandState, commandValue) {
    if (commandState == null) {
      commandState = "false";
    }

    document.execCommand(commandName, commandState, commandValue);

  },

  //粗体
  setBold: function () {
    document.execCommand("Bold", "false", null);
  },
  //下划线
  setUnderline: function () {
    document.execCommand("Underline ", "false", null);
  },
  //斜体
  setItalic: function () {
    document.execCommand("Italic");
  },

  //字体大小
  setFontSize: function (fontSize) {
    console.log(fontSize);
    if(fontSize>7){
      fontSize=7;
    }
    document.execCommand('fontSize', false, fontSize);
  },
  //字体颜色
  setForecolor: function (color) {
    document.execCommand('forecolor', false, color);
  },
  //字体背景颜色
  setBackColor: function (color) {
    document.execCommand('BackColor', false, color);
  },

  //项目符号
  //insertOrderedList  insertUnorderedList
  setOrderedList: function (type) {
    document.execCommand(type);
  },

  //水平对齐
  //justifyLeft justifyRight justifyFull  justifyCenter
  setjustify: function (type) {
    document.execCommand(type);
  },

  //增加缩进
  setIndent: function () {
    document.execCommand('Indent');
  },
  //减少缩进
  setOutdent: function () {
    document.execCommand('Outdent');
  },
  setFontName:function(value){
    document.execCommand('fontname', false, value);
  },
  demo: function () {



    // document.execCommand('selectAll');

    // document.execCommand("Bold","false",null);
    //document.execCommand('Italic');

    //TxtService.command("selectAll");
    //TxtService.command('Italic');
    //TxtService.command('Bold');

    //document.execCommand("forecolor", false, 'green');

    //TxtService.command('insertOrderedList');
    //TxtService.command('insertUnorderedList');
    //TxtService.command('Indent'); 
    // TxtService.command('delete');
    // TxtService.command('BackColor', false, 'red');
    // TxtService.command('fontname', false, 'serif');
    //console.log(777);
    document.execCommand('fontSize',false,2);
    // TxtService.setBold();
    //TxtService.setjustify('justifyRight');


  }


}
export default TxtService;
