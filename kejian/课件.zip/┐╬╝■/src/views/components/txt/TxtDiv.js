import { h, render, Component } from 'preact';
import Transform from 'views/components/shape/Transform';
import TxtService from './TxtService';
import CpRundata from 'utils/CpRundata';
import TxtDivBase from 'views/components/txt/TxtDivBase';

class TxtDiv extends Component {


  //初始执行函数
  componentDidMount() {

  }

  init = () => {

  }



  render() {
    return (
      <Transform {...this.props} hideRotate={true} dragPadding="6" onResizeStop={this.onResizeStop}>
        <TxtDivBase {...this.props} />
      </Transform>

    )

  }

}

export default TxtDiv;
