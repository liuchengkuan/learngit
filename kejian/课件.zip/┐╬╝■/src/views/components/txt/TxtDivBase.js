import { h, render, Component } from 'preact';
import Transform from '../shape/Transform';
import TxtService from './TxtService';
import CpRundata from 'utils/CpRundata';
import EditAreaStore from 'stores/EditAreaStore';

class TxtDivBase extends Component {
  //初始执行函数
  componentDidMount() {
    setTimeout(this.init, 0);
  }
 componentDidUpdate() {
    setTimeout(this.init, 0);
  }
  init = () => {
    var eleId = this.props.id;
    var parentDivEle = $("#"+eleId+"div");
    if(this.props.isSelected){
      parentDivEle.focus();
    }
    if(this.props.txtContent!=null){
        parentDivEle.html(this.props.txtContent);
		    //将输入框的光标移动到最后
       if($.support.msie){
          var range = document.selection.createRange();
          this.last = range;
          range.moveToElementText(parentDivEle[0]);
          range.select();
          document.selection.empty(); //取消选中
      }else{
          var range = document.createRange();
          range.selectNodeContents(parentDivEle[0]);
          range.collapse(false);
          var sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(range);
      }
       this.props.txtIsblur?parentDivEle.blur():null;
    }
  }


  getEvetTarget = (event) => {
    return event.srcElement ? event.srcElement : event.target;
  }


  onmouseDown = (event) => {
    // event.preventDefault();
    event.stopPropagation();
    if(this.props.isSelected){
      return;
    }
    var updateData={
        txtIsblur:false
    }
    EditAreaStore.updataDataById(this.props.id,updateData);
    EditAreaStore.selectCanvas(this.props.id);
  }

  onmouseUp = (event) => {
    // event.preventDefault(); //阻止事件
    //event.stopPropagation();

  }
  onmouseMove = (event) => {
    //event.preventDefault(); //阻止事件
    //event.stopPropagation();

  }
  oninput = (event) =>{
    var ele=$(this.getEvetTarget(event));
    var divContent=ele.html();
    var scrollHeight=ele[0].scrollHeight;
    var height=ele.height();
    if(scrollHeight>height){
      height=scrollHeight;
      ele.parent().height(scrollHeight);
      ele.prev().height(scrollHeight);
      ele.next().height(parseInt(scrollHeight)+12)
      ele.height(scrollHeight);
    }
    var updateData={
      txtIsblur:false,
      txtContent:divContent,
      height:height
    }
    EditAreaStore.updataDataById(this.props.id,updateData);
  }
  onBlur= () =>{
    var updateData={
        txtIsblur:true
    }
    EditAreaStore.updataDataById(this.props.id,updateData);
  }
  render() {
    return (
      <div id={this.props.id + "div"} oninput={this.oninput} onBlur={this.onBlur} className="txtDiv" contenteditable="true" onMouseDown={this.onmouseDown} onMouseUp={this.onmouseUp} onmouseMove={this.onmouseMove} style={{ width: this.props.width, height: this.props.height,background:this.props.fill}}>
      </div>
    )
  }
}

export default TxtDivBase;
