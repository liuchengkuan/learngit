import { h, render, Component } from 'preact';
import Transform from './Transform';
import TxtService from './TxtService';
import CpRundata from '../../../utils/CpRundata';

class TxtBase extends Component {

  //this.props //获取当前传递过来的数据

  //初始执行函数
  componentDidMount() {
    setTimeout(this.init, 0)
  }

  init = () => {
    /*var eleId = this.props.id;
    var txtEle = $('#eleId').children(".txt_AreaText");
    txtEle[0].style.height = 'auto';
    txtEle[0].crollTop = 0; 
    txtEle.css('width',this.props.tw);
    //txtEle.css('height',this.props.th);
    txtEle.css('height', txtEle[0].scrollHeight + 'px');*/

    var eleId = this.props.id;
    var parentDivEle = $('#' + eleId);

    //边框没有计算在内
    //currTxtAreaEle.css('width', this.props.width + 'px');
    //currTxtAreaEle.css('height', this.props.height + 'px');

    parentDivEle[0].style.width = this.props.width + 'px';
    parentDivEle[0].style.height = this.props.height + 'px';
  }


  getEvetTarget = (event) => {
    return event.srcElement ? event.srcElement : event.target;
  }


  oninput = (event) => {
    //console.log("come  in"+CpConst.txt_help_width);
    event.preventDefault(); //阻止事件
    event.stopPropagation();
    var currTxtAreaEle = $(this.getEvetTarget(event));
    var paretEle = currTxtAreaEle.parent();
    TxtService.setTxtSize(currTxtAreaEle, paretEle);
  }
  onmousemove = (event) => {
    //event.preventDefault(); //阻止事件
    event.stopPropagation();

  }

  onmouseDown = (event) => {
    event.stopPropagation();
    CpRundata.txtDownByMove = true;
    this.props.onSelectCanvas(this.props.id);
    CpRundata.shapeOriginalData = [];
    let tempData = this.props.getCanvasBySelected();
    for (let i in tempData) {
      CpRundata.shapeOriginalData.push({ ...tempData[i] });
    }
  }

  onmouseDownByDiv = (event) => {
    event.stopPropagation();
    CpRundata.txtDownByMove = false;
    this.props.onSelectCanvas(this.props.id);
    CpRundata.shapeOriginalData = [];
    let tempData = this.props.getCanvasBySelected();
    for (let i in tempData) {
      CpRundata.shapeOriginalData.push({ ...tempData[i] });
    }
  }

  onmouseUp = (event) => {
    CpRundata.txtDownByMove = false;
  }



  render() {
    return (
      <div id={this.props.id} className="txt_Div" onMouseUp={this.onmouseUp} onMouseDown={this.onmouseDownByDiv}>
        <textarea contenteditable="true" class="txt_AreaText" style={{ fontWeight: this.props.fontWeight }}
          onInput={this.oninput} onMouseMove={this.onmousemove} onMouseDown={this.onmouseDown} onMouseUp={this.onmouseUp} >
        </textarea>
      </div>
    )

  }

}

export default TxtBase;
