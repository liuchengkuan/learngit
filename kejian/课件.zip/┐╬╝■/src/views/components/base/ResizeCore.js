/**
 * 调整大小类
 *
 * @module  ResizeCore
 * 
 * @author Ma Junbao <mlive@live.cn>
 */

import { h } from 'preact';
import DragCore from './DragCore';

function ResizeCore(props) {
  const RESIZE_POINTS = "topLeft topCenter topRight centerLeft centerRight bottomLeft bottomCenter bottomRight";

  // 八个点样式
  let style = {
    left: -1,
    top: -1,
    width: parseInt(props.width) + 'px',
    height: parseInt(props.height) + 'px',
    position: 'absolute',
    border: props.hideResizeStroke == 'true' ? '' : '1px solid #95B6FF'
  }

  // 配置八个点
  let resizePoints = props.resizePoints || RESIZE_POINTS

  let resizeHandleStyle = {
    width: 5 + 'px',
    height: 5 + 'px',
    border: 1 + 'px solid #0079FF',
    backgroundColor: '#FEFEFF',
    position: 'absolute',
    zIndex: 1
  }

  let resizeHandleStyleAbsolute = -3 + 'px';

  let returnDataback = {
    width: parseInt(props.width),
    height: parseInt(props.height),
    x: props.x,
    y: props.y
  }

  let returnData = (data) => {
    return data;
  }

  let onResizeStart = (data) => {}

  let onResize = (data) => {
    typeof props.onResize == 'function' && props.onResize(data)
  }


  let onTopLeft = (data) => {
    handleTop(data);
    handleLeft(data);
    handleResize(data);
  }

  let onTopCenter = (data) => {
    handleTop(data);
    handleResize(data);
  }

  let onTopRight = (data) => {
    handleTop(data);
    handleRight(data);
    handleResize(data);
  }

  let onCenterRight = (data) => {
    handleRight(data);
    handleResize(data);
  }

  let onCenterLeft = (data) => {
    handleLeft(data)
    handleResize(data);
  }

  let onBottomLeft = (data) => {
    handleBottom(data);
    handleLeft(data);
    handleResize(data);
  }

  let onBottomCenter = (data) => {
    handleBottom(data)
    handleResize(data);
  }

  let onBottomRight = (data) => {
    handleBottom(data);
    handleRight(data);
    handleResize(data);
  }

  let onMove = (data) => {
    handleMove(data);
    typeof props.onMove == 'function' && props.onMove(data);
  }

  let onMouseDown = () => {
    typeof props.onMouseDown == 'function' && props.onMouseDown(props.id);
  }

  // Top Right Bottom Left Move handle
  let handleTop = (data) => {
    data.top = true;
  }
  let handleRight = (data) => {
    data.right = true;
  }
  let handleBottom = (data) => {
    data.bottom = true;
  }
  let handleLeft = (data) => {
    data.left = true;
  }

  let handleMove = (data) => {}

  let handleResize = (data) => {
    typeof props.onResize == 'function' && props.onResize(returnData(data));
  }

  let handleResizeStop = (data) => {
    typeof props.onResizeStop == 'function' && props.onResizeStop(returnData(data));
  }

  let handleResizeStart = (data) => {
    typeof props.onResizeStart == 'function' && props.onResizeStart(returnData(data));
  }

  let handleUpdataLayoutCursor = (cursor = 'default') => {
    props.onUpdataLayout({ editAreaCursor: cursor })
  }

  let _hasPoint = (point) => {
    if (resizePoints == RESIZE_POINTS) {
      return true
    };

    if (resizePoints.indexOf(point) > -1) {
      return true
    };

    return false;
  }

  return (
    props.isSelected ?
    <div style={style} onMouseDown={(e)=>{e.stopPropagation()}}>
      {_hasPoint('topLeft') ?
        <DragCore onDrag={onTopLeft} onDragStop={handleResizeStop} onDragStart={handleResizeStart}>
          <div style={{...resizeHandleStyle, ...{cursor: 'nwse-resize', top: resizeHandleStyleAbsolute, left: resizeHandleStyleAbsolute}}}></div>
        </DragCore> :
        null
      }
      {_hasPoint('topCenter') ?
        <DragCore onDrag={onTopCenter} onDragStop={handleResizeStop} onDragStart={handleResizeStart}>
          <div  style={{...resizeHandleStyle, ...{cursor: 'ns-resize', top: resizeHandleStyleAbsolute, left: '50%', marginLeft: resizeHandleStyleAbsolute}}}></div>
        </DragCore> :
        null
      }
      {_hasPoint('topRight') ?
        <DragCore onDrag={onTopRight} onDragStop={handleResizeStop} onDragStart={handleResizeStart}>
          <div style={{...resizeHandleStyle, ...{cursor: 'nesw-resize', top: resizeHandleStyleAbsolute, right: resizeHandleStyleAbsolute}}}></div>
        </DragCore> :
        null
      }
      {_hasPoint('centerLeft') ?
        <DragCore onDrag={onCenterLeft} onDragStop={handleResizeStop} onDragStart={handleResizeStart}>
          <div style={{...resizeHandleStyle, ...{cursor: 'ew-resize', top: '50%', marginTop: resizeHandleStyleAbsolute, left: resizeHandleStyleAbsolute}}}></div>
        </DragCore> :
        null
      }
      {_hasPoint('centerRight') ?
        <DragCore onDrag={onCenterRight} onDragStop={handleResizeStop} onDragStart={handleResizeStart}>
          <div style={{...resizeHandleStyle, ...{cursor: 'ew-resize', top: '50%', marginTop: resizeHandleStyleAbsolute, right: resizeHandleStyleAbsolute}}}></div>
        </DragCore> :
        null
      }
      {_hasPoint('bottomLeft') ?
        <DragCore onDrag={onBottomLeft} onDragStop={handleResizeStop} onDragStart={handleResizeStart}>
          <div style={{...resizeHandleStyle, ...{cursor: 'nesw-resize', bottom: resizeHandleStyleAbsolute, left: resizeHandleStyleAbsolute}}}></div>
        </DragCore> :
        null
      }
      {_hasPoint('bottomCenter') ?
        <DragCore onDrag={onBottomCenter} onDragStop={handleResizeStop} onDragStart={handleResizeStart}>
          <div style={{...resizeHandleStyle, ...{cursor: 'ns-resize', bottom: resizeHandleStyleAbsolute, left: '50%', marginLeft: resizeHandleStyleAbsolute}}}></div>
        </DragCore> :
        null
      }
      {_hasPoint('bottomRight') ?
        <DragCore onDrag={onBottomRight} onDragStop={handleResizeStop} onDragStart={handleResizeStart}>
          <div style={{...resizeHandleStyle, ...{cursor: 'nwse-resize', bottom: resizeHandleStyleAbsolute, right: resizeHandleStyleAbsolute}}}></div>
        </DragCore> :
        null
      }
    </div> : null
  );

}
export default ResizeCore;
