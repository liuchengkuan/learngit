import { h, render, Component } from 'preact';

class Base extends Component {
  constructor() {

  }

  setID() { }
  getID() { }
  hasID() { }
  getType() { }
  focus() { }
  blur() { }
  isFocused() { }
  setZ() { }
  getZ() { }
  setClassName() { }
  getClassName() { }
  move() { }
  resize() { }


  render(props, state) {

  }
}