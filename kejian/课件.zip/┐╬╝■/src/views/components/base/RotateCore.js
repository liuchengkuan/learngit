import {h} from 'preact';
import DragCore from './DragCore';

export default function(props) {
  let style = {
    width: '10px',
    height: '10px',
    backgroundColor: 'red',
    position: 'absolute',
    top: (props.pointBottom * -1) || '-20px',
    left: '50%',
    marginLeft: '-5px',
    zIndex: 1
  };

  let onRotateStart = (data) => {
    typeof props.onRotateStart == 'function' && props.onRotateStart(data);
  }
  let onRotate = (data) => {
    typeof props.onRotate == 'function' && props.onRotate(data);
  }
  let onRotateEnd = (data) => {
    typeof props.onRotateEnd == 'function' && props.onRotateEnd(data);
  }

  return (
    props.isSelected ? <DragCore onDragStart={onRotateStart} onDrag={onRotate} onDragEnd={onRotateEnd}><div style={style}></div></DragCore> : null
  )

}