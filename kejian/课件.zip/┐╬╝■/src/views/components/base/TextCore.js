/**
 * 文本框业务核心操作类
 * @auto 庄召
 */
const TxtCore= {

    // 执行基本命令
    command : function (commandName, commandValue, callback) {
        var editor = this;
        var hooks;
        
        function commandFn() {
            if (!commandName) {
                return;
            }
            if (editor.queryCommandSupported(commandName)) {
                // 默认命令
                document.execCommand(commandName, false, commandValue);
            } else {
                // hooks 命令
               /* hooks = editor.commandHooks;
                if (commandName in hooks) {
                    hooks[commandName](commandValue);
                }*/
            }
        }
    },

    

}