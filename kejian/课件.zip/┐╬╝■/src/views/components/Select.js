function d() {
  console.log(2);
}