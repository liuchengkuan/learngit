import { h, render, Component, cloneElement } from 'preact';
import {addClass} from './base/Dom';

class RadioGroup extends Component {
  childrens = this.props.children;
  state = {
    radiolist: this.childrens.map((children)=>{
      return children.attributes && children.attributes.checked ? true : false;
    })
  }

  check = (i) => {
    let _radiolist = this.state.radiolist.map((item, i) => {
      return false;
    });
    _radiolist[i] = true;
    this.setState({
      radiolist: _radiolist
    })
  }

  render(props, state) {
    return (
      <div className={props.className}>
        {
          this.childrens.map((children, i) => {
            console.log(children)
            return cloneElement(children, {
              className: this.state.radiolist[i] ? addClass('', 'nihao') : null,
              onClick: ()=>{this.check(i)},
              key: i
            });
          })
        }
      </div>
    )
  }
}

export default RadioGroup;
