/**
 * 图形 - 矩形
 * 正方形
 * 长方形
 * 圆角矩形
 * 
 * @author Ma Junbao <mlive@live.cn>
 * @deprecated 2016-12-12
 */

import { h } from 'preact';
import Transform from './Transform';
import ShapeStyle from './ShapeStyle';

export default function Rect(props) {
  let boxStyle = {
    width: props.width,
    height: props.height,
    opacity: props.opacity,
    id: props.id
  }
  let shapeStyle = {
    fill: props.fill,
    stroke: props.stroke,
    'stroke-width': props.strokeWidth,
    rx: props.strokeRadius,
    ry: props.strokeRadius
  }
  let shapeEle;

  return (
    <Transform {...props}>
      <ShapeStyle boxStyle={boxStyle} shapeStyle={shapeStyle}>
        <rect width={boxStyle.width} height={boxStyle.height} />
        {/*<circle cx="75" cy="75" r="75" />*/}
      </ShapeStyle>
    </Transform>
  )
}