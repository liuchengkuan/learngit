import { h } from 'preact';
import Transform from './Transform';

function Cross(props) {
  let blank = 1 / 6; // 四周留白

  let ow = props.width;
  let oh = props.height;
  let blankX = blank * ow;
  let blankY = blank * oh;
  let x1 = blankX;
  let y1 = blankY;
  let x2 = props.width - blankX;
  let y2 = props.height - blankY;
  let style = {
    position: 'absolute',
    opacity: props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={props.width} height={props.height} style={style}>
        <path d={`M${x1},${y1} L${x2},${y2} M${x2},${y1} L${x1},${y2}`} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle} />
      </svg>
    </Transform>
  )
}

export default Cross;
