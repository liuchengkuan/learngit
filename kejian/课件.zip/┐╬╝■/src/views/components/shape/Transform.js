import { h } from 'preact';
import DragCore from '../base/DragCore';
import ResizeCore from '../base/ResizeCore';
import RotateCore from '../base/RotateCore';
import CpRundata from 'utils/CpRundata';
import CpConst from 'utils/CpConst';
import TxtService from '../txt/TxtService';
import EditAreaStore from 'stores/EditAreaStore';
import TableService from '../table/TableService';
/**
 * 用于图形、图像的大小、位置、角度、缩放等转换
 *
 * @author Ma Junbao <mlive@live.cn>
 * @date 2017-02-22
 */
function Transform(props) {
  const maxAngle = CpConst.maximum_angle;
  let dx = 0,
    dy = 0,
    mx = 0,
    my = 0;
  let elementOffset = {
    x: 0,
    y: 0
  };

  // 矫正缩放偏移量
  let _deviationScale = (data) => {
    if (props.layout.scale !== 1) {
      data.mx = data.mx / props.layout.scale;
      data.my = data.my / props.layout.scale;
    }
  }
  //给特图形重新赋宽度值
  let _deviationSpecialShapeWidth = (currData) => {
    if (currData.type == 'square' || currData.type == 'circle') {
      currData.width = currData.height;
    }
    if (currData.type == 'equilateralTriangle') {
      currData.width = (currData.height * Math.sqrt(3) * 2) / 3;
    }
  }
  //给特图形重新赋高度值
  let _deviationSpecialShapeHieght = (currData) => {
    if (currData.type == 'square' || currData.type == 'circle') {
      currData.height = currData.width;
    }
    if (currData.type == 'equilateralTriangle') {
      currData.height = (currData.width * Math.sqrt(3)) / 2;
    }
  }
  // 纠正旋转偏移量


  let setOldData = () => {
    CpRundata.shapeOriginalData = [];
    let startData = props.getCanvasBySelected();
    for (let i in startData) {
      CpRundata.shapeOriginalData.push({
        ...startData[i]
      });
    }
  }

  let onDragStart = (data) => {
    CpRundata.txtDownByMove = false; //这个元素按下，默认开启移动,文本元素已经阻止了事件，所以这儿可以怎么做。add by 20170207
    //开始拖拽时隐藏表格的选中div和清空选中数据
    if(props.type=="table"){
      TableService.clearTableChosedata();
    }
    props.onSelectCanvas(props.id);
    setOldData();
  }

  let onDrag = (data) => {
    if (CpRundata.txtDownByMove == true) {
      return;
    }
    let _selected = props.getCanvasBySelected();
    // 矫正偏移量
    _deviationScale(data);

    for (let i in CpRundata.shapeOriginalData) {
      let startData = CpRundata.shapeOriginalData[i];
      let currData = props.getCanvasById(startData.id);

      currData.x = startData.x + data.mx;
      currData.y = startData.y + data.my;

      props.onUpdataCanvasById(currData.id, currData);
    }
  }


  // x,y计算逻辑 给onResize时候用 
  let computeonResize = (data, startData, currData) => {

    typeof props.onResize == 'function' && props.onResize(data);

    let angle = props.rotate;

    if (data.left) {
      currData.width = startData.width - data.mx;
      if (currData.width >= 0) {
        // currData.x = startData.x + data.mx;
      } else {
        currData.width = Math.abs(currData.width);
      }
      _deviationSpecialShapeHieght(currData);
    }

    if (data.right) {
      currData.width = startData.width + data.mx;
      if (currData.width >= 0) {
      } else {
        currData.width = Math.abs(currData.width);
        currData.x = startData.x - currData.width;
      }
      _deviationSpecialShapeHieght(currData);
    }

    if (data.top) {
      currData.height = startData.height - data.my;
      if (currData.height >= 0) {
        currData.y = startData.y + data.my;
      } else {
        currData.height = Math.abs(currData.height);
      }
      _deviationSpecialShapeWidth(currData);
    }

    if (data.bottom) {
      currData.height = startData.height + data.my;
      if (currData.height >= 0) {
      } else {
        currData.height = Math.abs(currData.height);
        currData.y = startData.y - currData.height;
      }
      _deviationSpecialShapeWidth(currData);
    }

    props.onUpdataCanvasById(currData.id, currData);
  }

  let onResizeStart = (data) => {
    typeof props.onResizeStart == 'function' && props.onResizeStart(data);

    let _offset = $(".edit-area-canvas").offset();
    elementOffset.x = _offset.left;
    elementOffset.y = _offset.top;

    setOldData();
  }

  let onResizeStop = (data) => {
    typeof props.onResizeStop == 'function' && props.onResizeStop(data);
  }

  let onResize = (data) => {
    // 矫正偏移量
    _deviationScale(data);
    for (let i in CpRundata.shapeOriginalData) {
      let startData = CpRundata.shapeOriginalData[i];
      let currData = props.getCanvasById(startData.id);

      // 坐标和宽、高逻辑
      computeonResize(data, startData, currData);

      // 增加文本框特殊处理，add by zhuangzhao 20170207
      if (currData.type == 'txt') {
        if (currData == null) {
          console.log("当前对象currData is null");
        }
       // TxtService.setTxtSizeByTransform(currData);
      }

    }
  }

  let rotatePoint = {
    x: 0,
    y: 0
  }
  let rotateNode;

  let rotateNewPoint = {
    x: 0,
    y: 0
  }

  let onRotateStart = (data) => {
    props.onSelectCanvas(props.id);

    setOldData();
    rotateNode = $(data.node).parents('.cp-layer');
    let offset = rotateNode.offset();
    let id = rotateNode.attr('id');
    let canvas = EditAreaStore.getCanvasById(id);

    let editArea = {};
    editArea.x = $('.edit-area-canvas').offset().left;
    editArea.y = $('.edit-area-canvas').offset().top;

    // 修正偏移
    let dCanvas = {};
    dCanvas.x = canvas.x * props.layout.scale;
    dCanvas.y = canvas.y * props.layout.scale;
    dCanvas.width = canvas.width * props.layout.scale;
    dCanvas.height = canvas.height * props.layout.scale;

    rotatePoint.x = dCanvas.x + editArea.x + (dCanvas.width && dCanvas.width / 2);
    rotatePoint.y = dCanvas.y + editArea.y + (dCanvas.height && dCanvas.height / 2);

  }
  let onRotate = (data) => {

    let dx = data.x - rotatePoint.x
    let dy = data.y - rotatePoint.y;
    let radian = Math.atan2(dy, dx)
    let angle = radian * 180 / Math.PI + 90

    let id = rotateNode.attr('id');
    EditAreaStore.updataCanvasById(id, {
      rotate: angle
    })
  }
  let onRotateEnd = (data) => {
    console.log(rotateNode.offset());
  }

  let style = {
    position: 'absolute',
    width: props.width,
    height: props.height,
    left: props.x,
    top: props.y,
    transform: `rotate(${props.rotate}deg)`
  }

  let paddingStyleNum = props.dragPadding || 0;
  let pointBottom = 20 + paddingStyleNum;

  let paddingStyle = {
    position: 'absolute',
    width: props.width + paddingStyleNum * 2,
    height: props.height + paddingStyleNum * 2,
    border: paddingStyleNum ? '1px solid #ddd' : null,
    boxSizing: 'border-box',
    left: '-' + paddingStyleNum + 'px',
    top: '-' + paddingStyleNum + 'px',
    cursor: 'move',
    zIndex: '-100'
  }

  return (
    <div style={style} id={props.id} className="cp-layer">
      {!props.hideRotate ? <RotateCore {...props} pointBottom={pointBottom} onRotate={onRotate} onRotateStart={onRotateStart} onRotateEnd={onRotateEnd} /> : null}
      <ResizeCore {...props} onResize={onResize} onResizeStart={onResizeStart} onResizeStop={onResizeStop}></ResizeCore>
      <DragCore onDrag={onDrag} onDragStart={onDragStart}>
        {props.children}
      </DragCore>
      <DragCore onDrag={onDrag} onDragStart={onDragStart}>
        <div style={paddingStyle} ></div>
      </DragCore>
    </div>
  )
}

export default Transform;
