import { h } from 'preact';
import DragCore from '../base/DragCore';
import ResizeCore from '../base/ResizeCore';
import RotateCore from '../base/RotateCore';
import CpRundata from '../../../utils/CpRundata';
import CpConst from '../../../utils/CpConst';
import TxtService from './TxtService';
import EditAreaStore from '../../../stores/EditAreaStore';

function ShapeAction(props) {
  const maxAngle = CpConst.maximum_angle;
  let dx = 0,
    dy = 0,
    mx = 0,
    my = 0;
  let canvasOffset;

  let setOldData = () => {
    CpRundata.shapeOriginalData = [];
    let startData = props.getCanvasBySelected();
    for (let i in startData) {
      CpRundata.shapeOriginalData.push({...startData[i] });
    }
  }

  let onDragStart = (data) => {
    CpRundata.txtDownByMove = false; //这个元素按下，默认开启移动,文本元素已经阻止了事件，所以这儿可以怎么做。add by 20170207

    props.onSelectCanvas(props.id);
    setOldData();
  }

  let onDrag = (data) => {

    if (CpRundata.txtDownByMove == true) {
      return;
    }

    let _selected = props.getCanvasBySelected();
    for (let i in CpRundata.shapeOriginalData) {
      let startData = CpRundata.shapeOriginalData[i];
      let currData = props.getCanvasById(startData.id);
      currData.x = startData.x + data.mx;
      currData.y = startData.y + data.my;
      props.onUpdataCanvasById(currData.id, currData);
    }
  }


  // x,y计算逻辑 给onResize时候用 
  let computeonResize = (data, startData, currData) => {
    typeof props.onResize == 'function' && props.onResize(data);

    if (data.left) {
        currData.width = startData.width - data.mx;
      if (currData.width >= 0) {
        currData.x = startData.x + data.mx;
      } else {
        currData.width = Math.abs(currData.width);
      }
    }

    if (data.right) {
      currData.width = startData.width + data.mx;
      if (currData.width >= 0) {} else {
        currData.width = Math.abs(currData.width);
        currData.x = startData.x - currData.width;
      }
    }

    if (data.top) {
      currData.height = startData.height - data.my;
      if (currData.height >= 0) {
        currData.y = startData.y + data.my;
      } else {
        currData.height = Math.abs(currData.height);
      }

    }

    if (data.bottom) {
      currData.height = startData.height + data.my;
      if (currData.height >= 0) {} else {
        currData.height = Math.abs(currData.height);
        currData.y = startData.y - currData.height;
      }
    }

    props.onUpdataCanvasById(currData.id, currData);
  }

  let onResizeStart = (data) => {
    typeof props.onResizeStart == 'function' && props.onResizeStart(data);

    canvasOffset = $(".edit-area-canvas").offset();
    setOldData();
  }

  let onResize = (data) => {

    for (let i in CpRundata.shapeOriginalData) {
      let startData = CpRundata.shapeOriginalData[i];
      let currData = props.getCanvasById(startData.id);

      // 坐标和宽、高逻辑
      computeonResize(data, startData, currData);

      // 增加文本框特殊处理，add by zhuangzhao 20170207
      if (currData.type == 'txt') {
        if (currData == null) {
          console.log("当前对象currData is null");
        }
        TxtService.setTxtSizeByShapeAction(currData);
      }

    }
  }

  let rotatePoint = {x:0,y:0}
  let rotateNode;

  let rotateNewPoint = {x:0, y:0}

  let onRotateStart = (data) => {
    props.onSelectCanvas(props.id);
    
    setOldData();
    rotateNode = $(data.node).parents('.cp-layer');
    let offset = rotateNode.offset();
    let id  = rotateNode.attr('id');
    let canvas = EditAreaStore.getCanvasById(id);

    let canvasAbsolute={};
    canvasAbsolute.x = $('.edit-area-canvas').offset().left;
    canvasAbsolute.y = $('.edit-area-canvas').offset().top;

    console.log(canvas.x ,canvasAbsolute.x)
    rotatePoint.x = canvas.x + canvasAbsolute.x + (canvas.width && canvas.width/2);
    rotatePoint.y = canvas.y + canvasAbsolute.y + (canvas.height && canvas.height/2);
  }
  let onRotate = (data) => {
    
    let dx = data.x - rotatePoint.x
    let dy = data.y - rotatePoint.y;
    let radian = Math.atan2(dy, dx)
    let angle = radian * 180/Math.PI + 90

    let id  = rotateNode.attr('id');
    EditAreaStore.updataCanvasById(id, {rotate: angle})
  }
  let onRotateEnd = (data) => {
    console.log(rotateNode.offset());
  }

  let style = {
    position: 'absolute',
    width: props.width,
    height: props.height,
    left: props.x,
    top: props.y,
    transform: `rotate(${props.rotate}deg)`
  }
  
  return (
    <div style={style} id={props.id} className="cp-layer">
      <RotateCore onRotate={onRotate} onRotateStart={onRotateStart} onRotateEnd={onRotateEnd} />
      <ResizeCore {...props} onResize={onResize} onResizeStart={onResizeStart}></ResizeCore>
      <DragCore onDrag={onDrag} onDragStart={onDragStart}>
        {props.children}
      </DragCore>
    </div>
  )
}

export default ShapeAction;
