import {h} from 'preact';
import Transform from './Transform';

function EquilateralTriangle(props) {
  let oW = props.width;
  let oH = props.height;
  let oSW = props.strokeWidth;
  let acW = props.width;
  let acH = props.height;
  // 绘制边框
  if (oSW>0) {
    acW = oW + parseInt(oSW);
    acH = oH + parseInt(oSW);
  }
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props} width={oW} height={oH}>
      <svg width={oW} height={oH} style={style} viewBox={`0,0,${acW},${acH}`}>
        <polygon points={`${props.width/2},0 ${props.width},${props.height} 0,${props.height}`} fill={props.fill} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle}/>
      </svg>
    </Transform>
  )
}

export default EquilateralTriangle;