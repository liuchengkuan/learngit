import {h} from 'preact';
import Transform from './Transform';

function RoundedRectangle(props) {
  let oW = props.width;
  let oH = props.height;
  let oSW = props.strokeWidth;
  // 绘制边框
  if (oSW>0) {
    oW = oW + oSW;
    oH = oH + oSW;
  }
  let rotate = {
    width: 5,
    height: 5,
    position: 'absolute',
    let: '50%',
    top: '-10px',
    background: '#def'
  }
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={oW} height={oH} style={style}>
        <rect width="100%" height="100%"   rx="50" fill={props.fill} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle}/>
      </svg>
      <div style={rotate}>s</div>
    </Transform>
  )
}

export default RoundedRectangle;