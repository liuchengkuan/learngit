import {h} from 'preact';
import Transform from './Transform';

function Ellipse(props) {
  let oW = props.width;
  let oH = props.height;
  let oSW = props.strokeWidth;
  // 绘制边框
  if (oSW>0) {
    oW = oW + parseInt(oSW);
    oH = oH + parseInt(oSW);
  }
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={props.width} height={props.height} style={style}>
        <ellipse cx={props.width/2} cy={props.height/2} rx={props.width/2} ry={props.height/2} fill={props.fill} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle}/>
      </svg>
    </Transform>
  )
}

export default Ellipse;