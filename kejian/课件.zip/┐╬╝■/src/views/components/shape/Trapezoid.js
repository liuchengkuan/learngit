import {h} from 'preact';
import Transform from './Transform';

function Trapezoid(props) {
  let oxw = props.width;  // 已知x值
  let om  = props.width/4; //变量边长
  let oxa = 0; // x轴a坐标
  let oxb = 0; // x轴b坐标
  let oy = props.height;  //已知y值
   oxa = om;
   oxb =oxw-om;
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={props.width} height={props.height} style={style}>
        <polygon points={`${oxa},0 ${oxb},0 ${oxw},${oy} 0,${oy}`} fill={props.fill} stroke-dasharray={props.strokeStyle}/>
      </svg>
    </Transform>
  )
}

export default Trapezoid;