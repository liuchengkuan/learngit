import {h} from 'preact';
import Transform from './Transform';

function Hexagon(props) {
  let ow = 0; //边宽
  let oxa = 0; // x轴a坐标
  let oxb = 0; // x轴b坐标
  let oxw = props.width;  // 已知x值
  ow = oxw/2;      //根据勾股定理和已知等三角形高算出边长是已知x值的一半
  oxa = oxw/4;   //根据勾股定理和已知等三角形高
  oxb = (oxw-ow)/2+ow;   //根据勾股定理和已知等三角形高
  let oxy = props.height;  // 已知y值
  let oy1 = (Math.sqrt(3)/2);
  let oy2 = (Math.sqrt(3)/4);
  let oya = oxy*oy1 ; // y轴a坐标
  let oyb = oxy*oy2 ; // y轴a坐标
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={props.width} height={props.height} style={style}>
        <polygon points={`${oxa},0 ${oxb},0 ${props.width},${oyb} ${oxb},${oya} ${oxa},${oya} 0 ,${oyb}`} fill={props.fill} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle}/>
      </svg>
    </Transform>
  )
}

export default Hexagon