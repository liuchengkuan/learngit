import { h } from 'preact';
import { SHAPE_TYPE } from 'utils/CpConst';
import Rect from './Rect';
import RoundedRectangle from './roundedRectangle';
import TxtDiv from '../txt/TxtDiv';
import Circle from './Circle';
import Ellipse from './Ellipse';
import Triangle from './Triangle';
import IsocelesTriangle from './IsocelesTriangle';
import EquilateralTriangle from './EquilateralTriangle';
import Pentagon from './Pentagon';
import TestLine from './TestLine';
import Line from './Line';
import Rhombus from './rhombus';
import Oblique from './oblique';
import Hexagon from './hexagon';
import Start from './start';
import Trapezoid from './trapezoid';
import Right from './right';
import Cross from './cross';
import Table from '../table/Table';

const Shape = ({ children, ...props }) => {
  switch (props.type) {
    case 'rect': // 矩形
    case 'square': // 正方形
      return <Rect {...props} strokeRadius="0" />
    case 'roundedRectangle': // 圆角矩形
      return <Rect {...props} strokeRadius="20" />
    case 'circle':
      return <Circle {...props} />
    case 'ellipse':
      return <Ellipse {...props} />
    case 'triangle':
      return <Triangle {...props} />;
    case 'isocelesTriangle':
      return <IsocelesTriangle {...props} />;
    case 'equilateralTriangle':
      return <EquilateralTriangle {...props} />;
    case 'pentagon':
      return <Pentagon {...props} />;
    case 'rhombus':
      return <Rhombus {...props} />;
    case 'oblique':
      return <Oblique {...props} />;
    case 'hexagon':
      return <Hexagon {...props} />;
    case 'start':
      return <Start {...props} />;
    case 'trapezoid':
      return <Trapezoid {...props} />;
    case 'right':
      return <Right {...props} />;
    case 'cross':
      return <Cross {...props} />;
    case 'txt':
      return <TxtDiv {...props} />;
    case 'testLine':
      return <TestLine {...props} />
    case 'line':
      return <Line {...props} />
    case 'arrowLine':
      return <Line {...props} />
    case 'dArrowLine':
      return <Line {...props} />
    case 'table':
      return <Table {...props} />
    default:
      return null;
  }
}

export default Shape;