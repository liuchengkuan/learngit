import { h, render, Component } from 'preact';
import Transform from './Transform';

class Circle extends Component {
  _w;
  _h;
    
  state = {
    _x1: 0,
    _y1: this.props.height -2,
    _x2: this.props.width,
    _y2: 0 + 2,
    _resizePoints: 'bottomLeft topRight'
  }

  handleResize = (data) => {
    console.log(data);
    if (data.mx < 0 && data.mx + this._w < 0) {
      this.setState({
        _x1: 0,
        _y1: 0,
        _x2: this.props.width,
        _y2: this.props.height,
        _resizePoints: 'topLeft bottomRight'
      })
    }else if (data.my > 0 && data.my - this._h > 0) {
      this.setState({
        _x1: 0,
        _y1: 0,
        _x2: this.props.width,
        _y2: this.props.height,
        _resizePoints: 'topLeft bottomRight'
      })
    }else {
      this.setState({
        _x1: 0,
        _y1: this.props.height -2,
        _x2: this.props.width,
        _y2: 0 + 2,
        _resizePoints: 'bottomLeft topRight'
      })
    }
  }

  handleResizeStart = (data) => {
    this._w = this.props.width;
    this._h = this.props.height;
  }

  render(props, state) {
    return (
      <Transform {...this.props } resizePoints={state._resizePoints} hideResizeStroke="true" onResizeStart={ this.handleResizeStart } onResize={ this.handleResize }>
        <svg width={this.props.width} height={this.props.height} style={{position: 'absolute'}}>
          <line x1={state._x1} y1={state._y1} x2={state._x2} y2={state._y2} stroke="#ddd" stroke-width={this.props.strokeWidth} />
        </svg>
      </Transform>
    )
  }

}

export default Circle;
