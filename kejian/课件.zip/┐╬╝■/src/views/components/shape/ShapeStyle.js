/**
 * 图形公共样式
 * 
 * 边框
 * 填充
 * 阴影
 */

import { h, cloneElement } from 'preact';

export default function ShapeStyle(props) {
  let uuid = props.boxStyle.id.slice(-8);
  let { boxStyle, shapeStyle, children } = props;
  let strokeWidth = parseFloat(shapeStyle['stroke-width']);

  return (
    <svg height={boxStyle.height} width={boxStyle.width} style={{ position: 'absolute', opacity: boxStyle.opacity }}>
      <pattern id={`svg-style-${uuid}`} viewBox={`-${strokeWidth / 2}, -${strokeWidth / 2}, ${boxStyle.width + strokeWidth}, ${boxStyle.height + strokeWidth}`} preserveAspectRatio="none" patternUnits="objectBoundingBox" width="1" height="1">
        {cloneElement(children[0], { ...shapeStyle })}
      </pattern>
      {cloneElement(children[0], {
        'fill': `url(#svg-style-${uuid})`
      })}
    </svg>
  )
}