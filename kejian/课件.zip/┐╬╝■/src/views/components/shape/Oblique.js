import {h} from 'preact';
import Transform from './Transform';

function Oblique(props) {
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={props.width} height={props.height} style={style}>
        <polygon points={`${props.width*0.25},0 ${props.width},0 ${props.width*0.75},${props.height} 0,${props.height}`} fill={props.fill} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle}/>
      </svg>
    </Transform>
  )
}

export default Oblique;