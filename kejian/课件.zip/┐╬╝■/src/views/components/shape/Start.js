import { h } from 'preact';
import Transform from './Transform';

function Start(props) {

  let oxw = props.width; //x轴坐标
  let oyh = props.height; //y轴坐标
  let x1 = oxw / 2;
  let y1 = 0;

  let x2 = oxw / 2+oxw/9;
  let y2 = oyh / 2-oyh/9;

  let x3 = oxw;
  let y3 = oyh / 2-oyh/9;

  let x4 = oxw / 2+oxw/5;
  let y4 = oyh / 2+oyh/9;

  let x5 = oxw / 2+oxw/3;
  let y5 = oyh;

  let x6 = oxw / 2;
  let y6 = oyh / 2 + oyh/4;
  let x7 = oxw / 2 - oxw / 3;
  let y7 = oyh;

  let x8 = oxw / 2-oxw/5;
  let y8 = oyh / 2+oyh/9;

  let x9 = 0;
  let y9 = oyh / 2-oyh/9;

  let x10 = oxw / 2-oxw/9;
  let y10 = oyh / 2-oyh/9;
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={ props.width } height={ props.height } style={style}>
        <polygon points={ `${x1},${y1} ${x2},${y2} ${x3},${y3} ${x4},${y4} ${x5},${y5} ${x6},${y6} ${x7},${y7} ${x8},${y8} ${x9},${y9} ${x10},${y10}` } fill={ props.fill } stroke-dasharray={props.strokeStyle}/>
      </svg>
    </Transform>
  )
}

export default Start;