import {h} from 'preact';
import Transform from './Transform';

function Pentagon(props) {
  let oxw = props.width;   //x轴坐标
  let oyh = props.height;  //y轴坐标
  /*let radians = 36*Math.PI/180;
  let ow = oxw/(2*Math.cos(radians)) ;  //边长
  let oya =(Math.sin(radians)*oxw)/(2*Math.cos(radians)) ;  //根据正弦和余弦推出y轴坐标
  let oxa =(oxw-ow)/2; // x轴值
  let oxb = oxa+ow; // x轴值*/
  let x1 = oxw / 2;
  let y1 = 0;

  let x2 = oxw;
  let y2 = oyh / 2-oyh/9;

  let x3 = oxw / 2+oxw/3;
  let y3 = oyh;

  let x4 = oxw / 2 - oxw / 3;
  let y4 = oyh;

  let x5 = 0;
  let y5 = oyh / 2-oyh/9;
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={props.width} height={props.height} style={style}>
        <polygon points={`${x1},${y1} ${x2},${y2} ${x3},${y3} ${x4},${y4} ${x5},${y5}`} fill={props.fill} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle}/>
      </svg>
    </Transform>
  )
}

export default Pentagon;