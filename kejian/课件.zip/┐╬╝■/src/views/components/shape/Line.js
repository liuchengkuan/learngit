import {h} from 'preact';
import Transform from './Transform';
/**
* 线条组件
* @author 邬宗俊 
*/
function Line(props) {
let rightArrow = ()=>{
	 let td=[];
    for(var i=0;i<props.row;i++){
         td.push(<td style={tdStyle} onclick={EditAreaPageService.tableTdClick}><input style={inputStyle} className="hidden" onblur={EditAreaPageService.inputBlur}/><span style={span}></span></td>);
    };
    return td;
} 

let leftArrow= () =>{
			<defs>
				<marker id="arrowLeft"
        		markerUnits="strokeWidth"   
            	viewBox="0 0 12 12"   
            	refX="4"   
            	refY="6"   
            	orient="auto">
            	<path d="M 10 2 L 2 6 L 10 10 L 6 6 L 10 2" style={{fill: props.fill}}/>
        		</marker>
        	</defs>  
}
let line =() =>{
	var x2=props.width;
	if(props.strokeWidth>=5){
		x2=x2-(props.strokeWidth*(props.strokeWidth-3));
	}else if(props.strokeWidth>=3){
		x2=x2-(props.strokeWidth*(props.strokeWidth-1));
	}
	if(props.type=='line'){
		return (<line x1="0" y1={props.height/2} x2={props.width} y2={props.height/2}  stroke={props.fill} stroke-width={props.strokeWidth}/>)
	}else if(props.type=='arrowLine'){
		return (<line x1="0" y1={props.height/2} x2={x2-8} y2={props.height/2}  stroke={props.fill}  stroke-width={props.strokeWidth} marker-end="url(#arrowRight)"/>) 
	}else{
		return (<line x1="6" y1={props.height/2} x2={x2-8} y2={props.height/2}  stroke={props.fill} stroke-width={props.strokeWidth} marker-end="url(#arrowRight)" marker-start="url(#arrowLeft)"/>) 
	}
}
let svg = () =>{
	return (<svg width={props.width} height={props.height} style={{position: 'absolute'}}> 
		{rightArrow()}{leftArrow()}{line()}
	</svg>)
}
  return (
		<Transform {...props}>
      		{svg()}
    	</Transform>
  )
}

export default Line;