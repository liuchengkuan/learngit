import {h} from 'preact';
import Transform from './Transform';

function Right(props) {
  let ow=props.width;
  let oh=props.height;
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={props.width} height={props.height} style={style}>
        <path d={`M${ow*0.08},${oh*0.6} L${ow*0.4},${oh*0.83} L${ow*0.9},${oh/6}`} stroke={props.stroke} stroke-width={props.strokeWidth} fill="none" />
      </svg>
    </Transform>
  )
}

export default Right;