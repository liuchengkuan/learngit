import EditAreaStore from '../../../stores/EditAreaStore';
/**
 * 表格业务类
 * @auto 邬宗俊
 */
 //当秦表格的总行数
var tableCountRow;
//当前表格的总列数
var tableCountCol;
//表格数据存储对象
var tableEleBo;
var tableHeight;
var pianyi_val = 14;
var mincell_val = 10;// 单元格的最小宽度,拖动改变单元格大小用
var selectStartX;
var selectStartY;
var selectEndX;
var selectEndY;
// 移动的方向
var moveType;//移动方向
var isSizePre = false;
var isCellMoveSize = false; // 正在进行改变单元格大小的动作
var choseTd;
var currStartTd;// 开始点击的单元格
var moveRangeS;// 移动范围
var moveRangeE;// 移动范围结束
var moveStartx=null;// 记录开始位置
var moveStartY=null;//记录拖动的开始Y轴位置
//所有的td對象
var allTd;
var isTxtDown = false; //按下txt
var isTxtlMove = false; // 正在进行单元格移动
var startTxtMoveTd_ID=null;
var currMoveTxt_ID; //当前移上的单元格id
//选中的起始行
var startRow;
//选中的起始列
var startCol;
//选中的结束行
var endRow;
//选中的结束列
var endCol;
var chosedTdArr=[];
var editDomType="div";
function loadRightTableAttr(){
    var trHArr={};
    var tdWArr={};
    var heightValue;
    var widthValue;
    for(var i=0;i<chosedTdArr.length;i++){
        var choseTd=chosedTdArr[i];
        var id=choseTd.attr("id");
        //var tableEle=choseTd.parent().parent();
        var rowNum=getTdIdRowAndCol(id).row;
        var colNum=getTdIdRowAndCol(id).col;
        var trEle=choseTd.parent();
        var trHeight=trEle.height();
        var tdWidth=choseTd.outerWidth();
        heightValue=trHeight;
        widthValue=tdWidth;
        if(tableEleBo.isNewTable){
          tdWArr[tdWidth]={
            width:tdWidth
          }
          trHArr[trHeight]={
            height:trHeight
          }
          break;
        }
        rowNum==1&&tableEleBo.isCreate?trHeight=trHeight+1:null;
        //colNum==1&&tableCountCol>=6?tdWidth=tdWidth+1:null;
        var rowspan=getRowSpan(choseTd);
        var colspan=getColSpan(choseTd);
        if(colspan!=null){
          tdWidth=tdWidth/colspan;
          tdWArr[tdWidth]={
            width:tdWidth
          }
          widthValue=tdWidth;
        }else{
          tdWArr[tdWidth]={
            width:tdWidth
          }
        }
        if(rowspan!=null){
            for(var j=1;j<rowspan;j++){
              trEle=trEle.next();
              trHArr[trEle.height()]={
                height:trHeight
              }
            }
        }else{
          trHArr[trHeight]={
            height:trHeight
          }
        }
    }
    if(Object.keys(trHArr).length==1){
      $("#rTableRowHeight").val(heightValue);
    }else{
      $("#rTableRowHeight").val("——");
    }
    if(Object.keys(tdWArr).length==1){
      $("#rTableColWidth").val(widthValue);
    }else{
      $("#rTableColWidth").val("——");
    }
}
function getChoseDivXy(ele,flag){
        var tdX=ele.offset().left;
        var tdY=ele.offset().top;
        var tdWidth=ele.width();
        var tdHeight=ele.height();
        if(flag){
          selectStartX=tdX;
          selectStartY=tdY;
          selectEndX=tdX+tdWidth;
          selectEndY=tdY+tdHeight;
        }else{
          if((tdX+tdWidth)>selectEndX){
            selectEndX=tdX+tdWidth;
          }
          if((tdY+tdHeight)>selectEndY){
            selectEndY=tdY+tdHeight
          }
        }
}
function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}
//显示在选中td上方的div层
function showChoseTdDiv(){
  //console.log(selectStartX,selectStartY,selectEndX,selectEndY);
  $("#tableSelected").css("left",selectStartX);
  $("#tableSelected").css("top",selectStartY);
  $("#tableSelected").css("width",selectEndX-selectStartX+12);
  $("#tableSelected").css("height",selectEndY-selectStartY+7);
  $("#tableSelected").css('visibility', 'visible');
}
//改变td及td下的textarea的背景色
function changeColorForChose(ele){
  ele.css("background-color","blue");
  ele.find(""+editDomType).css("background-color","blue");
}
//根据td的ID获取行和列
function getTdIdRowAndCol(id){
  //console.log(id);
  var obj=new Object();
  obj.row=parseInt(id.split("_")[0]);
  obj.col=parseInt(id.split("_")[1]);
  return obj;
}
//获取rowspan的值
function getRowSpan(tdId){
  if(typeof(tdId.attr("rowspan"))!="undefined"){
    return parseInt(tdId.attr("rowspan"));
  }
  return null;
}
//获取colspan的值
function getColSpan(tdId){
  if(typeof(tdId.attr("colspan"))!="undefined"){
    return parseInt(tdId.attr("colspan"));
  }
  return null;
}
//隐藏表格拖拽的辅助样式
function hideHelp() {
  //$(document).unbind('mousemove');
  //$(document).unbind('mouseup');
  var moveHelpDiv = $('#moveHelpDiv');
  moveHelpDiv.hide();
  var mhEle = $('#moveHelp');
  mhEle.hide();
  moveHelpDiv.unbind('mousemove');
  moveHelpDiv.unbind('mouseup');
  mhEle.unbind('mouseup');
}

// 按下时候触发的操作，移动也会调用下
function tdMouseDownBody(e) {
  if (isSizePre == true) {
    var target = $(getEvetTarget(e))
    //console.log(target);
    if(target.is(""+editDomType)){
      target.css("cursor", "default");
      return;
    }
    //console.log();
    var offset = $(target).offset();
    var relativeX = (e.pageX - offset.left);
    var relativeY = (e.pageY - offset.top);
    //console.log("relativeX:"+relativeX);
    var tableEle=target.parent().parent();
    var tableX=parseInt(tableEle.offset().left);
    var tableY=parseInt(tableEle.offset().top);
    var tableEleWidth=parseInt(tableEle.width());
    var tableHeight=parseInt(tableEle.height());
    if(Math.abs(e.pageX-tableX)<6||Math.abs(e.pageX-(tableX+tableEleWidth))<8){
      target.css("cursor", "default");
      return;
    }
    if(Math.abs(e.pageY-tableY)<6||Math.abs(e.pageY-(tableY+tableHeight))<6){
      target.css("cursor", "default");
      return;
    }  
    //return;
    var w = $(target).width() + pianyi_val;
    var h = $(target).height();
    var prew = $(target).prev().width() + pianyi_val;
    var nextw = $(target).next().width() + pianyi_val;

    // 左边
    if (relativeX < 4) {
      moveRangeS = e.pageX - prew + relativeX + mincell_val;
      moveRangeE = e.pageX + w - relativeX - mincell_val;
      if(Math.abs(e.pageX-offset.left)<4){
        moveType = 'r';
      }else{
        moveType = 'l';
      }
      target.css("cursor", "w-resize");
    } else if ((w - relativeX) < 11) {
      // 右边
      moveRangeS = e.pageX - w + (w - relativeX) + mincell_val;
      moveRangeE = e.pageX + nextw + (w - relativeX) - mincell_val;
      if(Math.abs(e.pageX-offset.left)<4){
        moveType = 'r';
      }else{
        moveType = 'l';
      }
      target.css("cursor", "w-resize");
    } else {
      //alert(11);
      if (relativeY < h / 2) {
        moveType = 't';
      } else {
        moveType = 'b';
      }
      target.css("cursor", "s-resize");
    }
   
  }
}
//设置table鼠标移动到的td的背景色（鼠标往右下方移动）
function tableMoveLowerRight(startTxtMoveTd_ID,endTxtMoveTd_ID){
  //console.log("往右下移动");
  //debugger;
  chosedTdArr=[];
  var startTd=$("#"+startTxtMoveTd_ID);
  var endTd=$("#"+endTxtMoveTd_ID);
  var startRowAndCol=getTdIdRowAndCol(startTxtMoveTd_ID);
  var endRowAndCol=getTdIdRowAndCol(endTxtMoveTd_ID);
  startRow=startRowAndCol.row;
  startCol=startRowAndCol.col;
  endRow=endRowAndCol.row;
  endCol=endRowAndCol.col;
  var endRowspan=getRowSpan(endTd);
  var endColspan=getColSpan(endTd);
  if(endRowspan!=null){
    endRow=endRow+endRowspan-1;
  }
  if(endColspan!=null){
    endCol=endCol+endColspan-1;
  }
  for(var i=0;i<allTd.length;i++){
    var tdId=$(allTd[i]).attr('id');
    var tdRowAndCol=getTdIdRowAndCol(tdId);
    var tdRow=tdRowAndCol.row;
    var tdCol=tdRowAndCol.col;
    var rowspan=0;
    var colspan=0;
    var flag=false;
    var curTdRowspan=getRowSpan($(allTd[i]));
    var curTdColspan=getColSpan($(allTd[i]));
    if(curTdRowspan!=null){
      rowspan=curTdRowspan;
    }
    if(curTdColspan!=null){
      colspan=curTdColspan;
    }
    //判断当前td的的行和列数是否在当前选中的表格范围内（如果当前td是合并过的，判断此td拆分后的四个点的td的行和列是否在范围内）
    if(tdRow>=startRow&&tdRow<=endRow&&tdCol>=startCol&&tdCol<=endCol){
      flag=true;
    }else if(rowspan!=0&&(tdRow+rowspan-1)>=startRow&&(tdRow+rowspan-1)<=endRow&&tdCol>=startCol&&tdCol<=endCol){
      flag=true;
    }else if(colspan!=0&&tdRow>=startRow&&tdRow<=endRow&&(tdCol+colspan-1)>=startCol&&(tdCol+colspan-1)<=endCol){
      flag=true;
    }else if(rowspan!=0&&colspan!=0&&(tdRow+rowspan-1)>=startRow&&(tdRow+rowspan-1)<=endRow&&(tdCol+colspan-1)>=startCol&&(tdCol+colspan-1)<=endCol){
      flag=true;
    }
    //console.log(flag);
    //如果td在范围内，判断开始、结束行，开始、结束列是否需要改变
    if(flag){
      //td的行数小于选中范围的开始行，重新赋值选中的开始行
      if(tdRow<startRow){
        startRow=tdRow;
      }
      //td的列数小于选中范围的开始列，重新赋值选中的开始列
      if(tdCol<startCol){
        startCol=tdCol;
      }
      //td的行数加上合并行数大于选中范围的结束行，重新赋值选中的结束行
      if((tdRow+rowspan-1)>endRow){
        endRow=tdRow+rowspan-1
      }
      //td的列数加上合并行数大于选中范围的结束列，重新赋值选中的结束列
      if((tdCol+colspan-1)>endCol){
        endCol=tdCol+colspan-1;
      }
        
    }
  }
  var flag=true;
  for(var i=0;i<allTd.length;i++){
      var tdId=$(allTd[i]).attr('id');
      var tdRowAndCol=getTdIdRowAndCol(tdId);
      var tdRow=tdRowAndCol.row;
      var tdCol=tdRowAndCol.col;

      //判断当前td所属的行和列数，在选中的行列数内，改变td和textarea的背景色
      if(tdRow>=startRow&&tdRow<=endRow&&tdCol>=startCol&&tdCol<=endCol){
        //changeColorForChose($(allTd[i]));
        getChoseDivXy($(allTd[i]),flag);
        flag=false;
        chosedTdArr.push($(allTd[i]));
      }
  }
  showChoseTdDiv();
  //console.log(selectStartX,selectStartY,selectEndX,selectEndY);
  
}
//设置table鼠标移动到的td的背景色（鼠标往右上方移动）
function tableMoveUpperRight(startTxtMoveTd_ID,endTxtMoveTd_ID){
  //console.log("往右上移动");
  chosedTdArr=[];
  var startTd=$("#"+startTxtMoveTd_ID);
  var endTd=$("#"+endTxtMoveTd_ID);
  var startRowAndCol=getTdIdRowAndCol(startTxtMoveTd_ID);
  var endRowAndCol=getTdIdRowAndCol(endTxtMoveTd_ID);
  startRow=startRowAndCol.row;
  startCol=startRowAndCol.col;
  endRow=endRowAndCol.row;
  endCol=endRowAndCol.col;  
  var startRowspan=getRowSpan(startTd);
  var endColspan=getColSpan(endTd);
  if(endColspan!=null){
    endCol=endCol+endColspan-1;
  }
  if(startRowspan!=null){
    startRow=startRow+startRowspan-1;
  }
  /*if(typeof(endTd.attr("colspan"))!="undefined"){
    var colspan=endTd.attr("colspan");
    endCol=endCol+parseInt(colspan)-1;
  }
  if(typeof(startTd.attr("rowspan"))!="undefined"){
    var rowspan=endTd.attr("rowspan");
    startRow=startRow+parseInt(rowspan)-1;
  }*/
  for(var i=0;i<allTd.length;i++){
    var tdId=$(allTd[i]).attr('id');
    var tdRowAndCol=getTdIdRowAndCol(tdId);
    var tdRow=tdRowAndCol.row;
    var tdCol=tdRowAndCol.col;
    var rowspan=0;
    var colspan=0;
    var flag=false;
    var curTdRowspan=getRowSpan($(allTd[i]));
    var curTdColspan=getColSpan($(allTd[i]));
    if(curTdRowspan!=null){
      rowspan=curTdRowspan;
    }
    if(curTdColspan!=null){
      colspan=curTdColspan;
    }
    //判断当前td的的行和列数是否在当前选中的表格范围内（如果当前td是合并过的，判断此td拆分后的四个点的td的行和列是否在范围内）
    if(tdRow>=endRow&&tdRow<=startRow&&tdCol>=startCol&&tdCol<=endCol){
      flag=true;
    }else if(rowspan!=0&&(tdRow+rowspan-1)>=endRow&&(tdRow+rowspan-1)<=startRow&&tdCol>=startCol&&tdCol<=endCol){
      flag=true;
    }else if(colspan!=0&&tdRow>=endRow&&tdRow<=startRow&&(tdCol+colspan-1)>=startCol&&(tdCol+colspan-1)<=endCol){
      flag=true;
    }else if(rowspan!=0&&colspan!=0&&(tdRow+rowspan-1)>=endRow&&(tdRow+rowspan-1)<=startRow&&(tdCol+colspan-1)>=startCol&&(tdCol+colspan-1)<=endCol){
      flag=true;
    }
    //如果td在范围内，判断开始、结束行，开始、结束列是否需要改变
    if(flag){
      //td的行数小于选中范围的结束行，重新赋值选中的结束行
      if(tdRow<endRow){
        endRow=tdRow;
      }
      //td的列数小于选中范围的开始列，重新赋值选中的开始列
      if(tdCol<startCol){
        startCol=tdCol;
      }
      //td的行数加上合并行数大于选中范围的开始行，重新赋值选中的开始行
      if((tdRow+rowspan-1)>startRow){
        startRow=tdRow+rowspan-1
      }
      //td的列数加上合并行数大于选中范围的结束列，重新赋值选中的结束列
      if((tdCol+colspan-1)>endCol){
        endCol=tdCol+colspan-1;
      }
        
    }
  }
  var flag=true;
  for(var i=0;i<allTd.length;i++){
    var tdId=$(allTd[i]).attr('id');
    var tdRowAndCol=getTdIdRowAndCol(tdId);
    var tdRow=tdRowAndCol.row;
    var tdCol=tdRowAndCol.col;
    //判断当前td所属的行和列数，在选中的行列数内，改变td和textarea的背景色
    if(tdRow>=endRow&&tdRow<=startRow&&tdCol>=startCol&&tdCol<=endCol){
      getChoseDivXy($(allTd[i]),flag);
      flag=false;
      chosedTdArr.push($(allTd[i]));
    }
  }
  console.log(chosedTdArr);
  //console.log(selectStartX,selectStartY,selectEndX,selectEndY);
  showChoseTdDiv();
}
//设置table鼠标移动到的td的背景色（鼠标往左下方移动）
function tableMoveUpperLeft(startTxtMoveTd_ID,endTxtMoveTd_ID){
  //console.log("往左上移动");
  chosedTdArr=[];
  var startTd=$("#"+startTxtMoveTd_ID);
  var endTd=$("#"+endTxtMoveTd_ID);
  var startRowAndCol=getTdIdRowAndCol(startTxtMoveTd_ID);
  var endRowAndCol=getTdIdRowAndCol(endTxtMoveTd_ID);
  startRow=startRowAndCol.row;
  startCol=startRowAndCol.col;
  endRow=endRowAndCol.row;
  endCol=endRowAndCol.col;
  var startRowspan=getRowSpan(startTd);
  var startColspan=getColSpan(startTd);
  if(startRowspan!=null){
    startRow=startRow+startRowspan-1;
    //endCol=endCol+endColspan-1;
  }
  if(startColspan!=null){
    startCol=startCol+startColspan-1;
    //startRow=startRow+startRowspan-1;
  }
  for(var i=0;i<allTd.length;i++){
    var tdId=$(allTd[i]).attr('id');
    var tdRowAndCol=getTdIdRowAndCol(tdId);
    var tdRow=tdRowAndCol.row;
    var tdCol=tdRowAndCol.col;
    var rowspan=0;
    var colspan=0;
    var flag=false;
    var curTdRowspan=getRowSpan($(allTd[i]));
    var curTdColspan=getColSpan($(allTd[i]));
    if(curTdRowspan!=null){
      rowspan=curTdRowspan;
    }
    if(curTdColspan!=null){
      colspan=curTdColspan;
    }/*
    if(typeof($(allTd[i]).attr("rowspan"))!="undefined"){
      rowspan=parseInt($(allTd[i]).attr("rowspan"));
    }
    if(typeof($(allTd[i]).attr("colspan"))!="undefined"){
      colspan=parseInt($(allTd[i]).attr("colspan"));
    }*/
    //判断当前td的的行和列数是否在当前选中的表格范围内（如果当前td是合并过的，判断此td拆分后的四个点的td的行和列是否在范围内）
    if(tdRow>=endRow&&tdRow<=startRow&&tdCol>=endCol&&tdCol<=startCol){
      flag=true;
    }else if(rowspan!=0&&(tdRow+rowspan-1)>=endRow&&(tdRow+rowspan-1)<=startRow&&tdCol>=endCol&&tdCol<=startCol){
      flag=true;
    }else if(colspan!=0&&tdRow>=endRow&&tdRow<=startRow&&(tdCol+colspan-1)>=endCol&&(tdCol+colspan-1)<=startCol){
      flag=true;
    }else if(rowspan!=0&&colspan!=0&&(tdRow+rowspan-1)>=endRow&&(tdRow+rowspan-1)<=startRow&&(tdCol+colspan-1)>=endCol&&(tdCol+colspan-1)<=startCol){
      flag=true;
    }
    //如果td在范围内，判断开始、结束行，开始、结束列是否需要改变
    if(flag){
      //td的行数小于选中范围的结束行，重新赋值选中的结束行
      if(tdRow<endRow){
        endRow=tdRow;
      }
      //td的列数小于选中范围的结束列，重新赋值选中的结束列
      if(tdCol<endCol){
        endCol=tdCol;
      }
      //td的行数加上合并行数大于选中范围的开始行，重新赋值选中的开始行
      if((tdRow+rowspan-1)>startRow){
        startRow=tdRow+rowspan-1
      }
      //td的列数加上合并行数大于选中范围的开始列，重新赋值选中的开始列
      if((tdCol+colspan-1)>startCol){
        startCol=tdCol+colspan-1;
      }
        
    }
  }
  var flag=true;
  for(var i=0;i<allTd.length;i++){
    var tdId=$(allTd[i]).attr('id');
    var tdRowAndCol=getTdIdRowAndCol(tdId);
    var tdRow=tdRowAndCol.row;
    var tdCol=tdRowAndCol.col;
    //判断当前td所属的行和列数，在选中的行列数内，改变td和textarea的背景色
    if(tdRow>=endRow&&tdRow<=startRow&&tdCol>=endCol&&tdCol<=startCol){
      getChoseDivXy($(allTd[i]),flag);
      flag=false;
      chosedTdArr.push($(allTd[i]));
    }
  }
  //console.log(selectStartX,selectStartY,selectEndX,selectEndY);
  showChoseTdDiv();
}
//设置table鼠标移动到的td的背景色（鼠标往左下方移动）
function tableMoveLowerLeft(startTxtMoveTd_ID,endTxtMoveTd_ID){
  //console.log("往左下移动");
  chosedTdArr=[];
  var startTd=$("#"+startTxtMoveTd_ID);
  var endTd=$("#"+endTxtMoveTd_ID);
  var startRowAndCol=getTdIdRowAndCol(startTxtMoveTd_ID);
  var endRowAndCol=getTdIdRowAndCol(endTxtMoveTd_ID);
  startRow=startRowAndCol.row;
  startCol=startRowAndCol.col;
  endRow=endRowAndCol.row;
  endCol=endRowAndCol.col;
  var startColspan=getColSpan(startTd);
  var endRowspan=getRowSpan(endTd);
  if(startColspan!=null){
    startCol=startCol+startColspan-1;
  }
  if(endRowspan!=null){
    endRow=endRow+endRowspan-1;
  }
  /*if(typeof(startTd.attr("colspan"))!="undefined"){
    var colspan=startTd.attr("colspan");
    startCol=parseInt(startCol)+parseInt(colspan)-1;
  }
  if(typeof(endTd.attr("rowspan"))!="undefined"){
    var rowspan=endTd.attr("rowspan");
    endRow=parseInt(endRow)+parseInt(rowspan)-1;
  }*/
  for(var i=0;i<allTd.length;i++){
    var tdId=$(allTd[i]).attr('id');
    var tdRowAndCol=getTdIdRowAndCol(tdId);
    var tdRow=tdRowAndCol.row;
    var tdCol=tdRowAndCol.col;
    var rowspan=0;
    var colspan=0;
    var flag=false;
    var curTdRowspan=getRowSpan($(allTd[i]));
    var curTdColspan=getColSpan($(allTd[i]));
    if(curTdRowspan!=null){
      rowspan=curTdRowspan;
    }
    if(curTdColspan!=null){
      colspan=curTdColspan;
    }/*
    if(typeof($(allTd[i]).attr("rowspan"))!="undefined"){
      rowspan=parseInt($(allTd[i]).attr("rowspan"));
    }
    if(typeof($(allTd[i]).attr("colspan"))!="undefined"){
      colspan=parseInt($(allTd[i]).attr("colspan"));
    }*/
    //判断当前td的的行和列数是否在当前选中的表格范围内（如果当前td是合并过的，判断此td拆分后的四个点的td的行和列是否在范围内）
    if(tdRow>=startRow&&tdRow<=endRow&&tdCol>=endCol&&tdCol<=startCol){
      flag=true;
    }else if(rowspan!=0&&(tdRow+rowspan-1)>=startRow&&(tdRow+rowspan-1)<=endRow&&tdCol>=endCol&&tdCol<=startCol){
      flag=true;
    }else if(colspan!=0&&tdRow>=endRow&&tdRow<=startRow&&(tdCol+colspan-1)>=endCol&&(tdCol+colspan-1)<=startCol){
      flag=true;
    }else if(rowspan!=0&&colspan!=0&&(tdRow+rowspan-1)>=startRow&&(tdRow+rowspan-1)<=endRow&&(tdCol+colspan-1)>=endCol&&(tdCol+colspan-1)<=startCol){
      flag=true;
    }
    //如果td在范围内，判断开始、结束行，开始、结束列是否需要改变
    if(flag){
      //td的行数小于选中范围的开始行，重新赋值选中的开始行
      if(tdRow<startRow){
        startRow=tdRow;
      }
      //td的列数小于选中范围的结束列，重新赋值选中的结束列
      if(tdCol<endCol){
        endCol=tdCol;
      }
      //td的行数加上合并行数大于选中范围的结束行，重新赋值选中的结束行
      if((tdRow+rowspan-1)>endRow){
        endRow=tdRow+rowspan-1
      }
      //td的列数加上合并列数大于选中范围的开始列，重新赋值选中的开始列
      if((tdCol+colspan-1)>startCol){
        startCol=tdCol+colspan-1;
      }
        
    }
  }
  var flag=true;
  for(var i=0;i<allTd.length;i++){
    var tdId=$(allTd[i]).attr('id');
    var tdRowAndCol=getTdIdRowAndCol(tdId);
    var tdRow=tdRowAndCol.row;
    var tdCol=tdRowAndCol.col;
    //判断当前td所属的行和列数，在选中的行列数内，改变td和textarea的背景色
    if(tdRow>=startRow&&tdRow<=endRow&&tdCol>=endCol&&tdCol<=startCol){
      getChoseDivXy($(allTd[i]),flag);
      flag=false;
      chosedTdArr.push($(allTd[i]));
    }
  }
  //console.log(selectStartX,selectStartY,selectEndX,selectEndY);
  showChoseTdDiv();
}
//拆分单元格是只有行合并的时候
function revertTdOnlyRow(table,startRow,startCol,rowspan){
  var tr=table.find("tr");
  //只有行合并
    for(var i=1;i<rowspan;i++){
      //需要拆分的单元格式第一列的
      /*if(startCol==1){
        var afterId=(startRow+i)+"_"+(startCol+1);
        var insertId=(startRow+i)+"_"+startCol;
        var td=$("<td>").attr("id",insertId).append($("<textarea rows='1'>"));
        $("#"+afterId).before(td);
      }else{*/
        //需要插入的td之前的td的id
        var beforeId=(startRow+i)+"_"+(startCol-1);
        //需要插入的td的id
        var insertId=(startRow+i)+"_"+startCol;
        var td=$("<td>").attr("id",insertId).append($("<"+editDomType+">").attr("contenteditable",true));
        //需要插入的td前id的td不存在
        if($("#"+beforeId).length==0){
          //找出当前td所在行的所有td
          var currTdArr=$(tr[startRow+i-1]).find("td");
          if(currTdArr.length>0){
            //当前行只有一个td
            if(currTdArr.length==1){
              var id=$(currTdArr[0]).attr("id");
              var col=id.split("_")[1];
              //td的列数大于拆分的单元格的列数
              if(col<startCol){
                //将需要插入的td插入到id所代表的td的后面
                $("#"+id).after(td);
              }else{
                //将需要插入的td插入到id所代表的td的前面
                $("#"+id).before(td);
              }
            }else{
              for(var j=0;j<currTdArr.length-1;j++){
                //当前循环的td的id
                var bId=$(currTdArr[j]).attr("id");
                //当前循环数组下一个的td的id
                var aId=$(currTdArr[j+1]).attr("id");
                var bcol=bId.split("_")[1];
                var acol=aId.split("_")[1];
                //数组中的所有td的列数都大于需要插入开始列数
                if(bcol>startCol&&j==0){
                  $("#"+bId).before(td);
                  break;
                }else if(bcol<startCol&&acol>startCol){//需要插入开始列数在数组中前后两个td的列数的中间
                  $("#"+bId).after(td);
                  break;
                }else if(bcol<startCol&&acol<startCol&&(j+1)==(currTdArr.length-1)){//需要插入开始列数大于数组中的所有列数
                  $("#"+aId).after(td);
                }
              }
            }
          }else{
            $(tr[startRow+i-1]).append(td);
          }
        }else{
          $("#"+beforeId).after(td);
        }
      //}
    }
}
//拆分单元格是只有列合并的时候
function revertTdOnlyCol(table,startRow,startCol,colspan,revertTdWidth){
  var tr=table.find("tr");
  for(var i=0;i<colspan-1;i++){
        var beforeId=startRow+"_"+(startCol+i);
        var insertId=startRow+"_"+(startCol+i+1);
        var td=$("<td>").attr("id",insertId).append($("<"+editDomType+">").attr("contenteditable",true));
        td.width(revertTdWidth)
        $("#"+beforeId).after(td);
  }
}
//拆分单元格是只有列合并的时候
function revertTdRowAndCol(table,startRow,startCol,rowspan,colspan,revertTdWidth){
  var tr=table.find("tr");
  for(var i=1;i<parseInt(rowspan)+1;i++){
      for(var j=0;j<=colspan-1;j++){
        //拆分后第一个单元格不需要插入
        if(i==1&&j==0){
        }else{
          //当拆分的单元格的起始列为1时做特殊处理
          if(startCol==1){
            //处理拆分的单元格的第一个需要拆分的行
            if(i==1){
              var beforeId=startRow+"_"+(startCol+j-1);
              var insertId=startRow+"_"+(startCol+j);
              var td=$("<td>").attr("id",insertId).append($("<"+editDomType+">").attr("contenteditable",true));
              td.width(revertTdWidth)
              $("#"+beforeId).after(td);
            }else{
              //第一列时的情况
              if(j==0){
                //需要插入的当前行
                var currTr=tr[startRow+i-1-1];
                var insertId=(startRow+i-1)+"_"+"1";
                var td=$("<td>").attr("id",insertId).append($("<"+editDomType+">").attr("contenteditable",true));
                td.width(revertTdWidth)
                var tdArr=$(currTr).find("td");
                //当前行有td
                if(tdArr.length>0){
                  $(tdArr[0]).before(td);
                }else{
                  $(currTr).append(td);
                }
              }else{
                var beforeId=(startRow+i-1)+"_"+(startCol+j-1);
                var insertId=(startRow+i-1)+"_"+(startCol+j);
                var td=$("<td>").attr("id",insertId).append($("<"+editDomType+">").attr("contenteditable",true));
                td.width(revertTdWidth)
                $("#"+beforeId).after(td);
              }
            }
          }else{
            //需要插入的td之前的td的id
            var beforeId=(startRow+i-1)+"_"+(startCol+j-1);
            //需要插入的td的id
            var insertId=(startRow+i-1)+"_"+(startCol+j);
            var td=$("<td>").attr("id",insertId).append($("<"+editDomType+">").attr("contenteditable",true));
            td.width(revertTdWidth)
            //需要插入的td前id的td不存在
            if($("#"+beforeId).length==0){
              //找出当前td所在行的所有td
              var currTdArr=$(tr[startRow+i-1-1]).find("td");
              if(currTdArr.length>0){
                //当前行只有一个td
                if(currTdArr.length==1){
                  var id=$(currTdArr[0]).attr("id");
                  var col=id.split("_")[1];
                  //td的列数大于拆分的单元格的列数
                  if(col<startCol){
                    //将需要插入的td插入到id所代表的td的后面
                    $("#"+id).after(td);
                  }else{
                    //将需要插入的td插入到id所代表的td的前面
                    $("#"+id).before(td);
                  }
                }else{
                  for(var k=0;k<currTdArr.length-1;k++){
                    //当前循环的td的id
                    var bId=$(currTdArr[k]).attr("id");
                    //当前循环数组下一个的td的id
                    var aId=$(currTdArr[k+1]).attr("id");
                    var bcol=bId.split("_")[1];
                    var acol=aId.split("_")[1];
                    //数组中的所有td的列数都大于需要插入开始列数
                    if(bcol>startCol&&k==0){
                      $("#"+bId).before(td);
                      break;
                    }else if(bcol<startCol&&acol>startCol){//需要插入开始列数在数组中前后两个td的列数的中间
                      $("#"+bId).after(td);
                      break;
                    }else if(bcol<startCol&&acol<startCol&&(k+1)==(currTdArr.length-1)){//需要插入开始列数大于数组中的所有列数
                      $("#"+aId).after(td);
                    }
                  }
                }
              }else{
                //直接在需要插入的行生成td
                $(tr[startRow+i-1-1]).append(td);
              }
            }else{
              //在找到的td后插入生成的td
              $("#"+beforeId).after(td);
            }
          }
        }
      }
    }
}
function hideRCMenu(){
  $("#tableRCMenu").css('visibility', 'hidden');
}
function showRCMenu(e){
  //console.log(e);
   var menu=$("#tableRCMenu");
   menu.css("left",e.clientX + "px");
   menu.css("top",(parseInt(e.clientY)-100)+"px");
   menu.css('visibility', 'visible');
}
//获取变化后的table的所有信息更新到存储层
function getTableInfoToStore(tableEle,isRender,tableW){
    tableEleBo.tableRow=tableCountRow;
    tableEleBo.tableCol=tableCountCol;
    //tableEleBo.width=tableEle.parent().width();
    tableEleBo.width=tableEle.parent().width();;
    tableEleBo.height=tableEle.parent().height();
    tableEleBo.tr=[];
    var alltr=tableEle.find("tr");
    var colEle=tableEle.parent().find("col");
    tableEleBo.col=colEle;
    for(var i=0;i<alltr.length>0;i++){
       var trElement={
          td:[],
          height:null,
          inerHtml:""
       }
       trElement.height=$(alltr[i]).height();
       var trTdArr=$(alltr[i]).find("td");
       for(var j=0;j<trTdArr.length;j++){
          var tdElement={
            width:null,
            inerHtml:"",
            rowspan:null,
            colspan:null,
            id:""
          }
          tdElement.id=$(trTdArr[j]).attr("id");
          var rowspan=getRowSpan($(trTdArr[j]));
          var colspan=getColSpan($(trTdArr[j]));
          if(rowspan!=null){
            tdElement.rowspan=rowspan;
          }
          if(colspan!=null){
            tdElement.colspan=colspan;
          }
          var tdWidth=$(trTdArr[j]).width();
          tdElement.width=tdWidth;
          //var textareaVal=$(trTdArr[j]).find(""+editDomType).inerHtml;
          //console.log(textareaVal);
          //$(trTdArr[j]).find(""+editDomType).html(textareaVal);
          tdElement.inerHtml=$(trTdArr[j]).html();
          trElement.td.push(tdElement);
       }
       trElement.inerHtml=$(alltr[i]).html();
       tableEleBo.tr.push(trElement);
    }
    //console.log(tableEleBo);
    EditAreaStore.updateTableData(tableEleBo,isRender);
}
const TableService = {
  createTableByStoreData:function(props){
    hideRCMenu();
    //$("#tableSelected").css("visibility","visible");
    
    var eleId = props.id+"table";
    var tableEle = $('#'+eleId);
    tableEle.empty();
    if(props.isNewTable){
      //console.log("新增");
      for(var i=0;i<=props.tableRow;i++){
      var tr=$("<tr>").attr("id",i);
      for(var j=0;j<props.tableCol;j++){
        if(i==0){
          tableEle.append($("<col>"));
        }else{
          var id=(i)+"_"+(j+1);
          tr.append($("<td>").attr("id",id).append($("<div>").attr("contenteditable",true)));
        }
      }
      if(i!=0){
        tableEle.append(tr);
      }
    }
   }else{
     //console.log("更新");
     tableEle.append(props.col);
      var trArr=props.tr;
      for(var i=0;i<trArr.length;i++){
          var tr=$("<tr>").attr("id",i+1);
          var tdArr=trArr[i].td;
          tr.height(trArr[i].height);
          tr.html(trArr[i].inerHtml);
          tableEle.append(tr);
      }

   }
   if(startTxtMoveTd_ID!=null){
      $("#"+eleId).find("#"+startTxtMoveTd_ID).find("div").focus();
   }
   
   TableService.bindEvent(tableEle);
   TableService.inintTableInfo(props);
  },
  txtmouseDown:function(){
    var e = window.event || arguments[0];
    e.stopPropagation();
    hideRCMenu();
    if(3 == e.which){
      //console.log("右击");
      return;
    }
    isTxtDown = true;
    isCellMoveSize = false;
    document.addEventListener("mouseup",function(){
        console.log("documentmouseup");
        isTxtDown=false;
       document.removeEventListener("mouseup",null);
    });
    var tempEle = $(getEvetTarget(e));
    if(tempEle[0].tagName!="DIV"){
        tempEle=$(tempEle.parents("div")[0]);
    }
    var startTxtMoveTd = tempEle.parent();
    tableEleBo.isCreate=false;
    getTableInfoToStore(tempEle.parent().parent(),false);
    var table=tempEle.parent().parent().parent();
    var tableId=table.parent().attr("id");
    var storeId=tableId.substring(0,tableId.lastIndexOf("table"));
    EditAreaStore.selectCanvas(storeId);
    startTxtMoveTd_ID =startTxtMoveTd.attr('id');
    currMoveTxt_ID = startTxtMoveTd_ID;
    chosedTdArr=[];
    chosedTdArr.push($("#"+startTxtMoveTd_ID));
    //点击时给右边的表格操作栏天添加属性
    loadRightTableAttr();
    $("#tableSelected").css("visibility","hidden");
    //此部分之后要加入将此table的存储层数据设置为选中
    //table.find('td').removeAttr("bgcolor");
    //table.find("textarea").css("background-color","");
    //getTableInfoToStore(table);
  },
  txtmouseMove:function(){
    //console.log(isCellMoveSize)
    if (isCellMoveSize) {
    // setCursorStyle();
    // setTdNoEdit();
    return;
    }
    var e = window.event || arguments[0];
    e.stopPropagation();
    //console.log(e);
    //文本移动 
    if(isTxtDown){
      
      var tempEle = $(getEvetTarget(e));
      if(tempEle[0].tagName!="DIV"){
        tempEle=$(tempEle.parents("div")[0]);
      }
      var tempTxtEle = tempEle.parent();
      var tempId = tempTxtEle.attr('id');
      var table=tempTxtEle.parent().parent().parent();
      allTd=table.find('td');
      $("#tableSelected").css("visibility","hidden");
      //allTd.css("background-color","");
      //table.find("textarea").css("background-color","");
      //不一致
      console.log(startTxtMoveTd_ID+"  "+tempId);
      if(startTxtMoveTd_ID!=tempId){
        //debugger;
        //console.log(startTxtMoveTd_ID+"  "+tempId);
        var startTdX=$("#"+startTxtMoveTd_ID).offset().left;
        var startTdY=$("#"+startTxtMoveTd_ID).offset().top;
        var currmouseX=e.clientX;
        var currmouseY=e.clientY;
        //设置鼠标移动到的td的背景色（以每个td的id为基准设置符合要求的td改变背景色）
        //往右下移动
        if(currmouseX-startTdX>0&&currmouseY-startTdY>0){
          tableMoveLowerRight(startTxtMoveTd_ID,tempId);
        }//往右上移动
        else if(currmouseX-startTdX>0&&currmouseY-startTdY<0){
          tableMoveUpperRight(startTxtMoveTd_ID,tempId);
        }//往左上移动
        else if(currmouseX-startTdX<0&&currmouseY-startTdY<0){
          tableMoveUpperLeft(startTxtMoveTd_ID,tempId);
          
        }//往左下移动
        else if(currmouseX-startTdX<0&&currmouseY-startTdY>0){
          tableMoveLowerLeft(startTxtMoveTd_ID,tempId);
        }
        loadRightTableAttr();
      }else{
        chosedTdArr=[];
        chosedTdArr.push($("#"+startTxtMoveTd_ID));
      }
    }
  },
  //拆分单元格
  revertTd:function(){
    var currTd=$("#"+currMoveTxt_ID);
    hideRCMenu();
    //没有选中的td时
    if(currTd.length==0){
      return;
    }
    var table=currTd.parent().parent();
    var startRowAndCol=getTdIdRowAndCol(currMoveTxt_ID);
    var startRow=startRowAndCol.row;;
    var startCol=startRowAndCol.col;
    var rowspan=0;
    var colspan=0;
    var curTdRowspan=getRowSpan(currTd);
    var curTdColspan=getColSpan(currTd);
    var revertTdWidth=currTd.width();
    if(curTdRowspan!=null){
      rowspan=curTdRowspan;
    }
    if(curTdColspan!=null){
      colspan=curTdColspan;
      revertTdWidth=revertTdWidth/colspan;
      currTd.width(revertTdWidth-colspan*3);
    }
    /*
    if(typeof(currTd.attr("rowspan"))!="undefined"){
      rowspan=currTd.attr("rowspan");
    }
    if(typeof(currTd.attr("colspan"))!="undefined"){
      colspan=currTd.attr("colspan");
    }*/
    if(rowspan==0&&colspan==0){
      return;  
    }else if(rowspan!=0&&colspan==0){//只有行合并
      revertTdOnlyRow(table,startRow,startCol,rowspan);
    }else if(rowspan==0&&colspan!=0){//只有列合并
      revertTdOnlyCol(table,startRow,startCol,colspan,revertTdWidth);
    }else{//都有
      revertTdRowAndCol(table,startRow,startCol,rowspan,colspan,revertTdWidth);
    }
    //删除拆分的单元格的rowspan和colspan属性
    $("#"+currMoveTxt_ID).removeAttr("rowspan");
    $("#"+currMoveTxt_ID).removeAttr("colspan");
    chosedTdArr=[];
    //给新生成的td重新绑定事件
    //TableService.bindEvent(table);
    tableEleBo.isCreate=true;
    getTableInfoToStore(table,true);
  },
  //合并单元格
  combineTd:function(){
    hideRCMenu();
    if(chosedTdArr.length<=1){
      return;
    }
    var table;
    var afterCombineTdId;
    var rowspan=0;
    var colspan=0;
    var minRow=1;
    var maxRow=1;
    var minCol=1;
    var maxCol=1;
    for(var i=0;i<chosedTdArr.length;i++){
      var id=chosedTdArr[i].attr("id");
      var currRowAndCol=getTdIdRowAndCol(id);
      var currRow=currRowAndCol.row;;
      var currCol=currRowAndCol.col;
      //当第一次循环时选中范围的最小行和列的就是当前的行和列
      if(i==0){
        table=chosedTdArr[i].parent().parent().parent()
        minRow=currRow;
        minCol=currCol;
      }
      //当前的行大于选中范围的的最大行
      if(currRow>maxRow){
        maxRow=currRow;
      }
      var choseTdRowspan=getRowSpan(chosedTdArr[i]);
      //当前的td有行合并时
      if(choseTdRowspan!=null){
        //当前td的最大真实行
        var realRow=currRow+choseTdRowspan-1;
        //当前的真实行大于选中范围的的最大行
        if(realRow>maxRow){
          maxRow=realRow;
        }
      }
      //当前的列数大于选中范围的的最大行
      if(currCol>maxCol){
        maxCol=currCol;
      }
      var choseTdColspan=getColSpan(chosedTdArr[i]);
      //当前的td有列合并时
      if(choseTdColspan!=null){
        //当前td的最大真实列
        var realCOl=currCol+choseTdColspan-1;
        //当前的真实列大于选中范围的的最大列
        if(realCOl>maxCol){
          maxCol=realCOl;
        }
      }
    }
    //计算rowspan和colspan
    rowspan=maxRow-minRow+1;
    colspan=maxCol-minCol+1;
    var id=minRow+"_"+minCol;
    var subWidth=0;
    for(var i=0;i<chosedTdArr.length;i++){
      //给选中的第一个td加rowspan和colspan
      if(i==0){
        if(rowspan>1){
          chosedTdArr[i].attr("rowspan",rowspan);
        }
        if(colspan>1){
          chosedTdArr[i].attr("colspan",colspan);
          subWidth=colspan*2;
        }
      }else{

        //console.log(33);
        //删除选中其他td
        chosedTdArr[i].remove();
      }
    }
    if(colspan>1){
      $("#"+id).width($("#tableSelected").width()-subWidth);
    }
    $("#tableSelected").css("visibility","hidden");
    //table.find('td').removeAttr("bgcolor");
    //table.find("textarea").css("background-color","");
    chosedTdArr=[];
    
     //给新生成的td重新绑定事件
    //TableService.bindEvent(table);
    tableEleBo.isCreate=true;
    getTableInfoToStore(table,true);
    },
    textRightCliCK:function(){
      var e=window.event || arguments[0];
      e.stopPropagation();
      startTxtMoveTd_ID=$(e.target).parent().attr("id");
      showRCMenu(e);
      return false;
       //e.preventDefault(); //阻止事件
       //alert("右击");
    },
  txtmouseUp:function(){
    console.log("txtmouseUp");
    var e=window.event || arguments[0];;
    //e.stopPropagation();
    isTxtDown = false;
    startTxtMoveTd_ID=null;
  },
  tdMouseMove:function(){
      var e = window.event || arguments[0];
        if(isSizePre==false){
        //console.log("tdMouseMove");
        isSizePre = true;
        tdMouseDownBody(e);
      }
  },
  tdMouseOut:function(){
    isSizePre = false;
    // isCellMoveSize=false;
    var mhEle = $('#moveHelp');
  },
  tdMouseDown:function(){
    startTxtMoveTd_ID=null;
    var e = window.event || arguments[0];
    e.stopPropagation();
    currStartTd = $(getEvetTarget(e));
    // console.log('hello'+$('#table').css('top'));
    tdMouseDownBody(e);
    hideRCMenu();
    //$('#moveHelpDiv').trigger("mousedown");
    // 在范围类
    if (isSizePre) {
      //$(document).bind('mousemove', this.bodyMouseMove);
      //$(document).bind('mouseup', this.moveHelpDivUp);
      isCellMoveSize = true;
      //console.log(currStartTd);
      var tableEle=currStartTd.parent().parent();
      /*var tableId=tableEle.parent().attr("id");
      var storeId=tableId.substring(0,tableId.lastIndexOf("table"));
      EditAreaStore.selectCanvas(storeId);*/
      //当点击的是表格的外边框时不用显示
      var tableX=tableEle.offset().left;
      var tableY=tableEle.offset().top;
      var tableWidth=tableEle.width();
      var tableHeight=tableEle.height();
      if(Math.abs(e.pageX-tableX)<6||Math.abs(e.pageX-(tableX+tableWidth))<8){
        return;
      }
      if(Math.abs(e.pageY-tableY)<6||Math.abs(e.pageY-(tableY+tableHeight))<6){
        return;
      }
      $("#tableSelected").css("visibility","hidden");
      //tableEle.find("td").removeAttr("bgcolor");
      //tableEle.find("textarea").css("background-color","");
      moveStartx = e.pageX;
      moveStartY = e.pageY;
      if(moveType == 'l' || moveType == 'r'){
        var mhEle = $('#moveHelp');
        mhEle.css('left', e.pageX + 'px');
        mhEle.css('top', tableEle.offset().top);
        mhEle.css('height', tableEle.height() + 'px');
        mhEle.css('width', '2px'); 
        var moveHelpDiv = $('#moveHelpDiv');
        moveHelpDiv.css('left', 0);
        moveHelpDiv.css('top', 0);
        moveHelpDiv.css('width', $(window).width());
        moveHelpDiv.css('height',$(window).height());
        TableService.showHelp();
        moveHelpDiv.css("cursor", "w-resize");
        mhEle.css("cursor", "w-resize");
      }else if(moveType == 't' || moveType == 'b'){
        var mhEle = $('#moveHelp');
        mhEle.css('left', tableEle.offset().left);
        mhEle.css('top', e.pageY);
        mhEle.css('height', '2px');
        mhEle.css('width', tableEle.width() + 'px');
        var moveHelpDiv = $('#moveHelpDiv');
        moveHelpDiv.css('left', 0);
        moveHelpDiv.css('top', 0);
        moveHelpDiv.css('width', $(window).width());
        moveHelpDiv.css('height',$(window).height());
        TableService.showHelp();
        moveHelpDiv.css("cursor", "s-resize")
        mhEle.css("cursor", "s-resize");
      }
    }
  },
  bodyMouseMove:function(){
        if (isCellMoveSize == true) {
        var e = window.event || arguments[0];
        e.stopPropagation();
        e.preventDefault();
        var mhEle = $('#moveHelp');
      
        if(moveType == 'l' || moveType == 'r'){
          var x = parseInt(e.pageX);
          if (x < moveRangeS || x > moveRangeE) {
            return;
          }
          mhEle.css('left', e.pageX + 'px');
        }else{
          var tableY=parseInt($("#table").css('top'));
          var tableHeight=parseInt($("#table").height());
          mhEle.css('top', e.pageY + 'px');
        }
      }
    },
    moveHelpDivUp:function(){
        hideHelp();
        if(isCellMoveSize){
            var e = window.event || arguments[0];
            var mhEle = $('#moveHelp');
            var w = parseInt(currStartTd.outerWidth());
            var tableEle=currStartTd.parent().parent();
            var nowx = e.pageX;
            var nowY = e.pageY;
            var x = parseInt(e.pageX);
            var tableX=parseInt(tableEle.offset.left);
            var tableWidth=parseInt(tableEle.width());
            var tableHeight=parseInt(tableEle.height());
            var preTd = currStartTd.prev();
            var preW = preTd.outerWidth();
            var changeSize = nowx - moveStartx;
            // 左边,前面后当前单元格一起变化
            if (moveType == 'r') {
              var tableCol=tableEle.parent().find("col");
              var tdId=currStartTd.attr("id");
              var colNum=getTdIdRowAndCol(tdId).col;
              var currTdColSapn=getColSpan(currStartTd);
              if(currTdColSapn!=null){
                var clickColWidth=$(tableCol[colNum-1]).width();
                if(clickColWidth==0){
                  $(tableCol[colNum-1]).width(w/currTdColSapn-changeSize);
                }else{
                  $(tableCol[colNum-1]).width(clickColWidth-changeSize);
                }
              }else{
                $(tableCol[colNum-1]).width(w-changeSize);
              }
              if (preTd != null) { 
                var colspan=getColSpan(preTd);
                var perColNum=getTdIdRowAndCol(preTd.attr("id")).col;
                if(colspan!=null){
                  var colWidth=$(tableCol[perColNum+colspan-2]).width();
                  if(colWidth==0){
                    colWidth=preTd.outerWidth()/colspan;
                  }
                  $(tableCol[perColNum+colspan-2]).width(colWidth+changeSize);
                }else{
                  $(tableCol[perColNum-1]).width(preW+changeSize);
                }
              }
            }else if(moveType == 'l'){
                var tableCol=tableEle.parent().find("col");
                var nextTd=currStartTd.next();
                var tdId=nextTd.attr("id");
                w = nextTd.outerWidth();
                var preW = currStartTd.outerWidth();
                var colNum=getTdIdRowAndCol(tdId).col;
                var currTdColSapn=getColSpan(nextTd);
                if(currTdColSapn!=null){
                  var clickColWidth=$(tableCol[colNum-1]).width();
                  if(clickColWidth==0){
                    $(tableCol[colNum-1]).width(w/currTdColSapn-changeSize);
                  }else{
                    $(tableCol[colNum-1]).width(clickColWidth-changeSize);
                  }                }else{
                  $(tableCol[colNum-1]).width(w-changeSize);
                }
                //$(tableCol[colNum-1]).width(w-changeSize);
                var colspan=getColSpan(currStartTd);
                var perColNum=getTdIdRowAndCol(currStartTd.attr("id")).col;
                if(colspan!=null){
                    var colWidth=$(tableCol[perColNum+colspan-2]).width();
                    if(colWidth==0){
                    colWidth=currStartTd.outerWidth()/colspan;
                    }
                    $(tableCol[perColNum+colspan-2]).width(colWidth+changeSize);
                }else{
                    $(tableCol[perColNum-1]).width(preW+changeSize);
                }
            } else if(moveType == 't' || moveType == 'b'){
              //console.log($("#table").find("tr"));
              var tr=tableEle.find("tr");
              var temptr=null;
              var flag=0;
              for(var i=0;i<tr.length;i++){
                //当拖动开始的Y坐标和当前tr的y坐标的差值小于4是拖动开始的坐标是当前tr的Y坐标
                if(Math.abs($(tr[i]).offset().top-moveStartY)<4){
                  flag=i;
                  temptr=$(tr[i]);
                  break;
                }
              }
              if(temptr!==null){
                //往上拖动
                if(nowY<temptr.offset().top){
                  //当拖动开始是在第一行时
                  if(flag==0){
                    var trChangeHeight=$(tr[flag]).offset().top-nowY+$(tr[flag]).height();
                    tableEle.css("top",nowY);
                    $(tr[flag]).css("height",trChangeHeight);
                    //$(tr[flag]).css("height",trChangeHeight);
                  }else{
                    var trHeight=$(tr[flag-1]).height();
                    var trChangeHeight=nowY-$(tr[flag-1]).offset().top; 
                    //当改变后行的高度小于15时，设置行高为15（就是每行的最小高度是15）     
                    if(trChangeHeight<43){
                      $(tr[flag-1]).css("height",43);
                    }else{
                      $(tr[flag-1]).css("height",trChangeHeight);
                    }
                    tableEle.parent().height(tableHeight-(trHeight-trChangeHeight))
                  }
                }else{
                  //往下拖动
                  //当拖动开始是在第一行时
                  if(flag==0){
                    var trChangeHeight=$(tr[flag]).height()-(nowY-$(tr[flag]).offset().top);
                    tableEle.css("top",nowY+"px");
                    $(tr[flag]).css("height",trChangeHeight);  
                  }else{
                    var trChangeHeight=nowY-$(tr[flag-1]).offset().top;     
                    $(tr[flag-1]).css("height",trChangeHeight);
                    //$(tr[flag-1]).css("height",trChangeHeight);
                  } 
                }
              }else{
                var trHeight=$(tr[flag-1]).height();
                var trChangeHeight=nowY-$(tr[tr.length-1]).offset().top;
                $(tr[tr.length-1]).css("height",trChangeHeight);
              }
            }
            tableEleBo.isCreate=true;
            getTableInfoToStore(tableEle,true);
        }
        isSizePre = false;
        isCellMoveSize = false;
        
    },
    textInput:function(){
        var e = window.event || arguments[0]; 
        var tableEle=$(e.target).parent().parent().parent();
        tableEleBo.isCreate=false;
        getTableInfoToStore(tableEle,false);
    },
    bindEvent:function(tableEle){
    var txtArr = tableEle.find("td").find(""+editDomType);
    // alert(tdArr.length);
    txtArr.on('mousedown', this.txtmouseDown);
    txtArr.on('mouseover',this.txtmouseMove);
    txtArr.on('mouseup', this.txtmouseUp);
    txtArr.on('contextmenu', this.textRightCliCK);
    txtArr.on("blur",this.textInput);
    var tdArr = tableEle.find('tr').children();
    // alert(tdArr.length);
    tdArr.on('mousemove', this.tdMouseMove);
    tdArr.on('mouseout', this.tdMouseOut);
    tdArr.on('mousedown', this.tdMouseDown);
    $("#tableSelected").on('contextmenu', this.textRightCliCK);
    $("#tableSelected").on('click', function(){
      $("#tableSelected").css("visibility","hidden");
    });
  },

  inintTableInfo:function(tableProps){
      tableCountRow=tableProps.tableRow;
      tableCountCol=tableProps.tableCol;
      tableEleBo=tableProps;
  },
  //向上插入一行
  insertTrBefore:function(){
    hideRCMenu();
    //选中的td所在的tr
    var currentTr=$("#"+startTxtMoveTd_ID).parent();
    //当前的table对象
    var tableEle=currentTr.parent();
    //当前行的后面的所有行
    var nextAllTr=currentTr.nextAll();
    //当前的行数
    var currRow=getTdIdRowAndCol(startTxtMoveTd_ID).row;
    //在当前的行的上面插入一行，行里的td数是table的最大列数
    var insertTrEle=$("<tr>");
    for(var i=1;i<=tableCountCol;i++){
        var id = (currRow)+"_"+i; 
        insertTrEle.append($("<td>").attr("id",id).append($("<"+editDomType+">").attr("contenteditable",true)));
    }
    currentTr.before(insertTrEle);
    nextAllTr=insertTrEle.nextAll();
    //console.log(nextAllTr);
     //改变插入的行后面的行的所td的id(依次加1)
    for(var i=1;i<=nextAllTr.length;i++){
      var tdArr=$(nextAllTr[i-1]).find("td");
      if(tdArr.length!=0){
          var tdRow=currRow+i;
          for(var j=0;j<tdArr.length;j++){
              var tdCol=getTdIdRowAndCol($(tdArr[j]).attr("id")).col;
              var id=tdRow+"_"+tdCol;
              $(tdArr[j]).attr("id",id);
          }
      }
    }
    //去除插入的不需要的td
    //如果插入td的所在范围是在之前合并过后的范围内,需要删除此td，并且将之前合并的替代的rowspan加1
    var allTdArr=$(currentTr).parent().find("td");
    for(var i=0;i<allTdArr.length;i++){
        var rowspan=getRowSpan($(allTdArr[i]));
        var colspan=getColSpan($(allTdArr[i]));
        var tdRowAndCol=getTdIdRowAndCol($(allTdArr[i]).attr("id"));
        var rowVal=tdRowAndCol.row;
        var colVal=tdRowAndCol.col;
        if(rowspan!=null){
           if(rowVal<=currRow&&(rowVal+rowspan-1)>=currRow){
             if(colspan!=null){
                for(var j=0;j<colspan;j++){
                    var id=currRow+"_"+(colVal+j);
                  $("#"+id).remove();
              }
            }else{
              var id=currRow+"_"+colVal;
              $("#"+id).remove();
            }
            $(allTdArr[i]).attr("rowspan",rowspan+1);
          }
        }
       
    }
    //将表格行数加1
    tableCountRow=tableCountRow+1;
    //给新生成的td重新绑定事件
    //TableService.bindEvent($(currentTr).parent());
    //将改变后的数据存在存储层中
    tableEleBo.isCreate=true;
    getTableInfoToStore(tableEle,true);
  },
  //向下插入一行
  insertTrAfter:function(){
    hideRCMenu();
    var currentTr=$("#"+startTxtMoveTd_ID).parent();
    var tableEle=currentTr.parent();
    var currRow=getTdIdRowAndCol(startTxtMoveTd_ID).row;
    var nextAllTr=currentTr.nextAll();
     var rowspan=getRowSpan($("#"+startTxtMoveTd_ID));
    if(rowspan!=null){
        currRow=currRow+rowspan-1;
        currentTr=$(nextAllTr[rowspan-2]);
        nextAllTr=$(nextAllTr[rowspan-2]).nextAll();
    }
    var insertTrEle=$("<tr>");
    for(var i=1;i<=tableCountCol;i++){
        var id = (currRow+1)+"_"+i; 
        insertTrEle.append($("<td>").attr("id",id).append($("<"+editDomType+">").attr("contenteditable",true)));
    }
    //console.log(nextAllTr);
    for(var i=1;i<=nextAllTr.length;i++){
      var tdArr=$(nextAllTr[i-1]).find("td");
      if(tdArr.length!=0){
          var tdRow=currRow+i+1;
          for(var j=0;j<tdArr.length;j++){
              var tdCol=getTdIdRowAndCol($(tdArr[j]).attr("id")).col;
              var id=tdRow+"_"+tdCol;
              $(tdArr[j]).attr("id",id);
          }
      }
    }
    currentTr.after(insertTrEle);
    //去除插入的不需要的td
    var allTdArr=$(currentTr).parent().find("td");
    for(var i=0;i<allTdArr.length;i++){
        var rowspan=getRowSpan($(allTdArr[i]));
        var colspan=getColSpan($(allTdArr[i]));
        var tdRowAndCol=getTdIdRowAndCol($(allTdArr[i]).attr("id"));
        var rowVal=tdRowAndCol.row;
        var colVal=tdRowAndCol.col;
        if(rowspan!=null&&rowVal<(currRow+1)&&(rowVal+rowspan-1)>=(currRow+1)){
          if(colspan!=null){
            for(var j=0;j<colspan;j++){
              var id=(currRow+1)+"_"+(colVal+j);
              $("#"+id).remove();
              }
            }else{
              var id=(currRow+1)+"_"+colVal;
              $("#"+id).remove();
            }
            $(allTdArr[i]).attr("rowspan",rowspan+1);
          }
    }
    tableCountRow=tableCountRow+1;
    //给新生成的td重新绑定事件
    //TableService.bindEvent($(currentTr).parent());
    tableEleBo.isCreate=true;
    getTableInfoToStore(tableEle,true);
  },
  //向右插入一列
  insertColAfter:function(){
    console.log("向右插入一列");
    hideRCMenu();
    //选中td所在的表格行
    var currentTr=$("#"+startTxtMoveTd_ID).parent();
    //当前表格
    var tableEle=currentTr.parent();
    //var tdStandardW=tableEle.width()/tableCountCol;
    //选中td的列数
    var currCol=getTdIdRowAndCol(startTxtMoveTd_ID).col;
    //选中td的colspan值
    var colspan=getColSpan($("#"+startTxtMoveTd_ID));
    //当colspan值不为空，将当前列数加上colspan-1(即将插入的td的列数要往后推colspan的值)
     if(colspan!=null){
        currCol=currCol+colspan-1;
     }
     //获取当前table的所有行
     var alltr=$(currentTr).parent().find("tr");
     //在每行的正确位置插入一个td并且把插入的位置后面的td的ID中的col值加1
     for(var i=1;i<=tableCountRow;i++){
        //生成需要插入的td
        var insertTd=$("<td>").attr("id",i+"_"+(currCol+1)).append($("<"+editDomType+">").attr("contenteditable",true));
        insertTd.width(30); 
        //找到每行需要的插入的位置的td(从插入的td的列数开始往前推)
        for(var j=currCol;j>=1;j--){
            var tdId=i+"_"+j;
            var afterTd=$("#"+tdId);
            var nextTdArr;
            if(afterTd.length > 0 ){
                nextTdArr=afterTd.nextAll();
                afterTd.after(insertTd);
                for(var k=0;k<nextTdArr.length;k++){
                    var row=getTdIdRowAndCol($(nextTdArr[k]).attr("id")).row;
                    var col=getTdIdRowAndCol($(nextTdArr[k]).attr("id")).col;
                    var changeId=row+"_"+(col+1);
                    $(nextTdArr[k]).attr("id",changeId);
                }
                break;
            }else if(j==1){
                nextTdArr=$(alltr[i-1]).find("td");
                if(nextTdArr.length>0){
                    $(nextTdArr[0]).before(insertTd);
                    for(var k=0;k<nextTdArr.length;k++){
                    var row=getTdIdRowAndCol($(nextTdArr[k]).attr("id")).row;
                    var col=getTdIdRowAndCol($(nextTdArr[k]).attr("id")).col;
                    var changeId=row+"_"+(col+1);
                    $(nextTdArr[k]).attr("id",changeId);
                  }
                }else{
                   $(alltr[i-1]).append(insertTd);
                 } 
            }  
        }
     }
     //当td有合并并且之前插入的td的位置在合并的范围内，删除多出的td
    var allTd=$(currentTr).parent().find("td");
    for(var i=0;i<allTd.length;i++){
        var colspan=getColSpan($(allTd[i]));
        var rowspan=getRowSpan($(allTd[i]));
        var tdRowAndCol=getTdIdRowAndCol($(allTd[i]).attr("id"))
        var tdCol=tdRowAndCol.col;
        var tdRow=tdRowAndCol.row;
        if(colspan!=null){
          if(tdCol<(currCol+1)&&(tdCol+colspan-1)>=(currCol+1)){
            var id=tdRow+"_"+(currCol+1);
            $("#"+id).remove();
            if(rowspan!=null){
              for(var j=1;j<rowspan;j++){
                  id=(tdRow+j)+"_"+(currCol+1);
                  $("#"+id).remove();
              }
            }
            $(allTd[i]).attr("colspan",(colspan+1));
          }
        }
     }
     //将table的列数加1
     tableCountCol=tableCountCol+1;
    //给新生成的td重新绑定事件
    //TableService.bindEvent($(currentTr).parent());
    tableEleBo.isCreate=true;
    getTableInfoToStore(tableEle,true);
  },
  //向左插入一列
  insertColBefore:function(){
    console.log("向左插入一列");
    console.log("tableCountRow:"+tableCountRow);
    hideRCMenu();
    //debugger;
    //选中表格所在的行元素
    var currentTr=$("#"+startTxtMoveTd_ID).parent();
    //当前的表格
    var tableEle=currentTr.parent();
    //var tdStandardW=tableEle.width()/tableCountCol;
    //当前选中的表格的列数
    var currCol=getTdIdRowAndCol(startTxtMoveTd_ID).col;
    //表格中的所有tr元素
    var alltr=$(currentTr).parent().find("tr");
    //在表格中的每个tr元素中插入一个td，td的id及位置需要逻辑计算
    for(var i=1;i<=tableCountRow;i++){
        //生成一个需要插入的td元素，id是当前行和选中的td的行数
        var insertTd=$("<td>").attr("id",i+"_"+currCol).append($("<"+editDomType+">").attr("contenteditable",true));
        insertTd.width(30); 
        //在每一行中找到ID中的行数小于等于currCol的td将insertTd对象插入到找到的替代的前面或后面
        for(var j=currCol;j>=1;j--){
            var tdId=i+"_"+j;
            var beforeTd=$("#"+tdId);
            var nextTdArr;
            if(beforeTd.length > 0 ){
                //找到这个td后面的所有td元素（在一行内）
                nextTdArr=beforeTd.nextAll();
                //如果当前的列和需要插入的列数相同在这个元素前面加入，否则在后面加入
                if(j==currCol){
                    beforeTd.before(insertTd);
                    beforeTd.attr("id",i+"_"+(j+1));
                }else{
                    beforeTd.after(insertTd);
                }
                //将插入元素后面的元素ID的列数都加1
                for(var k=0;k<nextTdArr.length;k++){
                    var row=getTdIdRowAndCol($(nextTdArr[k]).attr("id")).row;
                    var col=getTdIdRowAndCol($(nextTdArr[k]).attr("id")).col;
                    var changeId=row+"_"+(col+1);
                    $(nextTdArr[k]).attr("id",changeId);
                }

                break;
            //这是当在插入元素的掐面找不到时，将元素插入到后面一个存在元素的前面
            }else if(j==1){
                nextTdArr=$(alltr[i-1]).find("td");
                if(nextTdArr.length>0){
                    $(nextTdArr[0]).before(insertTd);
                    for(var k=0;k<nextTdArr.length;k++){
                    var row=getTdIdRowAndCol($(nextTdArr[k]).attr("id")).row;
                    var col=getTdIdRowAndCol($(nextTdArr[k]).attr("id")).col;
                    var changeId=row+"_"+(col+1);
                    $(nextTdArr[k]).attr("id",changeId);
                  }
                }else{
                   $(alltr[i-1]).append(insertTd);
                 } 
            }  
        }
     }
    //当td有合并并且之前插入的td的位置在合并的范围内，删除多出的td
    var allTd=$(currentTr).parent().find("td");
    for(var i=0;i<allTd.length;i++){
        var colspan=getColSpan($(allTd[i]));
        var rowspan=getRowSpan($(allTd[i]));
        var tdRowAndCol=getTdIdRowAndCol($(allTd[i]).attr("id"))
        var tdCol=tdRowAndCol.col;
        var tdRow=tdRowAndCol.row;
        if(colspan!=null){
          if(tdCol<currCol&&(tdCol+colspan-1)>=currCol){
            var id=tdRow+"_"+currCol;
            $("#"+id).remove();
            if(rowspan!=null){
              for(var j=1;j<rowspan;j++){
                  id=(tdRow+j)+"_"+currCol;
                  $("#"+id).remove();
              }
            }
            $(allTd[i]).attr("colspan",(colspan+1));
          }
        }
     }
     tableCountCol=tableCountCol+1;
     //给新生成的td重新绑定事件
    //TableService.bindEvent($(currentTr).parent());
    tableEleBo.isCreate=true;
    getTableInfoToStore(tableEle,true);
  },
  //删除选中的行
  deleteChoiceRow:function(){
    hideRCMenu();
    if(chosedTdArr.length==0){
      return;
    }
    //用来存储选中的单元格所在的行数
    var choiceRow={};
    //表格对象
    var tableEle;
    //需要删除的最小行数
    var minRow;
    //需要删除的最大行数
    var maxRow;
    //循环选中的td数组，将行数加入到choiceRow
    for(var i=0;i<chosedTdArr.length;i++){
      var tdEle=chosedTdArr[i]; 
      var tdId=chosedTdArr[i].attr("id");
      tableEle=$("#"+tdId).parent().parent();
      var tdRowAndCol=getTdIdRowAndCol(tdEle.attr("id"));
      var row=tdRowAndCol.row;
      var col=tdRowAndCol.col;
      var rowspan=getRowSpan(tdEle);
      choiceRow[row]=1;
      if(rowspan!=null){
        for(var j=1;j<rowspan;j++){
          choiceRow[row+j]=1;
        }
      }
    }
    var allTr=tableEle.find("tr");
    var allTd=tableEle.find("td");
    var flag=1;
    //给minRow和maxRow赋值
    Object.keys(choiceRow).map(function(row){
      if(flag==1){
          minRow=row;
          maxRow=row;
      }else if(row>maxRow){
          maxRow=row;
      }
      flag++;
    });
    //循环所有的td，有合并过的td,拆分后的元素有在需要删除的行内的，将这个td的rowspan改变
    for(var i=0;i<allTd.length;i++){
        var rowspan=getRowSpan($(allTd[i]));
        var colspan=getColSpan($(allTd[i]));
        var tdRow=getTdIdRowAndCol($(allTd[i]).attr("id")).row;
        var tdMaxRow=tdRow+rowspan-1;
        if(rowspan!=null&&tdRow<minRow&&tdMaxRow>=minRow){
          var delRowVal;
          if(tdMaxRow>maxRow){
            delRowVal=maxRow-minRow+1;
          }else{
             delRowVal=tdMaxRow-minRow+1;
          }
          if(rowspan-delRowVal==1){
            $(allTd[i]).removeAttr("rowspan");
          }else{
            $(allTd[i]).attr("rowspan",rowspan-delRowVal);
          }
        }else if(rowspan!=null&&tdRow>=minRow&&tdRow<=maxRow&&tdMaxRow>maxRow){
            var delRowVal=maxRow-tdRow+1;
            var row=(parseInt(maxRow)+1);
            var col=getTdIdRowAndCol($(allTd[i]).attr("id")).col;
            if(rowspan-delRowVal==1){
              $(allTd[i]).removeAttr("rowspan");
            }else{
              $(allTd[i]).attr("rowspan",rowspan-delRowVal);
            }
            for(var j=col;j<=tableCountCol;j++){
                var id=row+"_"+j;
                var currTd=$("#"+id);
                if(currTd.length>0){
                    currTd.before($(allTd[i]));
                    break;
                }else if(j==tableCountCol){
                    $(allTr[row-1]).appned($(allTd[i]));
                }
            }
        }
    }
    //删除选中的行
    Object.keys(choiceRow).map(function(row){
      $(allTr[row-1]).remove();
    });
    //插入一行后，获得删除行后面的所有行对象
    var needChangeTrArr;
    if(minRow==1){
      needChangeTrArr=tableEle.find("tr");
    }else{
      allTr=tableEle.find("tr");
      needChangeTrArr=$(allTr[minRow-2]).nextAll("tr");
    }
    //console.log(needChangeTrArr);
    //改变needChangeTrArr中的所有td的id的行数
    for(var i=0;i<needChangeTrArr.length;i++){
        //td改变后的行数是选中的最小行在上是需要改变的第几行数
        var changeRow=parseInt(minRow)+i;
        var tdArr=$(needChangeTrArr[i]).find("td");
        for(var j=0;j<tdArr.length;j++){
            var col=getTdIdRowAndCol($(tdArr[j]).attr("id")).col;
            $(tdArr[j]).attr("id",changeRow+"_"+col)
        }
    }
    tableCountRow=tableCountRow-(parseInt(maxRow)-parseInt(minRow)+1);
    tableEleBo.isCreate=true;
    getTableInfoToStore(tableEle,true);
  },
  //删除选中的列
  deleteChoiceCol:function(){
    hideRCMenu();
    if(chosedTdArr.length==0){
      return;
    }
    //用来存储选中的单元格所在的列数
    var choiceCol={};
    //表格对象
    var tableEle;
    //需要删除的最小列数
    var minCol;
    //需要删除的最大行数
    var maxCol;
    //循环选中的td数组，将列数加入到choiceCol
    for(var i=0;i<chosedTdArr.length;i++){
      var tdEle=chosedTdArr[i];
      var tdId=chosedTdArr[i].attr("id");
      tableEle=$("#"+tdId).parent().parent();
      var tdRowAndCol=getTdIdRowAndCol(tdEle.attr("id"));
      var row=tdRowAndCol.row;
      var col=tdRowAndCol.col;
      var colspan=getColSpan(tdEle);
      choiceCol[col]=1;
      if(colspan!=null){
        for(var j=1;j<colspan;j++){
          choiceCol[col+j]=1;
        }
      }
    }
    //console.log(choiceCol);
    var allTd=tableEle.find("td");
    var flag=1;
    //给minCol和maxCol赋值
    Object.keys(choiceCol).map(function(col){
      if(flag==1){
          minCol=col;
          maxCol=col;
      }else if(col>maxCol){
          maxCol=col;
      }
      flag++;
    });
    for(var i=0;i<allTd.length;i++){
       var rowspan=getRowSpan($(allTd[i]));
       var colspan=getColSpan($(allTd[i]));
       var tdCol=getTdIdRowAndCol($(allTd[i]).attr("id")).col;
       var tdRow=getTdIdRowAndCol($(allTd[i]).attr("id")).row;
       if(colspan==null&&(tdCol>=minCol&&tdCol<=maxCol)){
            $(allTd[i]).remove();
       }else if(colspan!=null){
          var tdMaxCol=tdCol+colspan-1;
          var delColVal;
          if(tdCol<minCol&&tdMaxCol>=minCol){
              if(tdMaxCol<=maxCol){
                delColVal=tdMaxCol-minCol+1;
              }else{
                delColVal=maxCol-minCol+1;
              }
              $(allTd[i]).attr("colspan",colspan-delColVal);
            }else if(tdCol>=minCol&&tdCol<=maxCol&&tdMaxCol>maxCol){
                delColVal=maxCol-tdCol+1;
                var id=tdRow+"_"+(parseInt(maxCol)+1);
                var cloneTd=$(allTd[i]).clone(true);
                cloneTd.attr("colspan",colspan-delColVal).attr("id",id);
                $(allTd[i]).after(cloneTd);
                $(allTd[i]).remove();
            }else if(tdCol>=minCol&&tdMaxCol<=maxCol){
               $(allTd[i]).remove();
            }
      }
    }
    var delColNum=parseInt(maxCol)-parseInt(minCol)+1;
    //修改改变后的td的id
    var allTr=tableEle.find("tr");
    for(var i=0;i<allTr.length;i++){
        var allTd=$(allTr[i]).find("td");
        for(var j=0;j<allTd.length;j++){
            var rowAndCol=getTdIdRowAndCol($(allTd[j]).attr("id"));
            var row=rowAndCol.row;
            var col=rowAndCol.col;
            if(col>minCol){
              var id=row+"_"+(col-delColNum);
              $(allTd[j]).attr("id",id); 
            }
            
        }
    }
    var tableCol=tableEle.parent().find("col");
    for(var i=minCol;i<=maxCol;i++){
      tableCol[i-1].remove();
    }
    tableCountCol=tableCountCol-delColNum;
    tableEleBo.isCreate=true;
    getTableInfoToStore(tableEle,true);
  },
  //改变表格背景颜色
  changeFillColor:function(colorValue){
    //alert(startTxtMoveTd_ID);
    if (chosedTdArr.length==0) {return;}
    var tableEle;
    $("#tableSelected").css("visibility","hidden");
    for(var i=0;i<chosedTdArr.length;i++){
          var tdId=chosedTdArr[i].attr("id");
          var tdEle=$("#"+tdId);
          tableEle=tdEle.parent().parent();
          tdEle.css("background-color",""+colorValue);
          tdEle.find(""+editDomType).css("background-color",""+colorValue);
    }
    tableEleBo.isCreate=true;
    getTableInfoToStore(tableEle,true);
  },
  //显示表格拖拽的辅助样式
  showHelp:function (){
    var moveHelpDiv = $('#moveHelpDiv');
    moveHelpDiv.show();
    var mhEle = $('#moveHelp');
    mhEle.show();
    moveHelpDiv.bind('mousemove', this.bodyMouseMove);
    moveHelpDiv.bind('mouseup', this.moveHelpDivUp);
    mhEle.bind('mouseup', this.moveHelpDivUp);
  },
  //左侧属性栏改变行高
  changeRowHeight:function(height){
      if(chosedTdArr.length==0){
          return;
      }
      var flagRowNum=0;
      var rowNumMap={};
      var flag=true;
      var tableEle;
      for(var i=0;i<chosedTdArr.length;i++){
          var tdId=chosedTdArr[i].attr("id");
          var rowNum=getTdIdRowAndCol(tdId).row;
          var trEle=$("#"+tdId).parent();
          tableEle=trEle.parent();
          if(typeof(rowNumMap[rowNum])=="undefined"){
            var trH=trEle.height();
            var changeH=height-trH;
            trEle.height(height);
            tableEle.height(tableEle.height()+changeH);
            rowNumMap[rowNum]={
                rowNum:rowNum
            };
          }
          var rowspan=getRowSpan(chosedTdArr[i]);
          if(rowspan!=null){
              for(var j=1;j<rowspan;j++){
                  console.log(rowNumMap[rowNum+j]);
                  if(typeof(rowNumMap[rowNum+j])=="undefined"){
                      trEle=trEle.next();
                      var trH=trEle.height();
                      var changeH=height-trH;
                      trEle.height(height);
                      tableEle.height(tableEle.height()+changeH);;
                      rowNumMap[rowNum+j]={
                        rowNum:rowNum+j
                      };
                  }
              }
          }
        getChoseDivXy(chosedTdArr[i],i==0?true:false);
      }
    showChoseTdDiv();
    tableEleBo.isCreate=false;
    getTableInfoToStore(tableEle,true);
  },
  //左侧属性栏改变列宽
  changeColWidth:function(width){
      if(chosedTdArr.length==0){
        return;
      }
      var tableW;
      var tableEle;
      var tableCol;
      var colNumArr={};
      var flag=true;
      var firstRow=0;
      var choseAllTdWidth=0;
      for(var i=0;i<chosedTdArr.length;i++){
        var tdId=chosedTdArr[i].attr("id");
        tableEle=$("#"+tdId).parent().parent();
        var colspan=getColSpan(chosedTdArr[i]);
        var colNum=getTdIdRowAndCol(tdId).col;
        var rowNum=getTdIdRowAndCol(tdId).row;
        i==0?firstRow=rowNum:null;
        if(rowNum==firstRow){
          choseAllTdWidth=choseAllTdWidth+$("#"+tdId).outerWidth();
        }
        colNumArr[colNum]={
        };
        if(colspan!=null){
          for(var j=1;j<colspan;j++){
              colNumArr[colNum+j]={
              };
          }
        } 
      }
      tableCol=tableEle.parent().find("col");
      tableW=tableEle.outerWidth();
      var colNumLen=Object.keys(colNumArr).length;
      var changeW=width*colNumLen-choseAllTdWidth;
      Object.keys(colNumArr).map(function(colNum,index){
        $(tableCol[colNum-1]).width(width);
      });
      tableEle.parent().width(tableW+changeW+1);
      for(var i=0;i<chosedTdArr.length;i++){
        var tdId=chosedTdArr[i].attr("id");
        getChoseDivXy($("#"+tdId),i==0?true:false);
      }
      showChoseTdDiv();
      tableEleBo.isCreate=true;
      getTableInfoToStore(tableEle,true);
  },
  addTdBorderStyle:function(width,lineStyle,color){
    if (chosedTdArr.length==0) {return;}
    var BorderStyle=width+"px "+lineStyle+" "+color;
    console.log(BorderStyle);
    var tableEle;
    for(var i=0;i<chosedTdArr.length;i++){
      var tdId=chosedTdArr[i].attr("id");
      var tdEle=$("#"+tdId)
      tableEle=tdEle.parent().parent();
      tdEle.css("border",BorderStyle);
    }
    tableEleBo.isCreate=true;
    getTableInfoToStore(tableEle,true);
  } 
}
export default TableService;
