/**
 * 图形 - 正方形
 * 
 * @author Ma Junbao <mlive@live.cn>
 * @deprecated 2016-12-12
 */

import { h } from 'preact';
import Transform from './Transform';
import TxtBase from './TxtBase';

function Square(props) {
  let oW = props.width;
  let oH = props.height;
  let oSW = props.strokeWidth;
  let acW = props.width;
  let acH = props.height;
  // 绘制边框
  if (oSW > 0) {
    acW = oW + parseInt(oSW);
    acH = oH + parseInt(oSW);
  }
  let rotate = {
    width: 5,
    height: 5,
    position: 'absolute',
    let: '50%',
    top: '-10px',
    background: '#def'
  }
  let style = {
    position: 'absolute',
    opacity: props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={oW} height={oH} style={style} viewBox={`0,0,${acW},${acH}`} preserveAspectRatio="none">
        <rect width={oW} height={oH} x={props.strokeWidth / 2} y={props.strokeWidth / 2} fill={props.fill} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle} />
      </svg>
      <div style={rotate}>s</div>
    </Transform>
  )
}

export default Square;