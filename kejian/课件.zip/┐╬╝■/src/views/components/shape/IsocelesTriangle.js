import {h} from 'preact';
import Transform from './Transform';

function IsocelesTriangle(props) {
  let oW = props.width;
  let oH = props.height;
  let oSW = props.strokeWidth;
  let acW = props.width;
  let acH = props.height;
  // 绘制边框
  if (oSW>0) {
    acW = oW + parseInt(oSW)*2;
    acH = oH + parseInt(oSW);
  }
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props} width={oW} height={oH}>
      <svg width={oW} height={oH} style={style} viewBox={`0,0,${oW},${oH}`} preserveAspectRatio="none">
        <polygon width={oW} height={oH} points={`${oSW},${oSW} ${props.width-oSW},${props.height-oSW} ${oSW},${props.height-oSW}`} fill={props.fill} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle}/>
      </svg>
    </Transform>
  )
}

export default IsocelesTriangle;