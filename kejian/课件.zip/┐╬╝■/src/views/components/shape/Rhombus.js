import {h} from 'preact';
import Transform from './Transform';

function Rhombus(props) {
  let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={props.width} height={props.height} style={style}>
        <polygon points={`${props.width/2},0 ${props.width},${props.height/2} ${props.width/2},${props.height} 0,${props.height/2}`} fill={props.fill} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle}/>
      </svg>
    </Transform>
  )
}

export default Rhombus;