import {h} from 'preact';
import Transform from './Transform';

function Triangle(props) {
let style={
    position: 'absolute',
    opacity:props.opacity
  }
  return (
    <Transform {...props}>
      <svg width={props.width} height={props.height} style={style}>
        <polygon points={`${props.width/2},0 ${props.width},${props.height} 0,${props.height}`} fill={props.fill} stroke={props.stroke} stroke-width={props.strokeWidth} stroke-dasharray={props.strokeStyle}/>
      </svg>
    </Transform>
  )
}

export default Triangle;