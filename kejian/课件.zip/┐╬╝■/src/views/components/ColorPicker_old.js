class ColorPicker {
  constructor() {
    this.state = {
      hsv: [],
      mouse: {
        x: 0,
        y: 0
      },
      canvasOffset: {
        left: 0,
        top: 0
      },
      clickElement: null
    };
    this.style = {
      CP: {
        padding: 6,
        height: 160,
        width: 160 + 22 + 14,
        backgroundColor: '#eee'
      },
      SV: {
        x: 0 + 6, // CP padding
        y: 0 + 6,
        width: 160,
        height: 160,
        hue: 22,
        lineWidth: 1,
        lineStyle: 'rgba(0,0,0,0.6)',
        pointX: 0 + 6, // CP padding
        pointY: 0 + 6, // CP padding
        pointWidth: 5,
        pointStyle: '#000',
        pointLineWidth: 1,
        pointLineStyle: '#fff',
      },
      H: {
        x: 160 + 14, // SV width
        y: 0 + 6,
        width: 22,
        height: 160,
        lineWidth: 1,
        lineStyle: 'rgba(0,0,0,0.6)',
        point: 0 + 6,  // CP padding
        pointWidth: 12,
        pointHeight: 10,
        pointStyle: '#000'
      }
    };
    this.event = {
      change: new Event('change'),
    };
    this.commonColor = ['red','yellow','green'];

    this.render();
    this.bind();
    
  }

  render() {
    this.domElement = document.createElement('div');
    this.domElement.setAttribute('id', 'color-picker');
    this.canvasElement = document.createElement('canvas');
    this.canvasElement.setAttribute('id', 'color-picker-canvas');
    this.canvasElement.setAttribute('width', this.style.CP.width + this.style.CP.padding * 2);
    this.canvasElement.setAttribute('height', this.style.CP.height + this.style.CP.padding * 2);
    this.canvasElement.style.backgroundColor = this.style.CP.backgroundColor;

    this.commonColorElement = document.createElement('ul');
    this.commonColorElement.setAttribute('id', 'color-picker-common-color');
    for(let i = 0;i<this.commonColor.length; i++) {
      let ele = document.createElement('li');
      ele.innerText = this.commonColor[i];
      this.commonColorElement.appendChild(ele);
    }
    // console.log(this.commonColorElement);


    this.canvasCtx = this.canvasElement.getContext('2d');

    this.domElement.appendChild(this.canvasElement);
    this.domElement.appendChild(this.commonColorElement);
    this.refresh();
  }

  bind() {
    this.onMouseDown = this.onMouseDown.bind(this);
    this.onMouseMove = this.onMouseMove.bind(this);
    this.onMouseUp = this.onMouseUp.bind(this);

    this.canvasElement.addEventListener('mousedown', this.onMouseDown);
    this.canvasElement.addEventListener('contextmenu', function(e) {
      e.preventDefault()
    });
  }

  layout() {}

  show() {
    document.body.appendChild(this.domElement);
    this.canvasElement.style.visibility = 'visible';
    this.draw();
  }

  hide() {
    this.canvasElement.style.visibility = 'hidden';
  }
  destroy() {}

  refresh(e) {}

  on(eventType, callBack) {
    let that = this;
    typeof callBack === 'function' && this.canvasElement.addEventListener(eventType, function(){that._changeEventCallBack.call(this, callBack)});
  }

  off(eventType, callBack) {
    let that = this;
    typeof callBack === 'function' && this.canvasElement.removeEventListener(eventType, function(){that._changeEventCallBack.call(this, callBack)})
  }

  onMouseDown(e) {
    if (e.which === 1) {
      this.state.canvasOffset.left = this.canvasElement.offsetLeft;
      this.state.canvasOffset.top = this.canvasElement.offsetTop;

      this.state.mouse.x = e.pageX - this.state.canvasOffset.left;
      this.state.mouse.y = e.pageY - this.state.canvasOffset.top;

      // 点击元素
      this.state.clickElement = this._clickElement(e);

      this.draw(e);

      document.addEventListener('mousemove', this.onMouseMove);
      document.addEventListener('mouseup', this.onMouseUp);

    }
  }

  onMouseMove(e) {
    this.state.mouse.x = e.pageX - this.state.canvasOffset.left;
    this.state.mouse.y = e.pageY - this.state.canvasOffset.top;

    this.draw(e);
  }

  onMouseUp(e) {
    document.removeEventListener('mousemove', this.onMouseMove);
    document.removeEventListener('mouseup', this.onMouseUp);
  }

  setHSV() {
    let hsv = this.state.hsv;
    let h = (this.style.H.point - this.style.H.y) / this.style.H.height * 359;
    let s = (this.style.SV.pointX - this.style.SV.x) / this.style.SV.width;
    let v = Math.abs(this.style.SV.pointY - this.style.SV.y - this.style.SV.height) / this.style.SV.height;
    this.state.hsv = [h,s,v];

    this.canvasElement.dispatchEvent(this.event.change);
  }

  getHSV() {
    return this.state.hsv;
  }

  draw(e) {
    if (e) {
      switch (this.state.clickElement) {
        case 'SV':
          this._drawSV(e);
          this._drawSVPoint('SV');
          break;
        case 'H':
          this._drawH(e);
          this._drawHPoint(e);
          break;
        default:
      }
    } else {
      this._drawSV(e);
      this._drawSVPoint('SV');
      this._drawH(e);
      this._drawHPoint(e);
    }

    this.setHSV();
  }

  _HSVToRGB(h, s, v) {
    if (v == null) {
      return undefined;
    }
    let r,
      g,
      b;
    let c,
      x,
      m;

    let hi = Math.floor(h / 60);

    c = v * s;
    x = c * (1 - Math.abs((h / 60) % 2 - 1));
    m = v - c;

    switch (hi) {
      case 0:
        r = c;g = x;b = 0;
        break;
      case 1:
        r = x;g = c;b = 0;
        break;
      case 2:
        r = 0;g = c;b = x;
        break;
      case 3:
        r = 0;g = x;b = c;
        break;
      case 4:
        r = x;g = 0;b = c;
        break;
      case 5:
        r = c;g = 0;b = x;
        break;
    }

    r = Math.round((r + m) * 255);
    g = Math.round((g + m) * 255);
    b = Math.round((b + m) * 255);

    return `rgb(${r}, ${g}, ${b})`;
  }

  _change() {

  }

  _changeEventCallBack = (callBack) => {
    let hsv = this.state.hsv;
    let data = {
      rgb: this._HSVToRGB(this.state.hsv[0],this.state.hsv[1],this.state.hsv[2])
    }

    callBack(data);
  }


  // 绘制饱和度、明度区域
  _drawSV(e) {
    let ctx = this.canvasCtx;
    let x = this.style.SV.x;
    let y = this.style.SV.y;
    let width = this.style.SV.width;
    let height = this.style.SV.height;
    let pointOutWidht = this.style.SV.pointWidth + this.style.SV.pointLineWidth;

    this.canvasCtx.clearRect(x - pointOutWidht, y - pointOutWidht, width + pointOutWidht * 2, height + pointOutWidht * 2);

    ctx.beginPath();
    ctx.fillStyle = this._HSVToRGB(this.style.SV.hue, 1, 1);
    ctx.rect(x, y, width, height);
    ctx.fill();

    ctx.beginPath();
    let toRight = ctx.createLinearGradient(x, y, width, y);
    toRight.addColorStop(0, '#fff');
    toRight.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = toRight;
    ctx.rect(x, y, width, height);
    ctx.fill();

    ctx.beginPath();
    let toTop = ctx.createLinearGradient(x, height, x, y);
    toTop.addColorStop(0, '#000');
    toTop.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = toTop;
    ctx.rect(x, y, width, height);
    ctx.fill();

    ctx.lineWidth = this.style.SV.lineWidth;
    ctx.strokeStyle = this.style.SV.lineStyle;
    ctx.stroke();

  }

  // 绘制饱和度、明度控制点
  _drawSVPoint(e) {
    let ctx = this.canvasCtx;
    let x;
    let y;

    if (this.state.clickElement === 'SV') {
      x = this.state.mouse.x;
      y = this.state.mouse.y;
    } else {
      x = this.style.SV.pointX;
      y = this.style.SV.pointY;
    }

    // 限制点位置
    x = this.style.SV.pointX = Math.min(Math.max(x, this.style.SV.x), this.style.SV.y + this.style.SV.width);
    y = this.style.SV.pointY = Math.min(Math.max(y, this.style.SV.y), this.style.SV.x + this.style.SV.height);

    ctx.beginPath();
    ctx.arc(x, y, this.style.SV.pointWidth, 0, 2 * Math.PI);
    ctx.fillStyle = this.style.SV.pointStyle;
    ctx.fill();
    ctx.lineWidth = this.style.SV.pointLineWidth;
    ctx.strokeStyle = this.style.SV.pointLineStyle;
    ctx.stroke();
  }

  // 绘制色调区域
  _drawH(e) {
    let ctx = this.canvasCtx;
    let H = this.style.H;

    ctx.clearRect(H.x - H.lineWidth, H.y - H.lineWidth, H.x, H.height + H.lineWidth * 2);

    ctx.beginPath();
    let hueGradient = ctx.createLinearGradient(H.x, H.y, H.x, H.height);
    hueGradient.addColorStop(0, 'red');
    hueGradient.addColorStop(0.17, '#ff0');
    hueGradient.addColorStop(0.33, 'lime');
    hueGradient.addColorStop(0.50, 'cyan');
    hueGradient.addColorStop(0.67, 'blue');
    hueGradient.addColorStop(0.83, '#f0f');
    hueGradient.addColorStop(1, 'red');

    ctx.fillStyle = hueGradient;
    ctx.rect(H.x, H.y, H.width, H.height);
    ctx.fill();

    ctx.lineWidth = this.style.SV.lineWidth;
    ctx.strokeStyle = this.style.SV.lineStyle;
    ctx.stroke();
  }

  // 绘制色调控制点
  _drawHPoint(e) {
    let ctx = this.canvasCtx;
    let H = this.style.H;
    let y;

    if (this.state.clickElement === 'H') {
      y = this.state.mouse.y;
    } else {
      y = H.point;
    }

    // 限制点位置
    y = H.point = Math.min(Math.max(y, H.y), H.y + H.height);

    ctx.clearRect(H.x + H.width + H.lineWidth, H.y - this.style.CP.padding, H.width, H.height + this.style.CP.padding * 2);
    ctx.beginPath();
    ctx.moveTo(H.x + H.width + H.lineWidth, y);
    ctx.lineTo(H.x + H.width + H.lineWidth + H.pointWidth / 2, y - H.pointHeight / 2);
    ctx.lineTo(H.x + H.width + H.lineWidth + H.pointWidth / 2, y + H.pointHeight / 2);
    ctx.closePath();
    ctx.fillStyle = H.pointStyle;
    ctx.fill();

    // 设置色调
    this.style.SV.hue = (y - this.style.CP.padding) / H.height * 359;
    this._drawSV();
    this._drawSVPoint();
  }

  // 点击元素
  _clickElement(e) {
    let {CP, SV, H} = this.style;
    let mouse = this.state.mouse;

    if (mouse.x > SV.x && mouse.x < SV.x + SV.width && mouse.y > SV.y && mouse.y < SV.y + SV.height) {
      return 'SV';
    } else if (mouse.x > H.x && mouse.x < H.x + H.width && mouse.y > H.y && mouse.y < H.y + H.height) {
      return 'H';
    }
  }

}

export default ColorPicker;
