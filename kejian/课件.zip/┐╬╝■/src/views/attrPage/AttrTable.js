import { h } from 'preact';
import AttrTableService from './AttrTableService';
export default function(props) {
  return (
  	<div id="attr-table">
    <div className="attr-line">
    <span className="attr-head-title"><i className="icon-right"></i>行与列的大小</span>
	</div>
	<div className="attr-line-none" id="attr-cell">
		<div className="attr-sider">
	    <span className="count-icon attr-count-icon"><i className="icon-add" onClick={AttrTableService.changeColWidth}/> <i className="icon-plus" onClick={AttrTableService.changeColWidth}/></span>
	   	<span className="attr-font">列</span>
	   	<span className="attr-select attr-select-smaller-none"><input type="text" id="rTableColWidth" defaultValue="——" className="attr-input attr-input-small-none" onClick={AttrTableService.inputFocus} onkeyup={AttrTableService.changeColByInput}/></span>
		</div>
		<div className="attr-sider">
	   <span className="attr-font">行</span>
	   <span className="count-icon attr-count-icon"><i className="icon-add" onClick={AttrTableService.changeRowHeight}/> <i className="icon-plus" onClick={AttrTableService.changeRowHeight}/></span>
	   <span className="attr-select attr-select-smaller-none"><input type="text"  id="rTableRowHeight" defaultValue="——" className="attr-input attr-input-small-none" onClick={AttrTableService.inputFocus} onkeyup={AttrTableService.changeRowByInput}/></span>
		</div>
	</div>
	<div className="attr-line">
	    <div className="attr-line-border"></div>
	</div>
	<div className="attr-line-none" id="attr-button-cell">
	    <span className="attr-select" onClick={AttrTableService.combineTd}><em className="attr-button-text">合并单元格</em></span>
	    <span className="attr-select attr-mleft" onClick={AttrTableService.revertTd}><em className="attr-button-text">拆分单元格</em></span>
	</div>
	<div className="attr-line">
	    <div className="attr-line-border"></div>
	</div>
	</div>
  )
};
