/**
 * 属性区布局
 * author 马君保，臧文玉
 */

import { h, render, Component } from 'preact';
import AttrTable from './AttrTable';
import AttrFill from './AttrFill';
import AttrBorder from './AttrBorder';
import AttrOpacity from './AttrOpacity';
import AttrZ_Index from './AttrZ_Index';
import AttrDistribute from './AttrDistribute';
import AttrDefaultBlock from './AttrDefaultBlock';
import AttrPageService from './AttrPageService';

class AttrPage extends Component {
  updata = (canvasObj) => {
    this.props.onUpdataSelectedCanvasByValue(canvasObj);
  }
  state = {
    defaultView: 0 // 0 样式 1 文本 2 排列
  }

  componentDidMount() {
    this.init();
  }
  init() {
    this.bind();
    this.show();
  }
  bind() {
    let $attrTabItem = $('.attr-tab li');
    let $attrContentItem = $('.attr-content .tab-content');
    $attrTabItem.on('click', function () {
      $attrTabItem.removeClass('now');
      $attrContentItem.removeClass('now');
      $(this).addClass('now');
      $attrContentItem.eq($(this).index()).addClass('now');
    });
  }
  show() {
    $('.attr-tab li').eq(this.state.defaultView).addClass('now');
    $('.attr-content .tab-content').eq(this.state.defaultView).addClass('now');
  }
  render(props, state) {
    return (
      <div className="attr-page">
        <div className="attr-tab">
          <ul className="tab-header">
            <li>
              <a>样式</a>
            </li>
            <li>
              <a>文本</a>
            </li>
            <li>
              <a>排列</a>
            </li>
          </ul>
        </div>
        <div className="attr-content">
          <div className="tab-content">
            <AttrDefaultBlock />
            <div className="attr-cont">
              <AttrTable />
              <AttrFill />
              <AttrBorder />
              <AttrOpacity />
            </div>
          </div>
          <div className="tab-content">
            <div className="line-cont">
              <div className="line-title">
                大标题<i className="icon icon-down" />
              </div>
            </div>
            <div className="attr-cont">
              <ul className="attr-tab-main border">
                <li className="on border-right">
                  样式
                </li>
                <li>
                  布局
                </li>
              </ul>
              <div className="line-tips">
                字体
              </div>
              <div className="attr-select attr-select-large" id="attr-font">
                 <select id="attr-font-name" className="attr-input attr-input-middle" defaultValue="无样式" onChange={AttrPageService.setFontName}>
                <option value="">默认</option>
                <option value="SimSun">宋体</option>
                <option value="SimHei">黑体</option>
                <option value="Microsoft YaHei">微软雅黑</option>
                <option value="Serif">Serif</option>
                </select>
                <i className="attr-select-icon-blue"></i>
              </div>
              <div className="attr-line-none" id="attr-font-style">
                <div className="attr-select attr-select-medium">
                  <input type="text" defaultValue="细体" className="attr-input attr-input-medium" />
                  <i className="attr-select-icon-blue"></i>
                </div>
                <div className="attr-location">
                  <span className="count-icon attr-count-icon"><i className="icon-add" onClick={AttrPageService.changeFontSizeValue} /> <i className="icon-plus" onClick={AttrPageService.changeFontSizeValue} /></span>
                  <span className="attr-select attr-select-smaller-none"><input type="text" id="attr-text-font-size" defaultValue="3" className="attr-input attr-input-small-none" onkeyup={AttrPageService.fontSizeInput} /></span>
                </div>
              </div>
              <div className="line-font-style">
                <span className="font-style"><em id="font_style_b" className="b" onClick={AttrPageService.setTextBold} /> <em id="font_style_i" className="i on" onClick={AttrPageService.setTextItalic} /> <em id="font_style_u" className="u" onClick={AttrPageService.setTextUnderline} /> <em className="k" /></span>
                <span className="select-color"><input type="color" className="input-color" onClick={() => { AttrPageService.setTextForecolor("red") }}/> <i className="icon-color"></i></span>
              </div>
              <div className="attr-line">
                <div className="attr-line-border"></div>
              </div>
              <div className="line-tips">
                对齐
              </div>
               <div className="tab-main-text">
                <em className="tl on" onClick={() => { AttrPageService.setTextjustify("justifyLeft")}}/>
                <em className="tc" onClick={() => { AttrPageService.setTextjustify("justifyCenter")}}/>
                <em className="tr" onClick={() => { AttrPageService.setTextjustify("justifyRight")}}/>
                <em className="ta" onClick={() => { AttrPageService.setTextjustify("justifyFull")}}/>
              </div>
              <div className="tab-main-style">
                <em className="tl on" onClick={AttrPageService.setOutdent} />
                <em className="tr" onClick={AttrPageService.setIndent} />
              </div>
              <div className="tab-main-font">
                <em className="tl" />
                <em className="tc on" />
                <em className="tr" />
              </div>
              <div className="attr-line">
                <div className="attr-line-border"></div>
              </div>
              <div className="line-tips">
                <i className="icon-right" />间距
              </div>
              <div className="attr-select attr-select-large" id="attr-font-space">
                <input type="text" defaultValue="1.0--倍数" className="attr-input attr-input-large" />
                <i className="attr-select-icon-blue"></i>
              </div>
              <div className="attr-line-none" id="atrr-space">
                <div className="attr-select attr-select-medium">
                  <input type="text" defaultValue="行距" className="attr-input attr-input-medium" />
                  <i className="attr-select-icon-blue"></i>
                </div>
                <div className="attr-location">
                  <span className="count-icon attr-count-icon"><i className="icon-add" /> <i className="icon-plus" /></span>
                  <span className="attr-select attr-select-smaller-none"><input type="text" defaultValue={1} className="attr-input attr-input-small-none" /></span>
                </div>
              </div>
              <div className="attr-line-none">
                <div className="left-info">
                  段前
                </div>
                <div className="attr-location">
                  <span className="count-icon attr-count-icon"><i className="icon-add" /> <i className="icon-plus" /></span>
                  <span className="attr-select attr-select-smaller-none"><input type="text" defaultValue={1} className="attr-input attr-input-small-none" /></span>
                </div>
              </div>
              <div className="attr-line-none">
                <div className="left-info">
                  段后
                </div>
                <div className="attr-location">
                  <span className="count-icon attr-count-icon"><i className="icon-add" /> <i className="icon-plus" /></span>
                  <span className="attr-select attr-select-smaller-none"><input type="text" defaultValue={1} className="attr-input attr-input-small-none" /></span>
                </div>
              </div>
              <div className="attr-line-none">
                <div className="attr-line-border"></div>
              </div>
              <div className="attr-line-none">
                <div className="left-info">
                  <i className="icon-right"/>项目符号
                </div>
                <div className="attr-select attr-select-large" id="attr-letter">
                <select id="attr-ordered-list" className="attr-input attr-input-middle" defaultValue="无样式" onChange={AttrPageService.setTextOrderedList}>
                <option value="">无</option>
                <option value="insertOrderedList">数字</option>
                <option value="insertUnorderedList">黑点</option>
    
                </select>
                  <i className="attr-select-icon-blue"></i>
                </div>
              </div>
              <div className="attr-line">
                <div className="attr-line-border"></div>
              </div>
            </div>
          </div>
          <div className="tab-content">
            <div className="attr-cont">
              <div className="attr-line">
                <span className="attr-head-title"><i className="attr-title-icon"></i>文本绕排</span>
              </div>
              <div className="attr-line-none">
                <div className="attr-select attr-select-large" id="attr-surround">
                  <em className="attr-input attr-input-large"><i className="attr-public-icon attr-surround-icon"></i>环绕</em>
                  <i className="attr-select-icon-blue"></i>
                </div>
              </div>
              <div className="attr-line">
                <div className="attr-line-border" />
              </div>

              <AttrZ_Index />
              <AttrDistribute />
              <div className="attr-line">
                <div className="attr-line-border"></div>
              </div>
              <div className="attr-line-none" id="attr-location">
                <span className="attr-location-title">位置</span>
                <div className="attr-location">
                  <span className="count-icon attr-count-icon"><i className="icon-add" /> <i className="icon-plus" /></span>
                  <span className="attr-select attr-select-smaller-none"><input type="text" defaultValue="12.15厘米" className="attr-input attr-input-small-none" /></span>
                  <span className="attr-location-x">y</span>
                </div>
                <div className="attr-location">
                  <span className="count-icon attr-count-icon"><i className="icon-add" /> <i className="icon-plus" /></span>
                  <span className="attr-select attr-select-smaller-none"><input type="text" defaultValue="12.15厘米" className="attr-input attr-input-small-none" /></span>
                  <span className="attr-location-x">x</span>
                </div>
              </div>
              <div className="attr-line">
                <div className="attr-line-border" />
              </div>
              <div className="attr-line-none" id="attr-roate">
                <span className="attr-location-title">旋转</span>
                <em className="attr-public-icon attr-roate-icon"><i className="attr-roate-icon-point"></i></em>
                <div className="attr-location">
                  <span className="attr-select attr-select-smallerr"><i className="attr-public-icon attr-roate-icon-right"></i></span>
                  <span className="attr-select attr-select-smallerr"><i className="attr-public-icon attr-roate-icon-up"></i></span>
                  <span className="attr-location-x attr-mleft">旋转</span>
                </div>
                <div className="attr-location">
                  <span className="count-icon attr-count-icon"><i className="icon-add" /> <i className="icon-plus" /></span>
                  <span className="attr-select attr-select-smaller-none"><input type="text" defaultValue="355.1度" className="attr-input attr-input-small-none" /></span>
                  <span className="attr-location-x">角度</span>
                </div>
              </div>
              <div className="attr-line">
                <div className="attr-line-border" />
              </div>
              <div className="attr-line">
                <span className="attr-select"><em className="attr-button-text">成组</em></span>
                <span className="attr-select attr-mleft"><em className="attr-button-text">取消成组</em></span>
              </div>
              <div className="attr-line">
                <div className="attr-line-border" />
              </div>
              <div className="toolbar-operation">
                <span className="toolbar-operation-con">
                  <i className="toolbar-operation-icon toolbar-icon-small"></i>
                  <span className="toolbar-progress"><i className="toolbar-opaqueness-icon"></i></span>
                  <i className="toolbar-operation-icon toolbar-icon-big"></i>
                  <font className="toolbar-progress-num">130%</font>
                </span>
                <span>
                  <i className="toolbar-progress-screen"></i>
                  <i className="toolbar-progress-preview"></i>

                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default AttrPage;
