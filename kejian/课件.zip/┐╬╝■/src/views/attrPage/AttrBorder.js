import { h } from 'preact';
import AttrBorderService from './AttrBorderService';
export default function(props) {
  return (
  	<div id="attr-boder">
      <div className="attr-line">
        <span className="attr-head-title" onClick={AttrBorderService.addBorderStyle}><i className="attr-title-icon"></i>边框</span>
        <span className="attr-right-info"><span className="attr-text-radius"><em className="attr-text-line"></em></span></span>
      </div>
      <div className="attr-line-none">
        <span className="attr-select" id="attr-align">
        <select className="attr-input attr-input-middle" id="attr-boder-style" defaultValue="无样式" onChange={AttrBorderService.changeBorderStyle}>
          <option value="solid">无样式</option>
          <option value="solid">实线</option>
          <option value="dashed">虚线</option>
        </select>
        <i className="attr-select-icon-blue"></i>
      </span>
        <span className="attr-select attr-select-small" id="attr-color"><input type="text" defaultValue="" coloValue="#000" className="attr-input attr-select-color" id="attr-border-color"/> <i className="attr-icon-color"></i></span>
        <span className="count-icon attr-count-icon"><i className="icon-add" onClick={AttrBorderService.changeBorderWidth}/> <i className="icon-plus" onClick={AttrBorderService.changeBorderWidth}/></span>
        <span className="attr-select attr-select-smaller attr-opaqueness-num"><input type="text" defaultValue="3" className="attr-input attr-input-smaller" id="attr-boder-width" onkeyup={AttrBorderService.borderInput}/></span>
      </div>
      <div className="attr-line">
        <div className="attr-line-border"></div>
      </div>
	</div>
  )
};
