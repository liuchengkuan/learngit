import {h} from 'preact';
import Service from './AttrDistributeService';

export default function(props) {
  let onChangeAlign = function(e) {
    Service.blockAlign(e.target.value);
    e.target.value = 0;
  }

  let onChangeDistribute = function(e) {
    Service.blockDistribute(e.target.value);
    e.target.value = 0;
  }

  return (
    <div className="attr-line-none">
      <span className="attr-select" id="attr-align">
        <select className="attr-input attr-input-middle" defaultValue="对齐" onChange={onChangeAlign}>
          <option value="0">对齐</option>
          <option value="1">左对齐</option>
          <option value="2">居中</option>
          <option value="3">右对齐</option>
          <optgroup></optgroup>
          <option value="4">顶部</option>
          <option value="5">中间</option>
          <option value="6">底部</option>
        </select>
        <i className="attr-select-icon-blue"></i>
      </span>
      <span className="attr-select attr-mleft" id="attr-distribution">
        <select className="attr-input attr-input-middle" defaultValue="对齐" onChange={onChangeDistribute}>
          <option value="0">分布</option>
          <option value="1">平均</option>
          <option value="2">水平</option>
          <option value="3">垂直</option>
        </select>
        <i className="attr-select-icon-blue"></i>
      </span>
    </div>
  )
}