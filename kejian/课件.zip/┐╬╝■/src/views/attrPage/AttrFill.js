import { h } from 'preact';
import AttrFillService from './AttrFillService';

export default function(props) {
  return (
  	<div id="attr-color-fill">
	    <div className="attr-line clear">
        <span className="attr-head-title" id="attr-fill-color"><i className="attr-title-icon"></i>填充</span>
        <span className="attr-right-info"><span className="attr-text-radius"><span className="attr-text-bias"></span></span>
        </span>
      </div>
      <div className="attr-line">
        <span className="attr-head-title">常用颜色</span>
      </div>
      <div className="attr-line" id="attr-color-list">
        <div className="attr-fill-color">
          <i className="attr-fill-color-icon" colorValue="" onClick={AttrFillService.changeFillColor}><em className="attr-fill-color-bias"></em></i>
          <i className="attr-fill-color-icon attr-fill-color-white" colorValue="#fff" onClick={AttrFillService.changeFillColor}></i>
          <i className="attr-fill-color-icon attr-fill-color-red" colorValue="#bd301e" onClick={AttrFillService.changeFillColor}></i>
          <i className="attr-fill-color-icon attr-fill-color-orangered" colorValue="#e95440" onClick={AttrFillService.changeFillColor}></i>
          <i className="attr-fill-color-icon attr-fill-color-croci" colorValue="#f2c733" onClick={AttrFillService.changeFillColor}></i>
          <i className="attr-fill-color-icon attr-fill-color-yellow" colorValue="#fff76f" onClick={AttrFillService.changeFillColor}></i>
          <i className="attr-fill-color-icon attr-fill-color-lightgreen" colorValue="#6fbe12" onClick={AttrFillService.changeFillColor}></i>
          <i className="attr-fill-color-icon attr-fill-color-green" colorValue="#21a767" onClick={AttrFillService.changeFillColor}></i>
          <i className="attr-fill-color-icon attr-fill-color-lightblue" colorValue="#1fabe5" onClick={AttrFillService.changeFillColor}></i>
          <i className="attr-fill-color-icon attr-fill-color-blue" colorValue="#1f81e5" onClick={AttrFillService.changeFillColor}></i>
          <i className="attr-fill-color-icon attr-fill-color-darkblue" colorValue="#6e1fe5" onClick={AttrFillService.changeFillColor}></i>
        </div>
      </div>
      <div className="attr-line-border"></div>
	</div>
  )
};
