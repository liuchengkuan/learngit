import {h} from 'preact';

export default function(props) {
  return (
    <div className="attr-shap-style">
      <div className="attr-shap-main">
        <a className="attr-shap-icon attr-shap-icon-left"></a>
        <ul className="attr-shap-ul">
          <li className="shap-blue">
            文本
          </li>
          <li className="shap-green">
            文本
          </li>
          <li className="shap-yellow">
            文本
          </li>
          <li className="shap-red">
            文本
          </li>
          <li className="shap-gray">
            文本
          </li>
          <li className="shap-border">
            文本
          </li>
        </ul>
        <a className="attr-shap-icon attr-shap-icon-right-on"></a>
      </div>
      <span className="attr-shap-name">形状样式</span>
      <span className="attr-shap-point"><i className="attr-shap-icon-point-on"></i><i className="attr-shap-icon-point"></i></span>
    </div>
  )
}