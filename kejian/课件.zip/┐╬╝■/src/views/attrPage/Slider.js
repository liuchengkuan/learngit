import { h } from 'preact';
function Slider(props) {
  let opacityIconDragFlag=false;
  let spanEle;
  let getEvetTarget = (event) => {
      return event.srcElement ? event.srcElement : event.target;
  }
  let sliderMouseDown = () => {
    var e = window.event || arguments[0];
      if(3 == e.which){
        return;
      }
      var ele=$(getEvetTarget(e));
      spanEle = ele;
      if(spanEle[0].nodeName!="SPAN"){
        spanEle=$(ele.parents("span")[0]);
      }
      var spanWidth=parseInt(spanEle.width());
      //var spanEle=$("#attr-opaqueness-span");
      var spanx=spanEle.offset().left;
      var mouseX=e.pageX;
      var x=mouseX-spanx;
      var percentValue=x/spanWidth;
      percentValue=percentValue*100; 
      if(percentValue<1){
        percentValue=0;
        spanEle.find("em").css("width","0px");
        spanEle.find("i").css("left","1px");
      }else if(percentValue>100){
        percentValue=100;
        spanEle.find("em").css("width","100%");
        spanEle.find("i").css("left",(spanWidth+4)+"px");
      }else{
        spanEle.find("em").css("width",percentValue+"%");
        spanEle.find("i").css("left",(x+4)+"px");
        percentValue=Math.floor(percentValue);
      }
      typeof props.onChange == 'function' && props.onChange(percentValue);
      //$("#attr-opacity-shape").val(percentValue+"%");
      //SliderService.changeShapeOpacity(percentValue/100);
      document.addEventListener("mousemove",opacitySpanMouseMove);
      document.addEventListener("mouseup",opacityIconMouseUp);
  }
  let opacitySpanMouseMove = () => {
    var e = window.event || arguments[0];
    var ele=$(getEvetTarget(e));
    //var spanEle=$("#attr-opaqueness-span");
    var spanx=spanEle.offset().left;
    var spanWidth=parseInt(spanEle.width());
    var mouseX=e.pageX;
    var x=mouseX-spanx;
    var percentValue=x/spanWidth;
    percentValue=percentValue*100; 
    if(percentValue<1){
      percentValue=0;
      spanEle.find("em").css("width","0px");
      spanEle.find("i").css("left","1px");
    }else if(percentValue>100){
      percentValue=100;
      spanEle.find("em").css("width","100%");
      spanEle.find("i").css("left",(spanWidth+4)+"px");
    }else{
      spanEle.find("em").css("width",percentValue+"%");
      spanEle.find("i").css("left",(x+4)+"px");
      percentValue=Math.floor(percentValue);
    }
    typeof props.onChange == 'function' && props.onChange(percentValue);
    //$("#attr-opacity-shape").val(percentValue+"%");
    //AttrBorderService.changeShapeOpacity(percentValue/100);
  }
  let opacityIconMouseUp = () => {
    document.removeEventListener("mousemove",opacitySpanMouseMove);
    document.removeEventListener("mouseup",opacityIconMouseUp);
  }
  return (
    <span  style={{width:props.width+"px"}} id={props.eleId} className="attr-opaqueness"  onmousedown={sliderMouseDown}>
      <em className="attr-opaqueness-blue">
        <i className="attr-opaqueness-icon"></i>
      </em>
    </span>
  )
}
export default Slider;
