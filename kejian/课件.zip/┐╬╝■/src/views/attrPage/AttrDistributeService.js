import EditAreaStore from 'stores/EditAreaStore';
import LayoutStore from 'stores/LayoutStore';

export default new class {
  blockAlign = function(align) {
    switch (align) {
      case "1":
        this._left();
        break;
      case "2":
        this._center();
        break;
      case "3":
        this._right();
        break;
      case "4":
        this._top();
        break;
      case "5":
        this._middle();
        break;
      case "6":
        this._bottom();
        break;
    }
  }

  blockDistribute = function(distribute) {
    switch (distribute) {
      case "1":
        this._distribute(1);
        break;
      case "2":
        this._horizontal(2);
        break;
      case "3":
        this._distribute(3);
        break;
    }
  }

  /**
   * 分布
   * @param  {number} direction 方向: 1 平均 2 水平 3 垂直
   * @param  {number} spacing   间距
   * @return {void}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2017-03-17
   */
  _distribute(direction, spacing) {
    let selectedEle = EditAreaStore.getCanvasBySelected();
    let length = selectedEle.length;
    if (length >= 3) {
      for (let i = 0; i < length; i++) {
        EditAreaStore.updataCanvasById(selectedEle[i].id, {x: selectedEle[i].x += spacing*i})
      }
    }
  }

  /**
   * 对齐
   * @param  {Function} callback 回调函数，返回改变数据
   * @return {void}            
   */
  _align = function(callback) {
    let selectedEle = EditAreaStore.getCanvasBySelected();
    let length = selectedEle.length;
    let changeData = callback(selectedEle);
    for (let i = 0; i < length; i++) {
      EditAreaStore.updataCanvasById(selectedEle[i].id, changeData);
    }
  }

  _horizontal() {
    this._distribute(2, 30);
  }

  _vertical() {}

  _left() {
    this._align(function(ele) {
      if (ele.length === 1) {
        return {
          x: 0
        }
      } else {
        let elesX = [];
        for (let i = 0; i < ele.length; i++) {
          elesX.push(ele[i].x);
        }
        return {
          x: Math.min.apply(Math, elesX)
        }
      }
    });
  }
  _center() {
    this._align(function(ele) {
      if (ele.length === 1) {
        return {
          x: LayoutStore.getState().editAreaWidth / 2 - ele[0].width / 2
        }
      } else {
        let elesX = [];
        for (let i = 0; i < ele.length; i++) {
          elesX.push(ele[i].x);
        }
        return {
          x: (Math.max.apply(Math, elesX) - Math.min.apply(Math, elesX)) / 2 + Math.min.apply(Math, elesX)
        }
      }
    });

  }
  _right() {
    this._align(function(ele) {
      if (ele.length === 1) {
        return {
          x: LayoutStore.getState().editAreaWidth - ele[0].width
        }
      } else {
        let elesX = [];
        for (let i = 0; i < ele.length; i++) {
          elesX.push(ele[i].x);
        }
        return {
          x: Math.max.apply(Math, elesX)
        }
      }
    });
  }
  _top() {
    this._align(function(ele) {
      if (ele.length === 1) {
        return {
          y: 0
        }
      } else {
        let elesY = [];
        for (let i = 0; i < ele.length; i++) {
          elesY.push(ele[i].y);
        }
        return {
          y: Math.min.apply(Math, elesY)
        }
      }
    });
  }
  _middle() {
    this._align(function(ele) {
      if (ele.length === 1) {
        return {
          y: LayoutStore.getState().editAreaHeight / 2 - ele[0].height / 2
        }
      } else {
        let elesY = [];
        for (let i = 0; i < ele.length; i++) {
          elesY.push(ele[i].y);
        }
        return {
          y: (Math.max.apply(Math, elesY) - Math.min.apply(Math, elesY)) / 2 + Math.min.apply(Math, elesY)
        }
      }
    });
  }
  _bottom() {
    this._align(function(ele) {
      if (ele.length === 1) {
        return {
          y: LayoutStore.getState().editAreaHeight - ele[0].height
        }
      } else {
        let elesY = [];
        for (let i = 0; i < ele.length; i++) {
          elesY.push(ele[i].y);
        }
        return {
          y: Math.max.apply(Math, elesY)
        }
      }
    });
  }


}