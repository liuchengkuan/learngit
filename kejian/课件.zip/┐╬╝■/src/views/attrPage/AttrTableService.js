import EditAreaStore from '../../stores/EditAreaStore';
import TableService from '../components/table/TableService';
function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}
const AttrTableService = {
    combineTd:function(){
        TableService.combineTd();
    },
    revertTd:function(){
      TableService.revertTd();
    },
    changeRowHeight:function(){
      var e = window.event || arguments[0]; 
      e.stopPropagation();
      var ele=$(getEvetTarget(e));
      var height=$("#rTableRowHeight").val();
      var plus=true;
      if(height!=="——"){
        height=parseInt(height);
        if(ele.hasClass("icon-add")){
          height=height+1;
        }else{
          height=height-1;
          plus=false;
        }
        if(height<43){
            return;
        }
        $("#rTableRowHeight").val(height);
        TableService.changeRowHeight(height)
      }
    },
    changeColWidth:function(){
      var e = window.event || arguments[0];
      e.stopPropagation();
      var ele=$(getEvetTarget(e));
      //debugger;
      var width=$("#rTableColWidth").val();
      var plus=true;
      if(width!=="——"){
        width=parseInt(width);
        if(ele.hasClass("icon-add")){
          width=width+1;
        }else{
          width=width-1;
          plus=false;
        }
        $("#rTableColWidth").val(width);
        TableService.changeColWidth(width);
      }
    },
    inputFocus:function(){
       var e = window.event || arguments[0];
       e.stopPropagation();
    },
    changeColByInput:function(){
      var e = window.event || arguments[0];
      e.stopPropagation();
      if(e.keyCode == 13){
        var width=$("#rTableColWidth").val();
        if(width!=="——"){
          width=parseInt(width);
          TableService.changeColWidth(width);
        }
      }
    },
    changeRowByInput:function(){
        var e = window.event || arguments[0];
        e.stopPropagation();
        if(e.keyCode == 13){
            var height=$("#rTableRowHeight").val();
            if(height!=="——"&&height>=43){
              height=parseInt(height);
              TableService.changeRowHeight(height)
            }
        }
    }
}
export default AttrTableService;
