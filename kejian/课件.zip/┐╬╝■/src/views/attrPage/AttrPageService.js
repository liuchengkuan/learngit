import EditAreaStore from '../../stores/EditAreaStore';
import EditAreaPageService from '../editAreaPage/EditAreaPageService';
import CpConst from '../../utils/CpConst';
import TxtService from '../components/txt/TxtService';
// 按钮元素对应的样式操作
var id_styleArr = CpConst.id_styleArr;


function getStyleValue(styleKey, currSelEleData) {
  var val = getStyleValueByFirst(styleKey, currSelEleData);
  return val;
}

// 关于点击，样式添加或取消的类别
function getStyleValueByFirst(styleKey, currSelEleData) {
  var val = null;
  if (styleKey == 'fontWeight') {
    var tempVal = currSelEleData.fontWeight;
    if (tempVal == 'normal') {
      tempVal = 'bold';
    } else {
      tempVal = 'normal';
    }
    val = tempVal;
  }
  return val;
}

function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}

function getStyleKey(id) {
  for (var i in id_styleArr) {
    var obj = id_styleArr[i];
    if (obj.id == id) {
      return obj.styleKey;
    }
  }
}
/**
 * 属性区业务
 * author 马君保
 */
const AttrPageService = {

  selectFontStyle: function (event) {
    var currEle = getEvetTarget(event);
    var id = currEle.id; //获取当期按钮的id编码
    var styleKey = getStyleKey(id);


    //后面会选择多个
    var currSelEleDataArr = EditAreaStore.getCanvasBySelected();
    for (var i in currSelEleDataArr) {
      var currSelEleData = currSelEleDataArr[i];
      console.log(currSelEleData);
      var styleVal = getStyleValue(styleKey, currSelEleData);
      currSelEleData[styleKey] = styleVal;
      // EditAreaStore.updataCanvasById(currSelEleData.id, currSelEleData);
      console.log(currSelEleData.id + "改变样式：" + currSelEleData[styleKey]);

      // 触发文本框大小调整
      if (currSelEleData.type == 'txt') {
        EditAreaPageService.setTxtStyleBychangePrp(currSelEleData.id);
      }

    }

  },
  //测试改变线条的粗细和颜色
  changeEleColor: function (e) {
    var currentEle = EditAreaStore.getCanvasBySelected();
    if (currentEle.length != 0) {
      for (var i = 0; i < currentEle.length; i++) {
        var type = currentEle[i].type;
        if (type.indexOf("ine") > 0) {
          currentEle[i].fill = '#000000';
          currentEle[i].strokeWidth = 5;
        }
      }
      EditAreaStore.updataSelectedCanvasByDiff(currentEle);
    } else {

    }

  },
  changeFontSizeValue: function () {
    var value = $("#attr-text-font-size").val();
    var e = window.event || arguments[0];
    var ele = getEvetTarget(e);
    if(value==7||value==1){
      return;
    }
    if ($(ele).hasClass("icon-add")) {
      value = parseInt(value) + 1;
    } else {
      value = parseInt(value) - 1;
    }
    $("#attr-text-font-size").val(value);
    AttrPageService.setTextFontSize(value);
  },
  fontSizeInput: function () {
    var e = window.event || arguments[0];
    if (e.keyCode == 13) {
      var value = $("#attr-text-font-size").val();
      if(value>7){
        return;
      }
      AttrPageService.setTextFontSize(parseInt(value));
    }
  },
  setTextBold: function (e) {
    e.stopPropagation();
    TxtService.setBold();
  },
  setTextUnderline: function () {
    TxtService.setUnderline();
  },
  setTextItalic: function () {
    TxtService.setItalic();
  },
  setTextFontSize: function (fontSizeValue) {
    TxtService.setFontSize(fontSizeValue);
  },
  setTextForecolor: function (color) {
    TxtService.setForecolor(color);
  },
  setTextBackColor: function () {
    TxtService.setBackColor();
  },
  setTextOrderedList: function (value) {
    var value=$("#attr-ordered-list").val();
    if(value!=""){
      TxtService.setOrderedList(value);
    }
  },
  setTextjustify: function (value) {
    var e = window.event || arguments[0];
    var ele = $(getEvetTarget(e));
    ele.siblings().removeClass("on");
    ele.addClass("on");
    TxtService.setjustify(value);
  },
  setIndent: function () {
    var e = window.event || arguments[0];
    var ele = $(getEvetTarget(e));
    ele.siblings().removeClass("on");
    ele.addClass("on");
    TxtService.setIndent();
  },
  setOutdent: function () {
    var e = window.event || arguments[0];
    var ele = $(getEvetTarget(e));
    ele.siblings().removeClass("on");
    ele.addClass("on");
    TxtService.setOutdent();
  },
  setFontName:function(){
    var fontName=$("#attr-font-name").val();
    if(fontName!=""){
      TxtService.setFontName(fontName);
    }
    
  }
}

export default AttrPageService;