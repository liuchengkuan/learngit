import EditAreaStore from '../../stores/EditAreaStore';
import TableService from '../components/table/TableService';
var opacityIconDragFlag=false;
var spanEle;
function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}
function changeOpacitySpanByInput(opacityNum){
      var spanEle=$("#attr-opaqueness-span");
      spanEle.find("em").css("width",(opacityNum+3)+"%");
      var leftX=150*(opacityNum+3)/100;
      spanEle.find("i").css("left",leftX+"px");
}
const SliderService = {
    
    sliderMouseDown:function(){
      var e = window.event || arguments[0];
      if(3 == e.which){
        return;
      }
      var ele=$(getEvetTarget(e));
      spanEle = ele;
      if(spanEle[0].nodeName!="SPAN"){
        spanEle=$(ele.parents("span")[0]);
      }
      var spanWidth=parseInt(spanEle.width());
      //var spanEle=$("#attr-opaqueness-span");
      var spanx=spanEle.offset().left;
      var mouseX=e.pageX;
      var x=mouseX-spanx;
      var percentValue=x/spanWidth;
      percentValue=percentValue*100; 
      if(percentValue<1){
        percentValue=0;
        spanEle.find("em").css("width","0px");
        spanEle.find("i").css("left","1px");
      }else if(percentValue>100){
        percentValue=100;
        spanEle.find("em").css("width","100%");
        spanEle.find("i").css("left",(spanWidth+4)+"px");
      }else{
        spanEle.find("em").css("width",percentValue+"%");
        spanEle.find("i").css("left",(x+4)+"px");
        percentValue=Math.floor(percentValue);
      }
      $("#attr-opacity-shape").val(percentValue+"%");
      //SliderService.changeShapeOpacity(percentValue/100);
      document.addEventListener("mousemove",SliderService.opacitySpanMouseMove);
      document.addEventListener("mouseup",SliderService.opacityIconMouseUp);
    },
     opacitySpanMouseMove:function(){
      var e = window.event || arguments[0];
      var ele=$(getEvetTarget(e));
      //var spanEle=$("#attr-opaqueness-span");
      var spanx=spanEle.offset().left;
      var spanWidth=parseInt(spanEle.width());
      var mouseX=e.pageX;
      var x=mouseX-spanx;
      var percentValue=x/spanWidth;
      percentValue=percentValue*100; 
      if(percentValue<1){
        percentValue=0;
        spanEle.find("em").css("width","0px");
        spanEle.find("i").css("left","1px");
      }else if(percentValue>100){
        percentValue=100;
        spanEle.find("em").css("width","100%");
        spanEle.find("i").css("left",(spanWidth+4)+"px");
      }else{
        spanEle.find("em").css("width",percentValue+"%");
        spanEle.find("i").css("left",(x+4)+"px");
        percentValue=Math.floor(percentValue);
      }
      $("#attr-opacity-shape").val(percentValue+"%");
      //AttrBorderService.changeShapeOpacity(percentValue/100);
    },
    opacityIconMouseUp:function(){
      document.removeEventListener("mousemove",SliderService.opacitySpanMouseMove);
      document.removeEventListener("mouseup",SliderService.opacityIconMouseUp);
    }
    
}
export default SliderService;