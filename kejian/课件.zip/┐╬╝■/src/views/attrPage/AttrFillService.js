import EditAreaStore from '../../stores/EditAreaStore';
import TableService from '../components/table/TableService';
function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}
const AttrFillService = {
    changeFillColor:function(){
      var e = window.event || arguments[0]; 
      e.stopPropagation();
      var ele=$(getEvetTarget(e));
      var color=ele.attr("colorValue");
      var selectCanvasData = EditAreaStore.getCanvasBySelected();
      for (let i in selectCanvasData) {
          var currData=selectCanvasData[i];
          if(currData.type=="table"){
            TableService.changeFillColor(color);
          }else{
            currData.fill=color;
            EditAreaStore.updataCanvasById(currData.id,currData);
          }
      }
      //这部分调用那个组件的service以后需要根据当前选中的组件确定
      
    }
}
export default AttrFillService;