import EditAreaStore from '../../stores/EditAreaStore';
import TableService from '../components/table/TableService';
function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}
const AttrBorderService = {
    addBorderStyle:function(){
      var borderStyle=$("#attr-boder-style").val();
      var borderW=$("#attr-boder-width").val();
      var borderCorlor=$("#attr-border-color").attr('coloValue');
      //console.log(borderStyle,borderW,borderCorlor);
      var selectCanvasData = EditAreaStore.getCanvasBySelected();
      for (let i in selectCanvasData) {
          var currData=selectCanvasData[i];
          if(currData.type=="table"){
            TableService.addTdBorderStyle(borderW,borderStyle,borderCorlor);
          }else{
            if(borderStyle=="dashed"){
              currData.strokeStyle=5;
            }else{
                currData.strokeStyle='';
            }
            currData.strokeWidth=borderW;
            currData.stroke=borderCorlor;
            EditAreaStore.updataCanvasById(currData.id,currData);
          }
      }
      
    },
    changeBorderWidth:function(){
    	var e = window.event || arguments[0];
    	var ele=$(getEvetTarget(e));
    	var borderW =parseInt($("#attr-boder-width").val());
    	if(ele.hasClass("icon-add")){
    		borderW=borderW+1;
    		$("#attr-boder-width").val(borderW);
    	}else{
    		if(borderW==1){
    			return;
    		}
    		borderW=borderW-1;
    		$("#attr-boder-width").val(borderW);
    	}
      AttrBorderService.addBorderStyle();
    },
    changeBorderStyle:function(e){
        var value=e.target.value;
        AttrBorderService.addBorderStyle();
    },
    borderInput:function(){
      var e = window.event || arguments[0];
      if(e.keyCode == 13){
        var value=$("#attr-boder-width").val();
        if(!$.isNumeric(value)){
            $("#attr-boder-width").val(1);
        }
        AttrBorderService.addBorderStyle();
      }
    }
}
export default AttrBorderService;