import {h} from 'preact';

export default function(props) {
  return (
    <div>
      <div className="attr-line" id="attr-opaqueness">
        <span className="attr-head-title"><i className="attr-title-icon-right"></i>不透明度</span>
      </div>
      <div classNameS="attr-line">
        <span className="attr-opaqueness"><em className="attr-opaqueness-blue"><i className="attr-opaqueness-icon"></i></em></span>
        <span className="count-icon attr-count-icon"><i className="icon-add" /> <i className="icon-plus" /></span>
        <span className="attr-select attr-select-smaller attr-opaqueness-num"><input type="text" defaultValue="70%" className="attr-input attr-input-smaller"/></span>
      </div>
      <div className="attr-line">
        <div className="attr-line-border"></div>
      </div>
    </div>
  )
}