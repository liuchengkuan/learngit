import {h} from 'preact';
import AttrOpacityService from './AttrOpacityService';
import Slider from './Slider';
export default function(props) {
  let sliderChange = (data) =>{
    $("#attr-opacity-shape").val(data+"%");
    AttrOpacityService.changeShapeOpacity(data/100);
  }
  return (
    <div id="attr-opaqueness-div" >
      <div className="attr-line" id="attr-opaqueness">
        <span className="attr-head-title"><i className="attr-title-icon-right"></i>不透明度</span>
      </div>
      <div classNameS="attr-line">
        <Slider width="150" eleId="attr-opaqueness-span" onChange={sliderChange}></Slider>
        <span className="count-icon attr-count-icon"><i className="icon-add" onClick={AttrOpacityService.changeOpacityValue}/> <i className="icon-plus" onClick={AttrOpacityService.changeOpacityValue}/></span>
        <span className="attr-select attr-select-smaller attr-opaqueness-num"><input type="text" id="attr-opacity-shape" defaultValue="70%" className="attr-input attr-input-smaller" onkeyup={AttrOpacityService.opacityInput}/></span>
      </div>
      <div className="attr-line">
        <div className="attr-line-border"></div>
      </div>
    </div>
  )
}