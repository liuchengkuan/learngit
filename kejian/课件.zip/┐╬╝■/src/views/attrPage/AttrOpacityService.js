import EditAreaStore from '../../stores/EditAreaStore';
import TableService from '../components/table/TableService';
var opacityIconDragFlag=false;
function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}
function changeOpacitySpanByInput(opacityNum){
      var spanEle=$("#attr-opaqueness-span");
      spanEle.find("em").css("width",(opacityNum+3)+"%");
      var leftX=150*(opacityNum+3)/100;
      spanEle.find("i").css("left",leftX+"px");
}
const AttrOpacityService = {
    changeShapeOpacity:function(opacityNum){
      var selectCanvasData = EditAreaStore.getCanvasBySelected();
      for (let i in selectCanvasData) {
          var currData=selectCanvasData[i];
          //currData.strokeStyle=borderStyle;
          currData.opacity=opacityNum;
          EditAreaStore.updataCanvasById(currData.id,currData);
      }
    },
    changeOpacityValue:function(){
      var e = window.event || arguments[0];
      var ele=$(getEvetTarget(e));
      var opacityVal=$("#attr-opacity-shape").val();
      var opacityNum=parseInt(opacityVal.substring(0,opacityVal.lastIndexOf("%")));
      if(ele.hasClass("icon-add")){
        if(opacityNum==100){
            return;
        }
        opacityNum=opacityNum+1;
        $("#attr-opacity-shape").val(opacityNum+"%");
        AttrOpacityService.changeShapeOpacity(opacityNum/100);
      }else{
        if(opacityNum==1){
          return;
        }
        opacityNum=opacityNum-1;
        $("#attr-opacity-shape").val(opacityNum+"%");
        AttrOpacityService.changeShapeOpacity(opacityNum/100);
      }
      changeOpacitySpanByInput(opacityNum);
    },
    opacitySpanMouseMove:function(){
      var e = window.event || arguments[0];
      var ele=$(getEvetTarget(e));
      var spanEle=$("#attr-opaqueness-span");
      var spanx=spanEle.offset().left;
      var mouseX=e.pageX;
      var x=mouseX-spanx;
      var percentValue=x/150;
      percentValue=percentValue*100; 
      if(percentValue<1){
        percentValue=0;
        spanEle.find("em").css("width","0px");
        spanEle.find("i").css("left","1px");
      }else if(percentValue>100){
        percentValue=100;
        spanEle.find("em").css("width","100%");
        spanEle.find("i").css("left","154px");
      }else{
        spanEle.find("em").css("width",percentValue+"%");
        spanEle.find("i").css("left",(x+4)+"px");
        percentValue=Math.floor(percentValue);
      }
      $("#attr-opacity-shape").val(percentValue+"%");
      AttrOpacityService.changeShapeOpacity(percentValue/100);
    },
    opacitySpanDown:function(){
      var e = window.event || arguments[0];
      if(3 == e.which){
        return;
      }
      var ele=$(getEvetTarget(e));
      var spanEle;
      var spanEle=$("#attr-opaqueness-span");
      var spanx=spanEle.offset().left;
      var mouseX=e.pageX;
      var x=mouseX-spanx;
      var percentValue=x/150;
      percentValue=percentValue*100; 
      if(percentValue<1){
        percentValue=0;
        spanEle.find("em").css("width","0px");
        spanEle.find("i").css("left","1px");
      }else if(percentValue>100){
        percentValue=100;
        spanEle.find("em").css("width","100%");
        spanEle.find("i").css("left","154px");
      }else{
        spanEle.find("em").css("width",percentValue+"%");
        spanEle.find("i").css("left",(x+4)+"px");
        percentValue=Math.floor(percentValue);
      }
      $("#attr-opacity-shape").val(percentValue+"%");
      AttrOpacityService.changeShapeOpacity(percentValue/100);
      document.addEventListener("mousemove",AttrOpacityService.opacitySpanMouseMove);
      document.addEventListener("mouseup",AttrOpacityService.opacityIconMouseUp);
    },
    opacityIconMouseUp:function(){
      document.removeEventListener("mousemove",AttrOpacityService.opacitySpanMouseMove);
      document.removeEventListener("mouseup",AttrOpacityService.opacityIconMouseUp);
    },
    opacityInput:function(){
      var e = window.event || arguments[0];
      if(e.keyCode == 13){
        var ele=$(getEvetTarget(e));
        var value=ele.val();
        if($.isNumeric(value)){
          value=parseInt(value);
          if(value>100){
            value=100;
          }
        }else{
          value=100;
        }
        $("#attr-opacity-shape").val(value+"%");
        changeOpacitySpanByInput(value);
        AttrOpacityService.changeShapeOpacity(value/100);
      }
      
    }
    
}
export default AttrOpacityService;