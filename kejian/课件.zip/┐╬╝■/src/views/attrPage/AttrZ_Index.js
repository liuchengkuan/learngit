import {h} from 'preact';
import EditAreaStore from 'stores/EditAreaStore';

export default function(props) {
  return (
    <div>
      <div className="attr-line-none" id="attr-arrange">
        <div className="attr-arrange-border">
          <span className="attr-arrange-button attr-border-right" onClick={EditAreaStore.end}><i className="attr-arrange-icon attr-arrange-icon-end"></i></span>
          <span className="attr-arrange-button" onClick={EditAreaStore.front}><i className="attr-arrange-icon attr-arrange-icon-first"></i></span>
        </div>
        <div className="attr-arrange-border attr-mleft">
          <span className="attr-arrange-button attr-border-right" onClick={EditAreaStore.prev}><i className="attr-arrange-icon attr-arrange-icon-backwards"></i></span>
          <span className="attr-arrange-button" onClick={EditAreaStore.next}><i className="attr-arrange-icon attr-arrange-icon-forward"></i></span>
        </div>
      </div>
      <div className="attr-line-none" id="attr-arrange-text">
        <span className="attr-arrange-text">最后</span>
        <span className="attr-arrange-text">最前</span>
        <span className="attr-arrange-text attr-mleft">向后</span>
        <span className="attr-arrange-text">向前</span>
      </div>
      <div className="attr-line">
        <div className="attr-line-border" />
      </div>
    </div>
  )
}