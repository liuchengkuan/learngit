/**
 * 状态变量类
 * @auto  庄召
 */
const CpRundata = {
  shapeOriginalData: [], // 图形操作前的数据状态，目前应用场景是移动和拖动
  txtDownByMove:false //控制shaape等按下的事件是否可以使用拖动功能，比如文本输入框在输入框按下时不能触发推动功能。
}

export default CpRundata;
