/**
 * 公共常量类
 * @auto  庄召，马君保
 */
const CpConst = {

  txt_help_width: 7,
  //样式按钮对应的所有样式
  id_styleArr: [{ id: 'font_style_b', styleKey: 'fontWeight' }],
  maximum_angle: 360, // 一圈360度

}

/**
 * 图形类型常量
 */
const SHAPE_TYPE = {
  RECT: 0,
  SQUARE: 1,
  ROUND_RECT: 2
}

export default CpConst;
export { SHAPE_TYPE };
