/**
 * 公共基础方法 ,基础方法都放这个里面来
 * @auto  庄召，马君保
 */
import CpConst from './CpConst';

const CpUtil = {

  //判断文字应该有多宽
  findvisualLength: function (val, currTxtAreaEle) {
    var ruler = $("#textAreaHelpSpan");
    ruler.text(val);
    /*ruler.css('font-size', currTxtAreaEle.css('font-size'));
    var style = currTxtAreaEle[0].style;
    for (var i = 0, len = style.length; i < len; i++) {
      var prop = style[i]
       console.log("prop:"+prop);
      ruler.css(prop, style.getPropertyValue(prop));
    }*/

    var id_styleArr = CpConst.id_styleArr;
    for (var i in id_styleArr) {
      var obj = id_styleArr[i];
      var styKey = obj.styleKey;
      ruler.css(styKey, currTxtAreaEle.css(styKey));
      // console.log("prop:"+currTxtAreaEle.css(styKey));
    }

    return ruler[0].offsetWidth;
  },

  uuid(long) {
    let uuid = '';
    let max = long || 32;
    for (let i = 0; i < max; i++) {
      let random = Math.random() * 16 | 0;
      if (i === 8 || i === 12 || i === 16 || i === 20) {
        uuid += '-';
      }
      uuid += (i === 12 ? 4 : (i === 16 ? (random & 3 | 8) : random)).toString(16);
    }
    return uuid;
  }

}

export default CpUtil;
