const path = require('path');
const webpack = require('webpack');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

const buildPath = '_build';

module.exports = {
  entry: './src/root',
  output: {
    path: path.resolve(__dirname, buildPath),
    filename: 'bundle.js',
    publicPath: ''
  },
  resolve: {
    modules: [path.resolve(__dirname, "src"), "node_modules"]
  },
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        exclude: 'node_modules',
        loader: 'babel-loader',
        options: {
          "plugins": [
            ["transform-react-jsx", {"pragma": "h"}],
            "transform-class-properties",
            "transform-object-rest-spread"
          ],
          "presets": ["es2015"]
        }
      },
      {
        test: /\.css$/,
        loader: ExtractTextPlugin.extract({
          fallbackLoader: 'style-loader',
          loader: 'css-loader!postcss-loader'
        })
      },
      { test: /\.(jpe?g|png|gif|svg)$/i, exclude: /(node_modules|bower_components)/, loader: 'url-loader?limit=1000&name=images/[name].[ext]' }, // IMAGES
      { test: /root.html?$/, loader: 'file-loader?name=index.[ext]' }
    ]
  },
   plugins: [
    new ExtractTextPlugin('./bundle.css')
  ],
  devServer: {
    contentBase: [path.resolve(__dirname, buildPath)],
    inline: true,
    host: '0.0.0.0',
    port: 8866
  }
}
