/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.l = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };

/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};

/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};

/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 64);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

!function (global, factory) {
    'object' == ( false ? 'undefined' : _typeof(exports)) && 'undefined' != typeof module ? factory(exports) :  true ? !(__WEBPACK_AMD_DEFINE_ARRAY__ = [exports], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)) : factory(global.preact = global.preact || {});
}(undefined, function (exports) {
    function VNode(nodeName, attributes, children) {
        this.nodeName = nodeName;
        this.attributes = attributes;
        this.children = children;
        this.key = attributes && attributes.key;
    }
    function h(nodeName, attributes) {
        var children, lastSimple, child, simple, i;
        for (i = arguments.length; i-- > 2;) {
            stack.push(arguments[i]);
        }if (attributes && attributes.children) {
            if (!stack.length) stack.push(attributes.children);
            delete attributes.children;
        }
        while (stack.length) {
            if ((child = stack.pop()) instanceof Array) for (i = child.length; i--;) {
                stack.push(child[i]);
            } else if (null != child && child !== !0 && child !== !1) {
                if ('number' == typeof child) child = String(child);
                simple = 'string' == typeof child;
                if (simple && lastSimple) children[children.length - 1] += child;else {
                    (children || (children = [])).push(child);
                    lastSimple = simple;
                }
            }
        }var p = new VNode(nodeName, attributes || void 0, children || EMPTY_CHILDREN);
        if (options.vnode) options.vnode(p);
        return p;
    }
    function extend(obj, props) {
        if (props) for (var i in props) {
            obj[i] = props[i];
        }return obj;
    }
    function clone(obj) {
        return extend({}, obj);
    }
    function delve(obj, key) {
        for (var p = key.split('.'), i = 0; i < p.length && obj; i++) {
            obj = obj[p[i]];
        }return obj;
    }
    function isFunction(obj) {
        return 'function' == typeof obj;
    }
    function isString(obj) {
        return 'string' == typeof obj;
    }
    function hashToClassName(c) {
        var str = '';
        for (var prop in c) {
            if (c[prop]) {
                if (str) str += ' ';
                str += prop;
            }
        }return str;
    }
    function cloneElement(vnode, props) {
        return h(vnode.nodeName, extend(clone(vnode.attributes), props), arguments.length > 2 ? [].slice.call(arguments, 2) : vnode.children);
    }
    function createLinkedState(component, key, eventPath) {
        var path = key.split('.');
        return function (e) {
            var t = e && e.target || this,
                state = {},
                obj = state,
                v = isString(eventPath) ? delve(e, eventPath) : t.nodeName ? t.type.match(/^che|rad/) ? t.checked : t.value : e,
                i = 0;
            for (; i < path.length - 1; i++) {
                obj = obj[path[i]] || (obj[path[i]] = !i && component.state[path[i]] || {});
            }obj[path[i]] = v;
            component.setState(state);
        };
    }
    function enqueueRender(component) {
        if (!component._dirty && (component._dirty = !0) && 1 == items.push(component)) (options.debounceRendering || defer)(rerender);
    }
    function rerender() {
        var p,
            list = items;
        items = [];
        while (p = list.pop()) {
            if (p._dirty) renderComponent(p);
        }
    }
    function isFunctionalComponent(vnode) {
        var nodeName = vnode && vnode.nodeName;
        return nodeName && isFunction(nodeName) && !(nodeName.prototype && nodeName.prototype.render);
    }
    function buildFunctionalComponent(vnode, context) {
        return vnode.nodeName(getNodeProps(vnode), context || EMPTY);
    }
    function isSameNodeType(node, vnode) {
        if (isString(vnode)) return node instanceof Text;
        if (isString(vnode.nodeName)) return !node._componentConstructor && isNamedNode(node, vnode.nodeName);
        if (isFunction(vnode.nodeName)) return (node._componentConstructor ? node._componentConstructor === vnode.nodeName : !0) || isFunctionalComponent(vnode);else ;
    }
    function isNamedNode(node, nodeName) {
        return node.normalizedNodeName === nodeName || toLowerCase(node.nodeName) === toLowerCase(nodeName);
    }
    function getNodeProps(vnode) {
        var props = clone(vnode.attributes);
        props.children = vnode.children;
        var defaultProps = vnode.nodeName.defaultProps;
        if (defaultProps) for (var i in defaultProps) {
            if (void 0 === props[i]) props[i] = defaultProps[i];
        }return props;
    }
    function removeNode(node) {
        var p = node.parentNode;
        if (p) p.removeChild(node);
    }
    function setAccessor(node, name, old, value, isSvg) {
        if ('className' === name) name = 'class';
        if ('class' === name && value && 'object' == (typeof value === 'undefined' ? 'undefined' : _typeof(value))) value = hashToClassName(value);
        if ('key' === name) ;else if ('class' === name && !isSvg) node.className = value || '';else if ('style' === name) {
            if (!value || isString(value) || isString(old)) node.style.cssText = value || '';
            if (value && 'object' == (typeof value === 'undefined' ? 'undefined' : _typeof(value))) {
                if (!isString(old)) for (var i in old) {
                    if (!(i in value)) node.style[i] = '';
                }for (var i in value) {
                    node.style[i] = 'number' == typeof value[i] && !NON_DIMENSION_PROPS[i] ? value[i] + 'px' : value[i];
                }
            }
        } else if ('dangerouslySetInnerHTML' === name) {
            if (value) node.innerHTML = value.__html || '';
        } else if ('o' == name[0] && 'n' == name[1]) {
            var l = node._listeners || (node._listeners = {});
            name = toLowerCase(name.substring(2));
            if (value) {
                if (!l[name]) node.addEventListener(name, eventProxy, !!NON_BUBBLING_EVENTS[name]);
            } else if (l[name]) node.removeEventListener(name, eventProxy, !!NON_BUBBLING_EVENTS[name]);
            l[name] = value;
        } else if ('list' !== name && 'type' !== name && !isSvg && name in node) {
            setProperty(node, name, null == value ? '' : value);
            if (null == value || value === !1) node.removeAttribute(name);
        } else {
            var ns = isSvg && name.match(/^xlink\:?(.+)/);
            if (null == value || value === !1) {
                if (ns) node.removeAttributeNS('http://www.w3.org/1999/xlink', toLowerCase(ns[1]));else node.removeAttribute(name);
            } else if ('object' != (typeof value === 'undefined' ? 'undefined' : _typeof(value)) && !isFunction(value)) if (ns) node.setAttributeNS('http://www.w3.org/1999/xlink', toLowerCase(ns[1]), value);else node.setAttribute(name, value);
        }
    }
    function setProperty(node, name, value) {
        try {
            node[name] = value;
        } catch (e) {}
    }
    function eventProxy(e) {
        return this._listeners[e.type](options.event && options.event(e) || e);
    }
    function collectNode(node) {
        removeNode(node);
        if (node instanceof Element) {
            node._component = node._componentConstructor = null;
            var _name = node.normalizedNodeName || toLowerCase(node.nodeName);
            (nodes[_name] || (nodes[_name] = [])).push(node);
        }
    }
    function createNode(nodeName, isSvg) {
        var name = toLowerCase(nodeName),
            node = nodes[name] && nodes[name].pop() || (isSvg ? document.createElementNS('http://www.w3.org/2000/svg', nodeName) : document.createElement(nodeName));
        node.normalizedNodeName = name;
        return node;
    }
    function flushMounts() {
        var c;
        while (c = mounts.pop()) {
            if (options.afterMount) options.afterMount(c);
            if (c.componentDidMount) c.componentDidMount();
        }
    }
    function diff(dom, vnode, context, mountAll, parent, componentRoot) {
        if (!diffLevel++) {
            isSvgMode = parent && 'undefined' != typeof parent.ownerSVGElement;
            hydrating = dom && !(ATTR_KEY in dom);
        }
        var ret = idiff(dom, vnode, context, mountAll);
        if (parent && ret.parentNode !== parent) parent.appendChild(ret);
        if (! --diffLevel) {
            hydrating = !1;
            if (!componentRoot) flushMounts();
        }
        return ret;
    }
    function idiff(dom, vnode, context, mountAll) {
        var ref = vnode && vnode.attributes && vnode.attributes.ref;
        while (isFunctionalComponent(vnode)) {
            vnode = buildFunctionalComponent(vnode, context);
        }if (null == vnode) vnode = '';
        if (isString(vnode)) {
            if (dom && dom instanceof Text && dom.parentNode) {
                if (dom.nodeValue != vnode) dom.nodeValue = vnode;
            } else {
                if (dom) recollectNodeTree(dom);
                dom = document.createTextNode(vnode);
            }
            return dom;
        }
        if (isFunction(vnode.nodeName)) return buildComponentFromVNode(dom, vnode, context, mountAll);
        var out = dom,
            nodeName = String(vnode.nodeName),
            prevSvgMode = isSvgMode,
            vchildren = vnode.children;
        isSvgMode = 'svg' === nodeName ? !0 : 'foreignObject' === nodeName ? !1 : isSvgMode;
        if (!dom) out = createNode(nodeName, isSvgMode);else if (!isNamedNode(dom, nodeName)) {
            out = createNode(nodeName, isSvgMode);
            while (dom.firstChild) {
                out.appendChild(dom.firstChild);
            }if (dom.parentNode) dom.parentNode.replaceChild(out, dom);
            recollectNodeTree(dom);
        }
        var fc = out.firstChild,
            props = out[ATTR_KEY];
        if (!props) {
            out[ATTR_KEY] = props = {};
            for (var a = out.attributes, i = a.length; i--;) {
                props[a[i].name] = a[i].value;
            }
        }
        if (!hydrating && vchildren && 1 === vchildren.length && 'string' == typeof vchildren[0] && fc && fc instanceof Text && !fc.nextSibling) {
            if (fc.nodeValue != vchildren[0]) fc.nodeValue = vchildren[0];
        } else if (vchildren && vchildren.length || fc) innerDiffNode(out, vchildren, context, mountAll, !!props.dangerouslySetInnerHTML);
        diffAttributes(out, vnode.attributes, props);
        if (ref) (props.ref = ref)(out);
        isSvgMode = prevSvgMode;
        return out;
    }
    function innerDiffNode(dom, vchildren, context, mountAll, absorb) {
        var j,
            c,
            vchild,
            child,
            originalChildren = dom.childNodes,
            children = [],
            keyed = {},
            keyedLen = 0,
            min = 0,
            len = originalChildren.length,
            childrenLen = 0,
            vlen = vchildren && vchildren.length;
        if (len) for (var i = 0; i < len; i++) {
            var _child = originalChildren[i],
                props = _child[ATTR_KEY],
                key = vlen ? (c = _child._component) ? c.__key : props ? props.key : null : null;
            if (null != key) {
                keyedLen++;
                keyed[key] = _child;
            } else if (hydrating || absorb || props || _child instanceof Text) children[childrenLen++] = _child;
        }
        if (vlen) for (var i = 0; i < vlen; i++) {
            vchild = vchildren[i];
            child = null;
            var key = vchild.key;
            if (null != key) {
                if (keyedLen && key in keyed) {
                    child = keyed[key];
                    keyed[key] = void 0;
                    keyedLen--;
                }
            } else if (!child && min < childrenLen) for (j = min; j < childrenLen; j++) {
                c = children[j];
                if (c && isSameNodeType(c, vchild)) {
                    child = c;
                    children[j] = void 0;
                    if (j === childrenLen - 1) childrenLen--;
                    if (j === min) min++;
                    break;
                }
            }
            child = idiff(child, vchild, context, mountAll);
            if (child && child !== dom) if (i >= len) dom.appendChild(child);else if (child !== originalChildren[i]) {
                if (child === originalChildren[i + 1]) removeNode(originalChildren[i]);
                dom.insertBefore(child, originalChildren[i] || null);
            }
        }
        if (keyedLen) for (var i in keyed) {
            if (keyed[i]) recollectNodeTree(keyed[i]);
        }while (min <= childrenLen) {
            child = children[childrenLen--];
            if (child) recollectNodeTree(child);
        }
    }
    function recollectNodeTree(node, unmountOnly) {
        var component = node._component;
        if (component) unmountComponent(component, !unmountOnly);else {
            if (node[ATTR_KEY] && node[ATTR_KEY].ref) node[ATTR_KEY].ref(null);
            if (!unmountOnly) collectNode(node);
            var c;
            while (c = node.lastChild) {
                recollectNodeTree(c, unmountOnly);
            }
        }
    }
    function diffAttributes(dom, attrs, old) {
        var name;
        for (name in old) {
            if (!(attrs && name in attrs) && null != old[name]) setAccessor(dom, name, old[name], old[name] = void 0, isSvgMode);
        }if (attrs) for (name in attrs) {
            if (!('children' === name || 'innerHTML' === name || name in old && attrs[name] === ('value' === name || 'checked' === name ? dom[name] : old[name]))) setAccessor(dom, name, old[name], old[name] = attrs[name], isSvgMode);
        }
    }
    function collectComponent(component) {
        var name = component.constructor.name,
            list = components[name];
        if (list) list.push(component);else components[name] = [component];
    }
    function createComponent(Ctor, props, context) {
        var inst = new Ctor(props, context),
            list = components[Ctor.name];
        Component.call(inst, props, context);
        if (list) for (var i = list.length; i--;) {
            if (list[i].constructor === Ctor) {
                inst.nextBase = list[i].nextBase;
                list.splice(i, 1);
                break;
            }
        }return inst;
    }
    function setComponentProps(component, props, opts, context, mountAll) {
        if (!component._disable) {
            component._disable = !0;
            if (component.__ref = props.ref) delete props.ref;
            if (component.__key = props.key) delete props.key;
            if (!component.base || mountAll) {
                if (component.componentWillMount) component.componentWillMount();
            } else if (component.componentWillReceiveProps) component.componentWillReceiveProps(props, context);
            if (context && context !== component.context) {
                if (!component.prevContext) component.prevContext = component.context;
                component.context = context;
            }
            if (!component.prevProps) component.prevProps = component.props;
            component.props = props;
            component._disable = !1;
            if (0 !== opts) if (1 === opts || options.syncComponentUpdates !== !1 || !component.base) renderComponent(component, 1, mountAll);else enqueueRender(component);
            if (component.__ref) component.__ref(component);
        }
    }
    function renderComponent(component, opts, mountAll, isChild) {
        if (!component._disable) {
            var skip,
                rendered,
                inst,
                cbase,
                props = component.props,
                state = component.state,
                context = component.context,
                previousProps = component.prevProps || props,
                previousState = component.prevState || state,
                previousContext = component.prevContext || context,
                isUpdate = component.base,
                nextBase = component.nextBase,
                initialBase = isUpdate || nextBase,
                initialChildComponent = component._component;
            if (isUpdate) {
                component.props = previousProps;
                component.state = previousState;
                component.context = previousContext;
                if (2 !== opts && component.shouldComponentUpdate && component.shouldComponentUpdate(props, state, context) === !1) skip = !0;else if (component.componentWillUpdate) component.componentWillUpdate(props, state, context);
                component.props = props;
                component.state = state;
                component.context = context;
            }
            component.prevProps = component.prevState = component.prevContext = component.nextBase = null;
            component._dirty = !1;
            if (!skip) {
                if (component.render) rendered = component.render(props, state, context);
                if (component.getChildContext) context = extend(clone(context), component.getChildContext());
                while (isFunctionalComponent(rendered)) {
                    rendered = buildFunctionalComponent(rendered, context);
                }var toUnmount,
                    base,
                    childComponent = rendered && rendered.nodeName;
                if (isFunction(childComponent)) {
                    var childProps = getNodeProps(rendered);
                    inst = initialChildComponent;
                    if (inst && inst.constructor === childComponent && childProps.key == inst.__key) setComponentProps(inst, childProps, 1, context);else {
                        toUnmount = inst;
                        inst = createComponent(childComponent, childProps, context);
                        inst.nextBase = inst.nextBase || nextBase;
                        inst._parentComponent = component;
                        component._component = inst;
                        setComponentProps(inst, childProps, 0, context);
                        renderComponent(inst, 1, mountAll, !0);
                    }
                    base = inst.base;
                } else {
                    cbase = initialBase;
                    toUnmount = initialChildComponent;
                    if (toUnmount) cbase = component._component = null;
                    if (initialBase || 1 === opts) {
                        if (cbase) cbase._component = null;
                        base = diff(cbase, rendered, context, mountAll || !isUpdate, initialBase && initialBase.parentNode, !0);
                    }
                }
                if (initialBase && base !== initialBase && inst !== initialChildComponent) {
                    var baseParent = initialBase.parentNode;
                    if (baseParent && base !== baseParent) {
                        baseParent.replaceChild(base, initialBase);
                        if (!toUnmount) {
                            initialBase._component = null;
                            recollectNodeTree(initialBase);
                        }
                    }
                }
                if (toUnmount) unmountComponent(toUnmount, base !== initialBase);
                component.base = base;
                if (base && !isChild) {
                    var componentRef = component,
                        t = component;
                    while (t = t._parentComponent) {
                        (componentRef = t).base = base;
                    }base._component = componentRef;
                    base._componentConstructor = componentRef.constructor;
                }
            }
            if (!isUpdate || mountAll) mounts.unshift(component);else if (!skip) {
                if (component.componentDidUpdate) component.componentDidUpdate(previousProps, previousState, previousContext);
                if (options.afterUpdate) options.afterUpdate(component);
            }
            var fn,
                cb = component._renderCallbacks;
            if (cb) while (fn = cb.pop()) {
                fn.call(component);
            }if (!diffLevel && !isChild) flushMounts();
        }
    }
    function buildComponentFromVNode(dom, vnode, context, mountAll) {
        var c = dom && dom._component,
            originalComponent = c,
            oldDom = dom,
            isDirectOwner = c && dom._componentConstructor === vnode.nodeName,
            isOwner = isDirectOwner,
            props = getNodeProps(vnode);
        while (c && !isOwner && (c = c._parentComponent)) {
            isOwner = c.constructor === vnode.nodeName;
        }if (c && isOwner && (!mountAll || c._component)) {
            setComponentProps(c, props, 3, context, mountAll);
            dom = c.base;
        } else {
            if (originalComponent && !isDirectOwner) {
                unmountComponent(originalComponent, !0);
                dom = oldDom = null;
            }
            c = createComponent(vnode.nodeName, props, context);
            if (dom && !c.nextBase) {
                c.nextBase = dom;
                oldDom = null;
            }
            setComponentProps(c, props, 1, context, mountAll);
            dom = c.base;
            if (oldDom && dom !== oldDom) {
                oldDom._component = null;
                recollectNodeTree(oldDom);
            }
        }
        return dom;
    }
    function unmountComponent(component, remove) {
        if (options.beforeUnmount) options.beforeUnmount(component);
        var base = component.base;
        component._disable = !0;
        if (component.componentWillUnmount) component.componentWillUnmount();
        component.base = null;
        var inner = component._component;
        if (inner) unmountComponent(inner, remove);else if (base) {
            if (base[ATTR_KEY] && base[ATTR_KEY].ref) base[ATTR_KEY].ref(null);
            component.nextBase = base;
            if (remove) {
                removeNode(base);
                collectComponent(component);
            }
            var c;
            while (c = base.lastChild) {
                recollectNodeTree(c, !remove);
            }
        }
        if (component.__ref) component.__ref(null);
        if (component.componentDidUnmount) component.componentDidUnmount();
    }
    function Component(props, context) {
        this._dirty = !0;
        this.context = context;
        this.props = props;
        if (!this.state) this.state = {};
    }
    function render(vnode, parent, merge) {
        return diff(merge, vnode, {}, !1, parent);
    }
    var options = {};
    var stack = [];
    var EMPTY_CHILDREN = [];
    var lcCache = {};
    var toLowerCase = function toLowerCase(s) {
        return lcCache[s] || (lcCache[s] = s.toLowerCase());
    };
    var resolved = 'undefined' != typeof Promise && Promise.resolve();
    var defer = resolved ? function (f) {
        resolved.then(f);
    } : setTimeout;
    var EMPTY = {};
    var ATTR_KEY = 'undefined' != typeof Symbol ? Symbol.for('preactattr') : '__preactattr_';
    var NON_DIMENSION_PROPS = {
        boxFlex: 1,
        boxFlexGroup: 1,
        columnCount: 1,
        fillOpacity: 1,
        flex: 1,
        flexGrow: 1,
        flexPositive: 1,
        flexShrink: 1,
        flexNegative: 1,
        fontWeight: 1,
        lineClamp: 1,
        lineHeight: 1,
        opacity: 1,
        order: 1,
        orphans: 1,
        strokeOpacity: 1,
        widows: 1,
        zIndex: 1,
        zoom: 1
    };
    var NON_BUBBLING_EVENTS = {
        blur: 1,
        error: 1,
        focus: 1,
        load: 1,
        resize: 1,
        scroll: 1
    };
    var items = [];
    var nodes = {};
    var mounts = [];
    var diffLevel = 0;
    var isSvgMode = !1;
    var hydrating = !1;
    var components = {};
    extend(Component.prototype, {
        linkState: function linkState(key, eventPath) {
            var c = this._linkedStates || (this._linkedStates = {});
            return c[key + eventPath] || (c[key + eventPath] = createLinkedState(this, key, eventPath));
        },
        setState: function setState(state, callback) {
            var s = this.state;
            if (!this.prevState) this.prevState = clone(s);
            extend(s, isFunction(state) ? state(s, this.props) : state);
            if (callback) (this._renderCallbacks = this._renderCallbacks || []).push(callback);
            enqueueRender(this);
        },
        forceUpdate: function forceUpdate() {
            renderComponent(this, 2);
        },
        render: function render() {}
    });
    exports.h = h;
    exports.cloneElement = cloneElement;
    exports.Component = Component;
    exports.render = render;
    exports.rerender = rerender;
    exports.options = options;
});
//# sourceMappingURL=preact.js.map

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _preact = __webpack_require__(0);

var _DragCore = __webpack_require__(5);

var _DragCore2 = _interopRequireDefault(_DragCore);

var _ResizeCore = __webpack_require__(34);

var _ResizeCore2 = _interopRequireDefault(_ResizeCore);

var _RotateCore = __webpack_require__(35);

var _RotateCore2 = _interopRequireDefault(_RotateCore);

var _CpRundata = __webpack_require__(13);

var _CpRundata2 = _interopRequireDefault(_CpRundata);

var _CpConst = __webpack_require__(9);

var _CpConst2 = _interopRequireDefault(_CpConst);

var _TxtService = __webpack_require__(10);

var _TxtService2 = _interopRequireDefault(_TxtService);

var _EditAreaStore = __webpack_require__(2);

var _EditAreaStore2 = _interopRequireDefault(_EditAreaStore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * 用于图形、图像的大小、位置、角度、缩放等转换
 *
 * @author Ma Junbao <mlive@live.cn>
 * @date 2017-02-22
 */
function Transform(props) {
  var maxAngle = _CpConst2.default.maximum_angle;
  var dx = 0,
      dy = 0,
      mx = 0,
      my = 0;
  var elementOffset = { x: 0, y: 0 };

  // 矫正缩放偏移量
  var _deviationScale = function _deviationScale(data) {
    if (props.layout.scale !== 1) {
      data.mx = data.mx / props.layout.scale;
      data.my = data.my / props.layout.scale;
    }
  };

  // 纠正旋转偏移量


  var setOldData = function setOldData() {
    _CpRundata2.default.shapeOriginalData = [];
    var startData = props.getCanvasBySelected();
    for (var i in startData) {
      _CpRundata2.default.shapeOriginalData.push(_extends({}, startData[i]));
    }
  };

  var onDragStart = function onDragStart(data) {
    _CpRundata2.default.txtDownByMove = false; //这个元素按下，默认开启移动,文本元素已经阻止了事件，所以这儿可以怎么做。add by 20170207

    props.onSelectCanvas(props.id);
    setOldData();
  };

  var onDrag = function onDrag(data) {

    if (_CpRundata2.default.txtDownByMove == true) {
      return;
    }

    var _selected = props.getCanvasBySelected();
    // 矫正偏移量
    _deviationScale(data);

    for (var i in _CpRundata2.default.shapeOriginalData) {
      var startData = _CpRundata2.default.shapeOriginalData[i];
      var currData = props.getCanvasById(startData.id);

      currData.x = startData.x + data.mx;
      currData.y = startData.y + data.my;

      props.onUpdataCanvasById(currData.id, currData);
    }
  };

  // x,y计算逻辑 给onResize时候用 
  var computeonResize = function computeonResize(data, startData, currData) {

    typeof props.onResize == 'function' && props.onResize(data);

    var angle = props.rotate;

    if (data.left) {
      currData.width = startData.width - data.mx;
      if (currData.width >= 0) {
        // currData.x = startData.x + data.mx;
      } else {
        currData.width = Math.abs(currData.width);
      }
    }

    if (data.right) {
      currData.width = startData.width + data.mx;
      if (currData.width >= 0) {} else {
        currData.width = Math.abs(currData.width);
        currData.x = startData.x - currData.width;
      }
    }

    if (data.top) {
      currData.height = startData.height - data.my;
      if (currData.height >= 0) {
        currData.y = startData.y + data.my;
      } else {
        currData.height = Math.abs(currData.height);
      }
    }

    if (data.bottom) {
      currData.height = startData.height + data.my;
      if (currData.height >= 0) {} else {
        currData.height = Math.abs(currData.height);
        currData.y = startData.y - currData.height;
      }
    }

    props.onUpdataCanvasById(currData.id, currData);
  };

  var onResizeStart = function onResizeStart(data) {
    typeof props.onResizeStart == 'function' && props.onResizeStart(data);

    var _offset = $(".edit-area-canvas").offset();
    elementOffset.x = _offset.left;
    elementOffset.y = _offset.top;

    setOldData();
  };

  var onResize = function onResize(data) {
    // 矫正偏移量
    _deviationScale(data);
    for (var i in _CpRundata2.default.shapeOriginalData) {
      var startData = _CpRundata2.default.shapeOriginalData[i];
      var currData = props.getCanvasById(startData.id);

      // 坐标和宽、高逻辑
      computeonResize(data, startData, currData);

      // 增加文本框特殊处理，add by zhuangzhao 20170207
      if (currData.type == 'txt') {
        if (currData == null) {
          console.log("当前对象currData is null");
        }
        _TxtService2.default.setTxtSizeByTransform(currData);
      }
    }
  };

  var rotatePoint = { x: 0, y: 0 };
  var rotateNode = void 0;

  var rotateNewPoint = { x: 0, y: 0 };

  var onRotateStart = function onRotateStart(data) {
    props.onSelectCanvas(props.id);

    setOldData();
    rotateNode = $(data.node).parents('.cp-layer');
    var offset = rotateNode.offset();
    var id = rotateNode.attr('id');
    var canvas = _EditAreaStore2.default.getCanvasById(id);

    var editArea = {};
    editArea.x = $('.edit-area-canvas').offset().left;
    editArea.y = $('.edit-area-canvas').offset().top;

    // 修正偏移
    var dCanvas = {};
    dCanvas.x = canvas.x * props.layout.scale;
    dCanvas.y = canvas.y * props.layout.scale;
    dCanvas.width = canvas.width * props.layout.scale;
    dCanvas.height = canvas.height * props.layout.scale;

    rotatePoint.x = dCanvas.x + editArea.x + (dCanvas.width && dCanvas.width / 2);
    rotatePoint.y = dCanvas.y + editArea.y + (dCanvas.height && dCanvas.height / 2);
  };
  var onRotate = function onRotate(data) {

    var dx = data.x - rotatePoint.x;
    var dy = data.y - rotatePoint.y;
    var radian = Math.atan2(dy, dx);
    var angle = radian * 180 / Math.PI + 90;

    var id = rotateNode.attr('id');
    _EditAreaStore2.default.updataCanvasById(id, { rotate: angle });
  };
  var onRotateEnd = function onRotateEnd(data) {
    console.log(rotateNode.offset());
  };

  var style = {
    position: 'absolute',
    width: props.width,
    height: props.height,
    left: props.x,
    top: props.y,
    transform: 'rotate(' + props.rotate + 'deg)'
  };

  return (0, _preact.h)(
    'div',
    { style: style, id: props.id, className: 'cp-layer' },
    (0, _preact.h)(_RotateCore2.default, { onRotate: onRotate, onRotateStart: onRotateStart, onRotateEnd: onRotateEnd }),
    (0, _preact.h)(_ResizeCore2.default, _extends({}, props, { onResize: onResize, onResizeStart: onResizeStart })),
    (0, _preact.h)(
      _DragCore2.default,
      { onDrag: onDrag, onDragStart: onDragStart },
      props.children
    )
  );
}

exports.default = Transform;

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _RootStore2 = __webpack_require__(8);

var _RootStore3 = _interopRequireDefault(_RootStore2);

var _LayoutStore = __webpack_require__(3);

var _LayoutStore2 = _interopRequireDefault(_LayoutStore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                * 编辑区类
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                * author 马君保
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                */

/**
 * 表示编辑区的类
 * @extends {RootStore}
 */
var EditAreaStore = function (_RootStore) {
  _inherits(EditAreaStore, _RootStore);

  function EditAreaStore() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, EditAreaStore);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = EditAreaStore.__proto__ || Object.getPrototypeOf(EditAreaStore)).call.apply(_ref, [this].concat(args))), _this), _this._canvasList = [], _this.addCanvas = function (newData) {
      _this._someValueToNumber(newData);
      _this._canvasList.push(newData);
      _this.selectCanvasById(newData.id);
      _this.emit();
    }, _this.selectCanvasById = function (id) {
      if (!id) return;
      for (var i in _this._canvasList) {
        var tempData = _this._canvasList[i];
        if (tempData.id == id) {
          tempData.isSelected = true;
        } else {
          tempData.isSelected = false;
        }
      }
      _this.emit();
    }, _this.selectCanvas = function (id) {
      if (!id) return;
      var _notSelect = true;
      // 判断是否被选中
      if (_this.getCanvasById(id).isSelected == true) {
        _notSelect = false;
      };

      if (_notSelect) {
        _this.selectCanvasById(id);
      }

      _this.emit();
    }, _this.selectCanvasByRect = function (rectObj) {
      var width = rectObj.width,
          height = rectObj.height,
          x = rectObj.x,
          y = rectObj.y;

      var x2 = x + width,
          y2 = y + height;
      for (var i in _this._canvasList) {
        var tempData = _this._canvasList[i];
        var computedX = tempData.x;
        var computedY = tempData.y;
        var computedX2 = computedX + tempData.width;
        var computedY2 = computedY + tempData.height;
        if (x <= computedX && x2 >= computedX2 && y <= computedY && y2 >= computedY2) {
          tempData.isSelected = true;
        } else {
          tempData.isSelected = false;
        }
      }
      _this.emit();
    }, _this.cancelSelected = function () {
      for (var i in _this._canvasList) {
        var tempData = _this._canvasList[i];
        tempData.isSelected = false;
      }
      _this.emit();
    }, _this.getCanvasBySelected = function () {
      var _selected = [];
      for (var i in _this._canvasList) {
        var tempData = _this._canvasList[i];
        if (tempData.isSelected == true) {
          _selected.push(tempData);
        };
      }
      return _selected;
    }, _this.getCanvasIdBySelected = function () {
      var _selectedId = [];
      var _selected = _this.getCanvasBySelected();
      for (var i in _selected) {
        _selectedId.push(_selected[i].id);
      }
      return _selectedId;
    }, _this.getCanvasById = function (id) {
      for (var i in _this._canvasList) {
        var tempData = _this._canvasList[i];
        if (tempData.id == id) {
          return tempData;
        }
      }
    }, _this.getCanvasList = function () {
      return this._canvasList;
    }, _this.updataSelectedCanvasByVaule = function (updateData) {
      var _selected = _this.getCanvasBySelected();

      var _loop = function _loop(i) {
        var nowCanvas = _selected[i];
        // 只改变选中的组件样式
        if (nowCanvas.isSelected === true) {
          _this._someValueToNumber(updateData);
          Object.keys(updateData).forEach(function (key) {
            nowCanvas[key] = updateData[key];
          });
        }
      };

      for (var i in _selected) {
        _loop(i);
      }
      _this.emit();
    }, _this.updataCanvasById = function (id, updateData) {
      if (!id) return;
      var _selected = _this._canvasList;

      var _loop2 = function _loop2(i) {
        var nowCanvas = _selected[i];
        if (nowCanvas.id == id) {
          _this._someValueToNumber(updateData);
          Object.keys(updateData).forEach(function (key) {
            nowCanvas[key] = updateData[key];
          });
          _this.emit();
        }
      };

      for (var i in _selected) {
        _loop2(i);
      }
    }, _this.deleteCanvas = function () {}, _this.updataSelectedCanvasByDiff = function (diffData) {
      var _selected = _this.getCanvasBySelected();
      console.log();

      var _loop3 = function _loop3(i) {
        var nowCanvas = _selected[i];
        _this._someValueToNumber(diffData);
        Object.keys(diffData).forEach(function (key) {
          nowCanvas[key] = diffData[key];
        });
      };

      for (var i in _selected) {
        _loop3(i);
      }
      _this.emit();
    }, _this.updateTableData = function (tableEleBo) {
      var table = _this.getCanvasById(tableEleBo.id);
      table.tableRow = tableEleBo.tableRow;
      table.tableCol = tableEleBo.tableCol;
      table.tr = tableEleBo.tr;
      table.isNewTable = false;
      table.width = tableEleBo.width;
      table.height = tableEleBo.height;
      //可以实时渲染，只要改变存储的数据就行
      _this.emit();
    }, _this.getState = function () {
      return _this._canvasList;
    }, _this._someValueToNumber = function (obj) {
      obj.x && (obj.x = parseInt(obj.x));
      obj.y && (obj.y = parseInt(obj.y));
      obj.width && (obj.width = parseInt(obj.width));
      obj.height && (obj.height = parseInt(obj.height));
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  /**
   * 在画布中添加新元素
   * @param  {object} newData 新元素属性对象
   * @return {undefined}
   * 
   * 
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-12
   */


  /**
   * 选中指定ID的第一个元素
   * @param  {number|string} id 元素ID
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @deprecated 2016-12-12
   */


  /**
   * 选中指定ID的第一个元素；当多选时，忽略传入ID，保持原有选择
   * @param  {number|string} id 元素ID
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @deprecated 2016-12-06
   */


  /**
   * 选中在矩形范围内的所有元素
   * @param  {object} rectObj 矩形对象
   * @param  {number} rectObj.width 矩形宽度
   * @param  {number} rectObj.height 矩形高度
   * @param  {number} rectObj.x 矩形x点
   * @param  {number} rectObj.y 矩形y点
   * @param  {number} rectObj.canvasLeft 画布与左侧导航区的距离
   * @param  {number} rectObj.canvasTop 画布与顶部菜单栏的距离
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-20
   */


  /**
   * 取消画布中选中的元素
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-23
   */


  /**
   * 获取选中的元素
   * @return {array} 元素数组
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-23
   */


  /**
   * 获取选中的元素的ID
   * @return {array} 元素ID数组
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-23
   */


  /**
   * 根据id获取对应的元素
   * @param  {number|string} id 元素ID
   * @return {object|undefined} 查找到的对象，若无返回undefined
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-24
   */


  /**
   * 获取画布中所有的元素
   * @return {object|undefined} 所有页面元素
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-24
   */


  /**
   * 改变选中元素的样式
   * @param {object} updateData 元素的新值
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-24
   */


  /**
   * 根据id改变对应的元素
   * @param {number|string} id 元素的ID
   * @param {object} updateData 元素的新值
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-24
   */


  // 删除选中的元素


  // 更新选中的元素
  /**
   * @param  {object} diffData 元素的旧值
   * @param  {object} diffData 元素的新值
   * @return {undefined}
   *
   * @author Ma Junbao <mlive@live.cn>
   * @date 2016-12-26
   */

  /**
  *重新复制表格数据
  */

  /*
   * 私有方法
   */

  // 确保传入参数是数字


  return EditAreaStore;
}(_RootStore3.default);

exports.default = new EditAreaStore();

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _RootStore2 = __webpack_require__(8);

var _RootStore3 = _interopRequireDefault(_RootStore2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                * 画布布局类
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                * author 马君保
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                */

var defaultLayout = {
  top: 60,
  left: 200,
  right: 270,
  minHeight: 650,
  mixWidth: 1000,
  editAreaWidth: 927,
  editAreaHeight: 698,
  editAreaCursor: 'default',
  scale: 1
};

var _layout = defaultLayout;

var LayoutStore = function (_RootStore) {
  _inherits(LayoutStore, _RootStore);

  function LayoutStore() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, LayoutStore);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = LayoutStore.__proto__ || Object.getPrototypeOf(LayoutStore)).call.apply(_ref, [this].concat(args))), _this), _this.getState = function () {
      return _layout;
    }, _this.updataLayout = function (config) {
      for (var key in config) {
        _layout[key] = config[key];
        // 不得不写 框架BUG
        if (key == 'scale') {
          $(".edit-area-canvas").css('transform', 'scale(' + config[key] + ')');
        }
      }
      _this.emit();
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  return LayoutStore;
}(_RootStore3.default);

exports.default = new LayoutStore();

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _CpConst = __webpack_require__(9);

var _CpConst2 = _interopRequireDefault(_CpConst);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CpUtil = {

  //判断文字应该有多宽
  findvisualLength: function findvisualLength(val, currTxtAreaEle) {
    var ruler = $("#textAreaHelpSpan");
    ruler.text(val);
    /*ruler.css('font-size', currTxtAreaEle.css('font-size'));
    var style = currTxtAreaEle[0].style;
    for (var i = 0, len = style.length; i < len; i++) {
      var prop = style[i]
       console.log("prop:"+prop);
      ruler.css(prop, style.getPropertyValue(prop));
    }*/

    var id_styleArr = _CpConst2.default.id_styleArr;
    for (var i in id_styleArr) {
      var obj = id_styleArr[i];
      var styKey = obj.styleKey;
      ruler.css(styKey, currTxtAreaEle.css(styKey));
      // console.log("prop:"+currTxtAreaEle.css(styKey));
    }

    return ruler[0].offsetWidth;
  },

  uuid: function uuid() {
    var uuid = '';
    for (var i = 0; i < 32; i++) {
      var random = Math.random() * 16 | 0;
      if (i === 8 || i === 12 || i === 16 || i === 20) {
        uuid += '-';
      }
      uuid += (i === 12 ? 4 : i === 16 ? random & 3 | 8 : random).toString(16);
    }
    return uuid;
  }
}; /**
    * 公共基础方法 ,基础方法都放这个里面来
    * @auto  庄召，马君保
    */
exports.default = CpUtil;

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Dom = __webpack_require__(33);

var _Event = __webpack_require__(16);

function DragCore(props) {
  var x = 0;
  var y = 0;
  var mx = 0;
  var my = 0;
  var dx = 0;
  var dy = 0;
  var darging = false;
  var canvasOffset = void 0;

  var returnData = function returnData(e) {
    return {
      x: e.pageX,
      y: e.pageY,
      canvasX: e.pageX - canvasOffset.left,
      canvasY: e.pageY - canvasOffset.top,
      mx: mx,
      my: my,
      dx: dx,
      dy: dy,
      lx: e.layerX,
      ly: e.layerY,
      event: e,
      node: e.target
    };
  };

  var handleDragStart = function handleDragStart(e) {
    var ownerDocument = document;

    x = e.pageX - mx;
    y = e.pageY - my;

    canvasOffset = $('.edit-area-canvas').offset();

    typeof props.onDragStart == 'function' && props.onDragStart(returnData(e));

    (0, _Dom.addEvent)(ownerDocument, 'mousemove', handleDrag);
    (0, _Dom.addEvent)(ownerDocument, 'mouseup', handleDragStop);
  };

  var handleDragStop = function handleDragStop(e) {
    e.stopPropagation();

    var ownerDocument = document;

    typeof props.onDragStop == 'function' && props.onDragStop(returnData(e));

    (0, _Dom.removeEvent)(ownerDocument, 'mousemove', handleDrag);
    (0, _Dom.removeEvent)(ownerDocument, 'mouseup', handleDragStop);
  };

  var handleDrag = function handleDrag(e) {
    e.stopPropagation();
    dx = mx;
    dy = my;
    mx = e.pageX - x;
    my = e.pageY - y;
    dx = mx - dx;
    dy = my - dy;
    typeof props.onDrag == 'function' && props.onDrag(returnData(e));
  };

  var onDragStart = function onDragStart(e) {
    e.stopPropagation();
    e.which == 1 && handleDragStart(e);
  };

  return (0, _preact.cloneElement)(props.children[0], {
    onMouseDown: onDragStart
  });
}

exports.default = DragCore;

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _EditAreaStore = __webpack_require__(2);

var _EditAreaStore2 = _interopRequireDefault(_EditAreaStore);

var _ElementBo = __webpack_require__(12);

var _ElementBo2 = _interopRequireDefault(_ElementBo);

var _TableEleBo = __webpack_require__(24);

var _TableEleBo2 = _interopRequireDefault(_TableEleBo);

var _CpUtil = __webpack_require__(4);

var _CpUtil2 = _interopRequireDefault(_CpUtil);

var _LayoutStore = __webpack_require__(3);

var _LayoutStore2 = _interopRequireDefault(_LayoutStore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var uuid = _CpUtil2.default.uuid;
//创建表格的列数
var tableCol = 0;
//创建表格的行数
var tableRow = 0;
//表格弹出框内鼠标移动动态变化的标志
var mouseover = false;
//点击事件时是点击页面需要弹框的元素还是其他元素
var clickFlag = true;
//显示或隐藏形状的弹出层
function showorOrHideShapePopUp() {
  try {
    if ($('#shapePopUpDiv').hasClass('hidden')) {
      $('#shapePopUpDiv').removeClass('hidden');
    } else {
      $('#shapePopUpDiv').addClass('hidden');
    }
  } catch (e) {
    console.error(e);
  }
}
//显示或隐藏表格的弹出层
function showorOrHideTablePopUp() {
  try {
    if ($('#tablePopUp').hasClass('hidden')) {
      $('#tablePopUp').removeClass('hidden');
    } else {
      $('#tablePopUp').addClass('hidden');
    }
  } catch (e) {
    console.error(e);
  }
}
var HeaderPageService = {
  //头部导航栏图形按钮点击事件
  shapeIconClick: function shapeIconClick(event) {
    try {
      $('#tablePopUp').addClass('hidden');
      showorOrHideShapePopUp();
      clickFlag = false;
    } catch (e) {
      console.error(e);
    }
  },
  //头部导航栏表格按钮点击事件
  tableIconClick: function tableIconClick(event) {

    try {
      $('#shapePopUpDiv').addClass('hidden');
      var span = $("#tablePopUpSpan").find("span");
      span.removeClass('on');
      tableCol = 0;
      tableRow = 0;
      $("#heeaderTableText").text(tableRow + '*' + tableCol + '表格');
      showorOrHideTablePopUp();
      mouseover = true;
      clickFlag = false;
    } catch (e) {
      console.error(e);
    }
  },

  tablePopUponMouseover: function tablePopUponMouseover(event) {
    if (mouseover) {
      var span = $("#tablePopUpSpan").find("span");
      span.removeClass('on');
      //改变弹出层的选中的td
      for (var i = 0; i < span.length; i++) {
        if (event.layerX >= span[i].offsetLeft && event.layerY >= span[i].offsetTop) {
          $(span[i]).addClass("on");
        }
      }
      //算账当前选择的行和列数量
      tableCol = parseInt((event.layerX - 8) / 23) + 1;
      if ((event.layerY - 41) / 23 == 0) {
        tableRow = parseInt((event.layerY - 41) / 23) + 1;
      } else {
        tableRow = parseInt((event.layerY - 41) / 23) + 1;
      }
      $("#heeaderTableText").text(tableRow + '*' + tableCol + '表格');
      //console.log(tableCol +' '+tableRow);
    }
  },
  //表格弹出框的每个表格鼠标点击事件
  tablePopUponTdClick: function tablePopUponTdClick() {
    if (mouseover) {
      mouseover = false;
    } else {
      mouseover = true;
    }
    showorOrHideTablePopUp();
    if (tableCol != 0 && tableRow != 0) {
      var elementBo = new _TableEleBo2.default();
      elementBo.type = "table";
      elementBo.id = uuid();
      elementBo.width = 400;
      elementBo.height = parseInt(tableRow) * 38.5;
      elementBo.tableRow = tableRow;
      elementBo.tableCol = tableCol;
      elementBo.x = parseInt(_LayoutStore2.default.getState().editAreaWidth) / 2 - parseInt(elementBo.width) / 2;
      elementBo.y = parseInt(_LayoutStore2.default.getState().editAreaHeight) / 2 - parseInt(elementBo.height) / 2;
      _EditAreaStore2.default.addCanvas(elementBo);
    }
  },
  //鼠标在选择表格行列范围内移出事件
  tablePopUpMouseOut: function tablePopUpMouseOut(e) {
    if (e.layerY <= 40 || e.layerY > 239 || e.layerX < 0 || e.layerX > 240) {
      console.log(111);
      var span = $("#tablePopUpSpan").find("span");
      span.removeClass('on');
      tableCol = 0;
      tableRow = 0;
      $("#heeaderTableText").text(tableRow + '*' + tableCol + '表格');
    }
  },
  //点击页面空白地方隐藏弹出框
  hiddenAllPopUp: function hiddenAllPopUp() {
    if (!$('#shapePopUpDiv').hasClass('hidden') && clickFlag) {
      $('#shapePopUpDiv').addClass('hidden');
    }
    if (!$('#tablePopUp').hasClass('hidden') && clickFlag) {
      $('#tablePopUp').addClass('hidden');
    }
    $('#navEleRmenu').css('visibility', 'hidden');
    $('#menu').css('visibility', 'hidden');
    clickFlag = true;
  },
  //在图形弹出框内点击时修改clickFlag为true
  changeClickFlag: function changeClickFlag() {
    clickFlag = false;
  }
};
exports.default = HeaderPageService;

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _CpUtil = __webpack_require__(4);

var _CpUtil2 = _interopRequireDefault(_CpUtil);

var _NavPageStore = __webpack_require__(15);

var _NavPageStore2 = _interopRequireDefault(_NavPageStore);

var _NavPageBo = __webpack_require__(14);

var _NavPageBo2 = _interopRequireDefault(_NavPageBo);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var uuid = _CpUtil2.default.uuid;

//公共变量区-----------------start

var currSelNavId_ByRilghtClick = null; //右击选择元素的id
//移动导航元素使用
var nvaPageEleMove = false;
var nvaPageEleMoveStart = false;
var startNavPageEle = null;

var currOperNavId; // 当前操作的面板id..........重要!

var copyNavPageData = null;
//在导航上右击时的对应的y轴坐标
var rightClickY;
//右击是在导航栏的非nav区域
var leftDivClick = false;
//右击是在导航栏navPage区域
var navClick = false;
//是否是粘贴的标志
var isCopy = false;
//公共变量区-----------------end

//内部函数区域-------------------------start

// 获取所有导航元素，范放在这儿是防止查询条件变化
function getAllNavPageEle() {
  return $('#leftMainDiv').children();
}

function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}

function hideAllRMenu() {
  try {
    $('#menu').css('visibility', 'hidden');
    $('#navEleRmenu').css('visibility', 'hidden');
  } catch (e) {
    console.error(e);
  }
}

//获取当前处于选中态的元素
function getSelNavPage() {}

function showRMenu_NavPageBody(event) {

  event.stopPropagation();
  var menu = document.getElementById('navEleRmenu');
  try {
    var divHeight = $("#navEleRmenu").outerHeight();
    var rightedge = event.clientX;
    var bottomedge = event.clientY;
    var windowHeight = $(window).height();
    //当点击位置加弹出框高度大于页面窗口高度，弹出框在鼠标上方显示
    if (bottomedge + divHeight > windowHeight) {
      bottomedge = bottomedge - divHeight;
      menu.style.top = bottomedge + "px";
    } else {
      menu.style.top = bottomedge + "px";
    }
    menu.style.left = rightedge + "px";

    $('#navEleRmenu').css('visibility', 'visible');
  } catch (e) {
    console.error(e);
  }
}

function setCuurSel(eleId) {
  currOperNavId = eleId;
  try {
    //数据驱动方式改变
    var navePageList = _NavPageStore2.default.getNavePageList();
    for (var i in navePageList) {
      var tempNavPageData = navePageList[i];
      var tempId = tempNavPageData.id;
      if (eleId == tempId) {
        tempNavPageData.className = 'navPageSelected';
      } else {
        tempNavPageData.className = 'navPage';
      }
      _NavPageStore2.default.updataNavePage(tempId, tempNavPageData);
    }
  } catch (e) {
    console.error("setCuurSel异常:" + e);
  }
}

//设置所有的都是未选中
function setNoSel() {
  var navePageList = _NavPageStore2.default.getNavePageList();

  for (var i in navePageList) {
    var tempNavPageData = navePageList[i];
    var tempId = tempNavPageData.id;
    tempNavPageData.className = 'navPage';

    _NavPageStore2.default.updataNavePage(tempId, tempNavPageData);
  }
}

//删除状态时候重新计算seq
function setNavPageEleSeqByDel(currSeq) {
  /* getAllNavPageEle().each(function() {
    var tempSeq = $(this).attr("seq");
    
    if(tempSeq>currSeq){
      $(this).attr("seq",tempSeq-1);
      $(this).children(".navPageLeft").html(tempSeq-1);
    }
  });*/
  try {
    //数据驱动方式改变现实seq
    var navePageList = _NavPageStore2.default.getNavePageList();
    for (var i in navePageList) {
      var tempNavPageData = navePageList[i];
      var tempSeq = tempNavPageData.seq;
      var id = tempNavPageData.id;

      if (tempSeq > currSeq) {
        tempNavPageData.seq = tempSeq - 1;
        _NavPageStore2.default.updataNavePage(id, tempNavPageData);
      }
    }
  } catch (e) {
    console.error("setNavPageEleSeqByDel异常:" + e);
  }
}
//重新设置所有数据的seq
function changeAllseq(navePageList) {
  try {
    for (var i = 0; i < navePageList.length; i++) {
      var temp = navePageList[i];
      temp.seq = parseInt(i) + 1;
      navePageList[i] = temp;
    }
  } catch (e) {
    console.error("setNavPageEleSeqByDel异常:" + e);
  }
}

// 根据实际的物理顺序重新编码顺序号
function refreshNavPageEleSeqByWL() {

  _NavPageStore2.default.updataSeqByPoint();

  /*var seq = 1;
  getAllNavPageEle().each(function() {
    $(this).attr("seq", seq);
    $(this).children(".navPageLeft").html(seq);
  
  });*/
}

function setNavPageEleMoveFalse() {
  nvaPageEleMove = false;
  nvaPageEleMoveStart = false;
  startNavPageEle = null;
  $('#leftMainDiv').css("cursor", "");
}

//内部函数区域-------------------------end

/**
 * 导航面板业务类
 * @auto 庄召
 */
var NavPageService = {

  //初始执行函数
  init: function init() {

    try {
      NavPageService.addNavePage();
      //$('#leftMainDiv').bind('contextmenu',this.showLeftRMenu);
      $('#leftMainDiv').get(0).oncontextmenu = function () {
        var evt = window.event || arguments[0];
        evt.stopPropagation();
        evt.preventDefault();
      };

      $('#leftDiv').get(0).oncontextmenu = NavPageService.showLeftRMenu;
    } catch (e) {
      console.error(e);
    }
  },
  initPageChildEle: function initPageChildEle() {},
  addNavePage: function addNavePage() {

    try {
      var navPageBo = new _NavPageBo2.default();
      navPageBo.id = uuid();
      navPageBo.seq = 1;
      navPageBo.className = 'navPageSelected';
      navPageBo.url = 'images/eg.jpg';
      _NavPageStore2.default.addNavePage(navPageBo);
      setCuurSel(navPageBo.id);
    } catch (e) {
      console.error(e);
    }
  },
  addNavePageByNewMenu: function addNavePageByNewMenu() {
    setNoSel();
    NavPageService.hideLeftRMenu();
    var navPageList = _NavPageStore2.default.getNavePageList();
    var tempseq;
    var newNavPageEleId = uuid();
    var navPageBo = new _NavPageBo2.default();
    navPageBo.id = uuid();
    navPageBo.className = 'navPageSelected';
    navPageBo.url = 'images/eg.jpg';
    if (leftDivClick) {
      tempseq = _NavPageStore2.default.getNavePageListSize() + 1;
    } else {
      var currData = _NavPageStore2.default.getNavePageData(currOperNavId);
      tempseq = currData.seq;
    }
    navPageBo.seq = tempseq;
    navPageList.splice(tempseq, 0, navPageBo);
    changeAllseq(navPageList);
    _NavPageStore2.default.refreshData(navPageList);
  },

  //显示左边右键菜单
  showLeftRMenu: function showLeftRMenu() {
    //setAllNavPageEleNoSel();
    NavPageService.hideNavEleRmenu();
    var evt = window.event || arguments[0];
    evt.stopPropagation();
    rightClickY = evt.y;
    var menu = document.getElementById('menu');
    try {

      var evt = window.event || arguments[0];
      evt.stopPropagation();
      var divHeight = $("#navEleRmenu").outerHeight();
      var rightedge = evt.clientX;
      var bottomedge = evt.clientY;
      var windowHeight = $(window).height();
      menu.style.left = rightedge + "px";
      //当点击位置加弹出框高度大于页面窗口高度，弹出框在鼠标上方显示
      if (bottomedge + divHeight > windowHeight) {
        bottomedge = bottomedge - divHeight;
        menu.style.top = bottomedge + "px";
      } else {
        menu.style.top = bottomedge + "px";
      }
      leftDivClick = true;
      navClick = false;
      $('#menu').css('visibility', 'visible');
    } catch (e) {
      console.error(e);
    }

    return false;
  },
  hideLeftRMenu: function hideLeftRMenu() {
    $('#menu').css('visibility', 'hidden');
  },
  hideNavEleRmenu: function hideNavEleRmenu() {
    $('#navEleRmenu').css('visibility', 'hidden');
  },
  //导航元素点击事件
  navPageEleClick: function navPageEleClick(e) {
    hideAllRMenu();
    /*try {
      hideAllRMenu();
      e.stopPropagation();
      var currNavPageEle = e.srcElement ? e.srcElement : e.target;
      currNavPageEle = $(currNavPageEle).parent().parent();
      setCuurSel(currNavPageEle);
    } catch (e) {
      console.error("navPageEleClick异常:" + e);
    }*/
  },
  //在右边导航栏上点击
  navPageClick: function navPageClick(e) {
    hideAllRMenu();
  },
  //元素上右击
  navPageRClick: function navPageRClick(event) {
    hideAllRMenu();
    var currNavPageEle = getEvetTarget(event);
    currNavPageEle = $(currNavPageEle).parent().parent();

    currSelNavId_ByRilghtClick = currNavPageEle.attr('id');

    setCuurSel(currSelNavId_ByRilghtClick);
    leftDivClick = false;
    navClick = true;
    // currSelNavEleByRilghtClick = currNavPageEle; 


    showRMenu_NavPageBody(event);
    return false;
  },

  //点击删除菜单删除当前的导航元素
  delNavPageByRightClick: function delNavPageByRightClick() {

    hideAllRMenu();

    try {
      if (currSelNavId_ByRilghtClick != null) {

        var currNavPageData = _NavPageStore2.default.getNavePageData(currSelNavId_ByRilghtClick);
        var currSeq = currNavPageData.seq;

        //$(currSelNavEleByRilghtClick).remove();
        //通过数据驱动方式删除
        _NavPageStore2.default.deleteNavePage(currSelNavId_ByRilghtClick);

        //重新编码顺序号
        setNavPageEleSeqByDel(currSeq);
      }
    } catch (e) {
      console.error('delNavPageByRightClick异常:' + e);
    }
  },

  //导航元素移动事件
  navPageElemousedown: function navPageElemousedown(event) {
    try {
      hideAllRMenu();
      event.stopPropagation();
      event.preventDefault();
      var currNavPageEle = getEvetTarget(event);
      currNavPageEle = $(currNavPageEle).parent().parent();
      setCuurSel(currNavPageEle.attr('id'));
    } catch (e) {
      console.error("navPageEleClick异常:" + e);
    }

    nvaPageEleMove = true;

    var currNavPageEle = getEvetTarget(event);
    currNavPageEle = $(currNavPageEle).parent().parent();

    startNavPageEle = currNavPageEle;
  },

  navPageElemouseup: function navPageElemouseup() {

    var e = window.event || arguments[0];
    e.stopPropagation();

    var currNavPageEle = getEvetTarget(e);
    currNavPageEle = $(currNavPageEle).parent().parent();

    //满足移动条件
    if (startNavPageEle != null && nvaPageEleMoveStart) {
      // console.error(currNavPageEle.attr('id'));
      //判断移动的位置和当前是否是一个
      if (currNavPageEle.attr('id') != $(startNavPageEle).attr('id')) {
        var seq = currNavPageEle.attr('seq');
        var startSeq = $(startNavPageEle).attr('seq');
        var currId = currNavPageEle.attr('id');
        var startId = $(startNavPageEle).attr('id');

        if (seq > startSeq) {

          //$(startNavPageEle).insertAfter(currNavPageEle);
          //通过改变数据位置实现
          _NavPageStore2.default.changeDataPoint(startId, currId);
        }
        if (seq < startSeq) {
          // $(startNavPageEle).insertBefore(currNavPageEle);
          //通过改变数据位置实现
          _NavPageStore2.default.changeDataPoint(startId, currId);
        }
        refreshNavPageEleSeqByWL();
      }
      setNavPageEleMoveFalse();
    }
  },
  navPageElemousemove: function navPageElemousemove() {
    if (nvaPageEleMove == true && nvaPageEleMoveStart == false) {
      nvaPageEleMoveStart = true;
      return;
    }
    if (nvaPageEleMoveStart == true) {

      $('#leftMainDiv').css("cursor", "move");
    }
  },
  leftMainDivmouseUp: function leftMainDivmouseUp() {
    //满足移动条件
    if (startNavPageEle != null) {
      $('#leftMainDiv').append($(startNavPageEle));
      refreshNavPageEleSeqByWL();
    }

    setNavPageEleMoveFalse();
  },
  leftMainDivClk: function leftMainDivClk() {

    _NavPageStore2.default.addNavePage({});
    //this.hideMenu();
    //console.log(Const.objMethod )
    // Const.objMethod.onAddCanvas({type: 'txt'});

    //EditAreaStore.addCanvas({type: 'txt'});
    /* let d = new Canvasbo
    let c = new Canvasbo
    d.fill = 'red';
       console.log(d,c)
    EditAreaActions.addCanvas({type: 'txt'});*/
  },
  //设置当前操作的导航面板的内容
  setUrlCurrOperSel: function setUrlCurrOperSel(url) {
    var tempData = _NavPageStore2.default.getNavePageData(currOperNavId);
    if (tempData == null) {} else {}
    tempData.url = url;
    _NavPageStore2.default.updataNavePage(tempData.id, tempData);
  },
  //复制当前的节点
  copyCurrNavPage: function copyCurrNavPage() {
    var currData = _NavPageStore2.default.getNavePageData(currOperNavId);
    copyNavPageData = currData;
    isCopy = true;
    hideAllRMenu();
  },
  //剪切当前的节点
  cutCurrNavPage: function cutCurrNavPage() {
    var currData = _NavPageStore2.default.getNavePageData(currOperNavId);
    copyNavPageData = currData;
    isCopy = false;
    hideAllRMenu();
  },
  //粘贴导航节点
  pasteNavPage: function pasteNavPage(e) {
    hideAllRMenu();
    //当需要粘贴的数据没有设置时直接返回
    if (copyNavPageData == null) {
      return false;
    }
    var navPageList = _NavPageStore2.default.getNavePageList();
    var navPageBo = new _NavPageBo2.default();
    navPageBo.id = uuid();
    //navPageBo.className = 'navPage';
    navPageBo.url = copyNavPageData.url;
    //将新添加的设置为选中
    navPageBo.className = 'navPageSelected';
    //判断是在导航栏内点击还是在某个导航块内点击
    if (leftDivClick) {
      //这部分时当在导航栏最顶端点击时做特殊处理
      if (rightClickY < 75) {
        navPageBo.seq = 0;
        //当为剪切时先删除选择元素在插入元素
        if (!isCopy) {
          navPageList.splice(0, 1);
          currOperNavId = navPageBo.id;
        }
        setNoSel();
        //navPageBo.className = 'navPageSelected';
        navPageList.splice(0, 0, navPageBo);
        changeAllseq(navPageList);
        _NavPageStore2.default.refreshData(navPageList);
      } else {
        navPageBo.seq = navPageList.length + 1;
        if (!isCopy) {
          navPageList.splice(copyNavPageData.seq - 1, 1);
          currOperNavId = navPageBo.id;
        }
        setNoSel();
        //navPageBo.className = 'navPageSelected';
        navPageList.splice(navPageList.length, 0, navPageBo);
        changeAllseq(navPageList);
        _NavPageStore2.default.refreshData(navPageList);
      }
    } else {
      var currData = _NavPageStore2.default.getNavePageData(currOperNavId);
      var seq = currData.seq;
      if (!isCopy) {
        navPageList.splice(copyNavPageData.seq - 1, 1);
        currOperNavId = navPageBo.id;
        setNoSel();
        // navPageBo.className = 'navPageSelected';
        navPageList.splice(seq - 1, 0, navPageBo);
        changeAllseq(navPageList);
      } else {
        setNoSel();

        navPageList.splice(seq, 0, navPageBo);
        changeAllseq(navPageList);
      }
      _NavPageStore2.default.refreshData(navPageList);
    }
    //var num=parseInt((mouseHeight-60-15)/104);
    //console.log(num);
  }

};

exports.default = NavPageService;

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = __webpack_require__(23);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } } /**
                                                                                                                                                           * 存储根类
                                                                                                                                                           * author 马君保
                                                                                                                                                           */

var Store = function Store(eventType) {
  _classCallCheck(this, Store);

  this.addChangeListener = function (callback) {
    _events.EventEmitter.prototype.on(this.eventType, callback);
  };

  this.removeChangeListener = function (callback) {
    _events.EventEmitter.prototype.off(this.eventType, callback);
  };

  this.emit = function () {
    _events.EventEmitter.prototype.emit(this.eventType);
  };

  this.eventType = eventType || 'change';
};

exports.default = Store;

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * 公共常量类
 * @auto  庄召，马君保
 */
var CpConst = {

  txt_help_width: 7,
  //样式按钮对应的所有样式
  id_styleArr: [{ id: 'font_style_b', styleKey: 'fontWeight' }],
  maximum_angle: 360 };

exports.default = CpConst;

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _EditAreaStore = __webpack_require__(2);

var _EditAreaStore2 = _interopRequireDefault(_EditAreaStore);

var _CpUtil = __webpack_require__(4);

var _CpUtil2 = _interopRequireDefault(_CpUtil);

var _CpConst = __webpack_require__(9);

var _CpConst2 = _interopRequireDefault(_CpConst);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 修正了宽高
function xz_add(value) {
  return value + _CpConst2.default.txt_help_width * 2;
}

function xz_del(value) {
  return value - _CpConst2.default.txt_help_width * 2;
}
/**
 * 文本框业务类
 * @auto 庄召
 */
var TxtService = {

  //移动改变大小的时候。
  setTxtSizeByTransform: function setTxtSizeByTransform(tempData) {
    var id = tempData.id;
    var paretEle = $('#' + id);
    var currTxtAreaEle = paretEle.children(".txt_AreaText");
    //var len = currTxtAreaEle.width();

    var targetW = xz_del(tempData.width);
    var targetH = xz_del(tempData.height);
    paretEle.width(targetW);
    paretEle.height(targetH);

    var text = currTxtAreaEle.val();
    //console.log("当前值:"+text);
    var len = _CpUtil2.default.findvisualLength(text, currTxtAreaEle);
    if (len <= targetW) {
      var tempLen = len + 20;
      if (tempLen < 20) {
        tempLen = 20;
      }

      if (tempLen > targetW - _CpConst2.default.txt_help_width) {
        tempLen = targetW - _CpConst2.default.txt_help_width;
      }

      currTxtAreaEle.css('width', tempLen + 'px');
      tempData.tw = tempLen;
    } else {
      var tempLen = targetW - _CpConst2.default.txt_help_width;
      currTxtAreaEle.css('width', tempLen + 'px');
    }

    currTxtAreaEle.css('height', 'auto');
    currTxtAreaEle[0].scrollTop = 0;

    currTxtAreaEle.css('height', currTxtAreaEle[0].scrollHeight + 'px');
    tempData.th = currTxtAreaEle[0].scrollHeight;
    //tempData.height = xz_add(paretEle.height());
  },
  //设置文本框宽和高
  setTxtSize: function setTxtSize(currTxtAreaEle, paretEle) {

    try {
      var id = paretEle.attr('id');
      var tempData = _EditAreaStore2.default.getCanvasById(id);

      //小于父亲 
      var text = currTxtAreaEle.val();
      //console.log("当前值:"+text);
      var len = _CpUtil2.default.findvisualLength(text, currTxtAreaEle);
      // console.log("文本长度:"+len);
      var txtParntWidth = paretEle.css('width').replace('px', '');
      if (len <= txtParntWidth) {
        // console.log("改变大小:"+CpConst.txt_help_width);

        var tempLen = len + 20;
        if (tempLen < 20) {
          tempLen = 20;
        }

        if (tempLen > txtParntWidth - _CpConst2.default.txt_help_width) {
          tempLen = txtParntWidth - _CpConst2.default.txt_help_width;
        }

        currTxtAreaEle.css('width', tempLen + 'px');
        // console.log("目标宽度:"+tempLen);
        tempData.tw = tempLen;
        tempData.width = xz_add(paretEle.width());
      }

      currTxtAreaEle.css('height', 'auto');
      currTxtAreaEle[0].scrollTop = 0;

      currTxtAreaEle.css('height', currTxtAreaEle[0].scrollHeight + 'px');
      tempData.th = currTxtAreaEle[0].scrollHeight;

      // 文本输入区域笔外网区域小了.解决拖动改变大小后，父窗体不跟随子窗体大小变化问题，原因不清楚
      if (paretEle.height() < currTxtAreaEle.height()) {
        paretEle.height(currTxtAreaEle.height());
      }
      tempData.height = xz_add(paretEle.height());
      //console.log("tempData.height:"+tempData.height +">>"+currTxtAreaEle.height());

      _EditAreaStore2.default.updataCanvasById(id, tempData);
    } catch (e) {
      alert("setTxtSize异常:" + e);
    }
  },

  command: function command(commandName, commandValue, callback) {
    var editor = this;
    var hooks;

    function commandFn() {
      if (!commandName) {
        return;
      }
      if (editor.queryCommandSupported(commandName)) {
        // 默认命令
        document.execCommand(commandName, false, commandValue);
      } else {
        // hooks 命令
        /* hooks = editor.commandHooks;
         if (commandName in hooks) {
             hooks[commandName](commandValue);
         }*/
      }
    }
  }

};
exports.default = TxtService;

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _EditAreaStore = __webpack_require__(2);

var _EditAreaStore2 = _interopRequireDefault(_EditAreaStore);

var _ElementBo = __webpack_require__(12);

var _ElementBo2 = _interopRequireDefault(_ElementBo);

var _CpUtil = __webpack_require__(4);

var _CpUtil2 = _interopRequireDefault(_CpUtil);

var _LayoutStore = __webpack_require__(3);

var _LayoutStore2 = _interopRequireDefault(_LayoutStore);

var _TxtService = __webpack_require__(10);

var _TxtService2 = _interopRequireDefault(_TxtService);

var _NavPageService = __webpack_require__(7);

var _NavPageService2 = _interopRequireDefault(_NavPageService);

var _HeaderPageService = __webpack_require__(6);

var _HeaderPageService2 = _interopRequireDefault(_HeaderPageService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var uuid = _CpUtil2.default.uuid;
/**
 * 编辑区业务类
 * @auto 庄召
 */
var EditAreaPageService = {

  //初始执行函数
  init: function init() {

    /*try {
      
    } catch (e) {
      console.error(e);
    }*/

  },
  // 添加组件，文本、图形其它
  // 目前只做初次添加组件
  addEle: function addEle(vtype) {
    try {
      var elementBo = new _ElementBo2.default();
      elementBo.type = vtype;
      elementBo.id = uuid();
      elementBo.width = 150;
      elementBo.height = 150;

      // if(vtype.indexOf("ine")>0){
      //   elementBo.fill='#000000';
      //   elementBo.strokeWidth=1;
      //   elementBo.height = 4;
      // }
      // if(elementBo.type == 'testLine') {
      //   elementBo.strokeWidth = 2;
      //   elementBo.height = elementBo.strokeWidth + 2;
      // }

      switch (elementBo.type) {
        case 'txt':
          elementBo.width = 150, elementBo.height = 30;
          break;
        case 'cross':
        case 'right':
          elementBo.strokeWidth = 10;
          break;
        default:
          break;
      }

      elementBo.x = parseInt(_LayoutStore2.default.getState().editAreaWidth) / 2 - parseInt(elementBo.width) / 2;
      elementBo.y = parseInt(_LayoutStore2.default.getState().editAreaHeight) / 2 - parseInt(elementBo.height) / 2;

      _EditAreaStore2.default.addCanvas(elementBo);
      // HeaderPageService.changeCliakFlag();
    } catch (e) {
      console.error(e);
    }
  },
  /* // 添加组件，表格
   addTableEle: function(vtype) {
     try {
  
       var tableEleBo = new TableEleBo();
       tableEleBo.type = vtype;
       tableEleBo.id = uuid();
       tableEleBo.width = 150;
       tableEleBo.height = 150;
       tableEleBo.col=2;
       tableEleBo.row=3;
       tableEleBo.x = parseInt(LayoutStore.getState().editAreaWidth) / 2 - parseInt(tableEleBo.width) / 2;
       tableEleBo.y = parseInt(LayoutStore.getState().editAreaHeight) / 2 - parseInt(tableEleBo.height) / 2;
  
       EditAreaStore.addCanvas(tableEleBo);
     } catch (e) {
       console.error(e);
     }
   },*/
  // 表格td点击事件
  tableTdClick: function tableTdClick(event) {
    try {
      var ele = event.srcElement ? event.srcElement : event.target;
      var input = $(ele).find('input');
      if (input.is(':focus')) return;
      var span = $(ele).find('span');
      input.removeClass('hidden');
      input.val(span.text());
      input.focus();
      span.addClass('hidden');
    } catch (e) {
      console.error(e);
    }
  },
  //input框输入结束
  inputBlur: function inputBlur(event) {
    try {
      var ele = event.srcElement ? event.srcElement : event.target;
      var inputEle = $(ele);
      inputEle.addClass('hidden');
      var span = inputEle.parents('td').find('span');
      span.text(inputEle.val());
      span.removeClass('hidden');
    } catch (e) {
      console.error(e);
    }
  },
  //当设置文本框的样式的时候可能触发文本其它样式的变化，如大小的变化。调用这个方法重新计算
  setTxtStyleBychangePrp: function setTxtStyleBychangePrp(id) {

    var paretEle = $('#' + id);
    var currTxtAreaEle = paretEle.children(".txt_AreaText");
    // TxtService.command('bold');

    _TxtService2.default.setTxtSize(currTxtAreaEle, paretEle);
  },

  //测试方法用别删除
  demo: function demo() {

    try {
      html2canvas($('.edit-area-canvas')[0], {
        onrendered: function onrendered(canvas) {
          var url = canvas.toDataURL();
          _NavPageService2.default.setUrlCurrOperSel(url);
        }
      });
    } catch (e) {
      alert('生成导航面板信息异常:' + e);
    }
  }

};

exports.default = EditAreaPageService;

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 编辑区元素的数据对象
 */

var ElementBo = //表格列数
function ElementBo() {
  _classCallCheck(this, ElementBo);

  this.id = null;
  this.type = null;
  this.x = null;
  this.y = null;
  this.width = null;
  this.height = null;
  this.rotate = 0;
  this.tw = null;
  this.th = null;
  this.fill = '#50a0f9';
  this.isSelected = false;
  this.fontWeight = 'normal';
  this.strokeStyle = 'solid';
  this.strokeWidth = 0;
  this.stroke = '#50a0f9';
  this.tableRow = 0;
  this.tableCol = 0;
} // 旋转角度 0-359 顺时针 number
// 文本控件中，文本区域的宽度
// 文本控件中，文本区域的高度
// 填充
//默认是未选中
// 边框宽度 number
//表格行数
;

exports.default = ElementBo;

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * 状态变量类
 * @auto  庄召
 */
var CpRundata = {
  shapeOriginalData: [], // 图形操作前的数据状态，目前应用场景是移动和拖动
  txtDownByMove: false //控制shaape等按下的事件是否可以使用拖动功能，比如文本输入框在输入框按下时不能触发推动功能。
};

exports.default = CpRundata;

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
* 导航面板数据对象用来和后台、页面对象等交互
*/

var NavPageBo = function NavPageBo() {
  _classCallCheck(this, NavPageBo);

  this.id = '';
  this.seq = 0;
  this.className = '';
  this.url = null;
};

exports.default = NavPageBo;

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _CpUtil = __webpack_require__(4);

var _CpUtil2 = _interopRequireDefault(_CpUtil);

var _RootStore2 = __webpack_require__(8);

var _RootStore3 = _interopRequireDefault(_RootStore2);

var _LayoutStore = __webpack_require__(3);

var _LayoutStore2 = _interopRequireDefault(_LayoutStore);

var _NavPageBo = __webpack_require__(14);

var _NavPageBo2 = _interopRequireDefault(_NavPageBo);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var uuid = _CpUtil2.default.uuid;

var _navePageList = [];

// 确保传入参数是数字
var someToNumber = function someToNumber(obj) {
  obj.x && (obj.x = parseInt(obj.x));
  obj.y && (obj.y = parseInt(obj.y));
};

// 获取位置
var findPointById = function findPointById(id) {
  for (var i in _navePageList) {
    var tempData = _navePageList[i];
    if (tempData.id == id) {
      return i;
    }
  }
  return 0;
};

var findNavePageData = function findNavePageData(id) {

  for (var i in _navePageList) {
    var tempData = _navePageList[i];
    if (tempData.id == id) {
      return tempData;
    }
  }
  return null;
};

/**
 *导航元素数据确定类
 *auto 庄召
 */

var NavPageStore = function (_RootStore) {
  _inherits(NavPageStore, _RootStore);

  function NavPageStore() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, NavPageStore);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = NavPageStore.__proto__ || Object.getPrototypeOf(NavPageStore)).call.apply(_ref, [this].concat(args))), _this), _this.getState = function () {
      return _navePageList;
    }, _this.refresh = function () {
      this.emit();
    }, _this.addNavePage = function (newData) {
      // 生成组件对象
      // _navePageList[newData.id] = newData;
      _navePageList.push(newData);
      // 测试复制粘贴时用的区分数据
      /*var navPageBo = new NavPageBo();
       navPageBo.id = uuid();
       navPageBo.seq = 2,
       navPageBo.className = 'navPageSelected';
       navPageBo.url = 'images/icons.png';
       _navePageList.push(navPageBo);*/
      this.emit();
    }, _this.deleteNavePage = function (id) {
      /*if(id in _navePageList) {
        delete _navePageList[id];
      }*/

      for (var i in _navePageList) {
        var tempData = _navePageList[i];
        if (tempData.id == id) {
          _navePageList.splice(i, 1); //移除当前对象
        }
      }
      this.emit();
    }, _this.updataNavePage = function (id, updateData) {
      someToNumber(updateData);
      /*if (id in _navePageList) {
        Object.keys(updateData).forEach(function(key) {
          _navePageList[id][key] = updateData[key];
        });
        this.emit();
      }*/

      for (var i in _navePageList) {
        var tempData = _navePageList[i];
        if (tempData.id == id) {
          Object.keys(updateData).forEach(function (key) {
            tempData[key] = updateData[key];
          });

          this.emit();
        }
      }
    }, _this.updataSeqByPoint = function () {

      for (var i in _navePageList) {
        var tempData = _navePageList[i];
        tempData.seq = parseInt(i) + 1;
      }
      this.emit();
    }, _this.changeDataPoint = function (currId, targetId) {
      try {
        var currPoint = findPointById(currId);
        var targetPoint = findPointById(targetId);
        var moveData = findNavePageData(currId);
        _navePageList.splice(currPoint, 1);
        _navePageList.splice(targetPoint, 0, moveData);
        this.emit();
      } catch (e) {
        alert(e);
      }
    }, _this.getNavePageList = function () {
      return _navePageList;
    }, _this.getNavePageListSize = function () {
      var objLen = 0;
      for (var i in _navePageList) {
        objLen++;
      }
      return objLen;
    }, _this.setNavePageList = function (navePageList) {
      _navePageList = navePageList;
    }, _this.getNavePageData = function (id) {
      //return _navePageList[id];
      return findNavePageData(id);
    }, _this.refreshData = function (navePageList) {
      _navePageList = navePageList;
      this.emit();
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }
  //添加一个导航面板

  //根据id删除一个面板


  //根据id更新一个面板

  //改变元素位置，当移动的时候


  //根据id获取一个元素数据

  //重新加载导航数据


  return NavPageStore;
}(_RootStore3.default);

exports.default = new NavPageStore();

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

function Event(props) {
  return (0, _preact.cloneElement)(props.children[0], props);
}

exports.default = Event;

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _EditAreaStore = __webpack_require__(2);

var _EditAreaStore2 = _interopRequireDefault(_EditAreaStore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * 表格业务类
 * @auto 邬宗俊
 */
//当秦表格的总行数
var tableCountRow;
//当前表格的总列数
var tableCountCol;
//表格数据存储对象
var tableEleBo;
var pianyi_val = 14;
var mincell_val = 10; // 单元格的最小宽度,拖动改变单元格大小用
// 移动的方向
var moveType; //移动方向
var isSizePre = false;
var isCellMoveSize = false; // 正在进行改变单元格大小的动作
var choseTd;
var currStartTd; // 开始点击的单元格
var moveRangeS; // 移动范围
var moveRangeE; // 移动范围结束
var moveStartx = null; // 记录开始位置
var moveStartY = null; //记录拖动的开始Y轴位置
//所有的td對象
var allTd;
var isTxtDown = false; //按下txt
var isTxtlMove = false; // 正在进行单元格移动
var startTxtMoveTd_ID;
var currMoveTxt_ID; //当前移上的单元格id
//选中的起始行
var startRow;
//选中的起始列
var startCol;
//选中的结束行
var endRow;
//选中的结束列
var endCol;
var chosedTdArr = [];
function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}
//改变td及td下的textarea的背景色
function changeColorForChose(ele) {
  ele.attr("bgcolor", "blue");
  ele.find("textarea").attr("style", "background-color:blue");
}
//根据td的ID获取行和列
function getTdIdRowAndCol(id) {
  //console.log(id);
  var obj = new Object();
  obj.row = parseInt(id.split("_")[0]);
  obj.col = parseInt(id.split("_")[1]);
  return obj;
}
//获取rowspan的值
function getRowSpan(tdId) {
  if (typeof tdId.attr("rowspan") != "undefined") {
    return parseInt(tdId.attr("rowspan"));
  }
  return null;
}
//获取colspan的值
function getColSpan(tdId) {
  if (typeof tdId.attr("colspan") != "undefined") {
    return parseInt(tdId.attr("colspan"));
  }
  return null;
}
//显示表格拖拽的辅助样式
function showHelp() {}
/*var moveHelpDiv = $('#moveHelpDiv');
moveHelpDiv.show();
var mhEle = $('#moveHelp');
mhEle.show();*/

//隐藏表格拖拽的辅助样式
function hideHelp() {}
/*var moveHelpDiv = $('#moveHelpDiv');
moveHelpDiv.hide();
var mhEle = $('#moveHelp');
mhEle.hide();*/


// 按下时候触发的操作，移动也会调用下
function tdMouseDownBody(e) {
  if (isSizePre == true) {
    var target = $(getEvetTarget(e));
    //console.log();
    var offset = $(target).offset();
    var relativeX = e.pageX - offset.left;
    var relativeY = e.pageY - offset.top;
    var tableEle = target.parent().parent();
    var tableX = parseInt(tableEle.offset().left);
    var tableY = parseInt(tableEle.offset().top);
    var tableEleWidth = parseInt(tableEle.width());
    var tableHeight = parseInt(tableEle.height());
    /*if(Math.abs(e.pageX-tableX)<6||Math.abs(e.pageX-(tableX+tableEleWidth))<8){
      $('body').css("cursor", "default");
      return;
    }
    if(Math.abs(e.pageY-tableY)<6||Math.abs(e.pageY-(tableY+tableHeight))<6){
      $('body').css("cursor", "default");
      return;
    }*/
    //return;
    var w = $(target).width() + pianyi_val;
    var h = $(target).height();
    var prew = $(target).prev().width() + pianyi_val;
    var nextw = $(target).next().width() + pianyi_val;
    // 左边
    if (relativeX < 4) {
      moveRangeS = e.pageX - prew + relativeX + mincell_val;
      moveRangeE = e.pageX + w - relativeX - mincell_val;
      moveType = 'l';
      target.css("cursor", "w-resize");
    } else if (w - relativeX < 11) {
      // 右边
      moveRangeS = e.pageX - w + (w - relativeX) + mincell_val;
      moveRangeE = e.pageX + nextw + (w - relativeX) - mincell_val;

      moveType = 'r';
      target.css("cursor", "w-resize");
    } else {
      //alert(11);
      if (relativeY < h / 2) {
        moveType = 't';
      } else {
        moveType = 'b';
      }
      target.css("cursor", "s-resize");
    }
  }
}
//设置table鼠标移动到的td的背景色（鼠标往右下方移动）
function tableMoveLowerRight(startTxtMoveTd_ID, endTxtMoveTd_ID) {
  //console.log("往右下移动");
  //debugger;
  chosedTdArr = [];
  var startTd = $("#" + startTxtMoveTd_ID);
  var endTd = $("#" + endTxtMoveTd_ID);
  var startRowAndCol = getTdIdRowAndCol(startTxtMoveTd_ID);
  var endRowAndCol = getTdIdRowAndCol(endTxtMoveTd_ID);
  startRow = startRowAndCol.row;
  startCol = startRowAndCol.col;
  endRow = endRowAndCol.row;
  endCol = endRowAndCol.col;
  var endRowspan = getRowSpan(endTd);
  var endColspan = getColSpan(endTd);
  if (endRowspan != null) {
    endRow = endRow + endRowspan - 1;
  }
  if (endColspan != null) {
    endCol = endCol + endColspan - 1;
  }
  for (var i = 0; i < allTd.length; i++) {
    var tdId = $(allTd[i]).attr('id');
    var tdRowAndCol = getTdIdRowAndCol(tdId);
    var tdRow = tdRowAndCol.row;
    var tdCol = tdRowAndCol.col;
    var rowspan = 0;
    var colspan = 0;
    var flag = false;
    var curTdRowspan = getRowSpan($(allTd[i]));
    var curTdColspan = getColSpan($(allTd[i]));
    if (curTdRowspan != null) {
      rowspan = curTdRowspan;
    }
    if (curTdColspan != null) {
      colspan = curTdColspan;
    }
    //判断当前td的的行和列数是否在当前选中的表格范围内（如果当前td是合并过的，判断此td拆分后的四个点的td的行和列是否在范围内）
    if (tdRow >= startRow && tdRow <= endRow && tdCol >= startCol && tdCol <= endCol) {
      flag = true;
    } else if (rowspan != 0 && tdRow + rowspan - 1 >= startRow && tdRow + rowspan - 1 <= endRow && tdCol >= startCol && tdCol <= endCol) {
      flag = true;
    } else if (colspan != 0 && tdRow >= startRow && tdRow <= endRow && tdCol + colspan - 1 >= startCol && tdCol + colspan - 1 <= endCol) {
      flag = true;
    } else if (rowspan != 0 && colspan != 0 && tdRow + rowspan - 1 >= startRow && tdRow + rowspan - 1 <= endRow && tdCol + colspan - 1 >= startCol && tdCol + colspan - 1 <= endCol) {
      flag = true;
    }
    //console.log(flag);
    //如果td在范围内，判断开始、结束行，开始、结束列是否需要改变
    if (flag) {
      //td的行数小于选中范围的开始行，重新赋值选中的开始行
      if (tdRow < startRow) {
        startRow = tdRow;
      }
      //td的列数小于选中范围的开始列，重新赋值选中的开始列
      if (tdCol < startCol) {
        startCol = tdCol;
      }
      //td的行数加上合并行数大于选中范围的结束行，重新赋值选中的结束行
      if (tdRow + rowspan - 1 > endRow) {
        endRow = tdRow + rowspan - 1;
      }
      //td的列数加上合并行数大于选中范围的结束列，重新赋值选中的结束列
      if (tdCol + colspan - 1 > endCol) {
        endCol = tdCol + colspan - 1;
      }
    }
  }
  for (var i = 0; i < allTd.length; i++) {
    var tdId = $(allTd[i]).attr('id');
    var tdRowAndCol = getTdIdRowAndCol(tdId);
    var tdRow = tdRowAndCol.row;
    var tdCol = tdRowAndCol.col;
    //判断当前td所属的行和列数，在选中的行列数内，改变td和textarea的背景色
    if (tdRow >= startRow && tdRow <= endRow && tdCol >= startCol && tdCol <= endCol) {
      changeColorForChose($(allTd[i]));
      //$(allTd[i]).attr("bgcolor","blue");
      //$($(allTd[i]).find("textarea")).attr("style","background-color:blue");
      chosedTdArr.push($(allTd[i]));
    }
  }
}
//设置table鼠标移动到的td的背景色（鼠标往右上方移动）
function tableMoveUpperRight(startTxtMoveTd_ID, endTxtMoveTd_ID) {
  //console.log("往右上移动");
  chosedTdArr = [];
  var startTd = $("#" + startTxtMoveTd_ID);
  var endTd = $("#" + endTxtMoveTd_ID);
  var startRowAndCol = getTdIdRowAndCol(startTxtMoveTd_ID);
  var endRowAndCol = getTdIdRowAndCol(endTxtMoveTd_ID);
  startRow = startRowAndCol.row;
  startCol = startRowAndCol.col;
  endRow = endRowAndCol.row;
  endCol = endRowAndCol.col;
  var startRowspan = getRowSpan(startTd);
  var endColspan = getColSpan(endTd);
  if (endColspan != null) {
    endCol = endCol + endColspan - 1;
  }
  if (startRowspan != null) {
    startRow = startRow + startRowspan - 1;
  }
  /*if(typeof(endTd.attr("colspan"))!="undefined"){
    var colspan=endTd.attr("colspan");
    endCol=endCol+parseInt(colspan)-1;
  }
  if(typeof(startTd.attr("rowspan"))!="undefined"){
    var rowspan=endTd.attr("rowspan");
    startRow=startRow+parseInt(rowspan)-1;
  }*/
  for (var i = 0; i < allTd.length; i++) {
    var tdId = $(allTd[i]).attr('id');
    var tdRowAndCol = getTdIdRowAndCol(tdId);
    var tdRow = tdRowAndCol.row;
    var tdCol = tdRowAndCol.col;
    var rowspan = 0;
    var colspan = 0;
    var flag = false;
    var curTdRowspan = getRowSpan($(allTd[i]));
    var curTdColspan = getColSpan($(allTd[i]));
    if (curTdRowspan != null) {
      rowspan = curTdRowspan;
    }
    if (curTdColspan != null) {
      colspan = curTdColspan;
    }
    /*if(typeof($(allTd[i]).attr("rowspan"))!="undefined"){
      rowspan=parseInt($(allTd[i]).attr("rowspan"));
    }
    if(typeof($(allTd[i]).attr("colspan"))!="undefined"){
      colspan=parseInt($(allTd[i]).attr("colspan"));
    }*/
    //判断当前td的的行和列数是否在当前选中的表格范围内（如果当前td是合并过的，判断此td拆分后的四个点的td的行和列是否在范围内）
    if (tdRow >= endRow && tdRow <= startRow && tdCol >= startCol && tdCol <= endCol) {
      flag = true;
    } else if (rowspan != 0 && tdRow + rowspan - 1 >= endRow && tdRow + rowspan - 1 <= startRow && tdCol >= startCol && tdCol <= endCol) {
      flag = true;
    } else if (colspan != 0 && tdRow >= endRow && tdRow <= startRow && tdCol + colspan - 1 >= startCol && tdCol + colspan - 1 <= endCol) {
      flag = true;
    } else if (rowspan != 0 && colspan != 0 && tdRow + rowspan - 1 >= endRow && tdRow + rowspan - 1 <= startRow && tdCol + colspan - 1 >= startCol && tdCol + colspan - 1 <= endCol) {
      flag = true;
    }
    //如果td在范围内，判断开始、结束行，开始、结束列是否需要改变
    if (flag) {
      //td的行数小于选中范围的结束行，重新赋值选中的结束行
      if (tdRow < endRow) {
        endRow = tdRow;
      }
      //td的列数小于选中范围的开始列，重新赋值选中的开始列
      if (tdCol < startCol) {
        startCol = tdCol;
      }
      //td的行数加上合并行数大于选中范围的开始行，重新赋值选中的开始行
      if (tdRow + rowspan - 1 > startRow) {
        startRow = tdRow + rowspan - 1;
      }
      //td的列数加上合并行数大于选中范围的结束列，重新赋值选中的结束列
      if (tdCol + colspan - 1 > endCol) {
        endCol = tdCol + colspan - 1;
      }
    }
  }
  for (var i = 0; i < allTd.length; i++) {
    var tdId = $(allTd[i]).attr('id');
    var tdRowAndCol = getTdIdRowAndCol(tdId);
    var tdRow = tdRowAndCol.row;
    var tdCol = tdRowAndCol.col;
    //判断当前td所属的行和列数，在选中的行列数内，改变td和textarea的背景色
    if (tdRow >= endRow && tdRow <= startRow && tdCol >= startCol && tdCol <= endCol) {
      changeColorForChose($(allTd[i]));
      //$(allTd[i]).attr("bgcolor","blue");
      //$($(allTd[i]).find("textarea")).attr("style","background-color:blue");
      chosedTdArr.push($(allTd[i]));
    }
  }
}
//设置table鼠标移动到的td的背景色（鼠标往左下方移动）
function tableMoveUpperLeft(startTxtMoveTd_ID, endTxtMoveTd_ID) {
  //console.log("往左上移动");
  chosedTdArr = [];
  var startTd = $("#" + startTxtMoveTd_ID);
  var endTd = $("#" + endTxtMoveTd_ID);
  var startRowAndCol = getTdIdRowAndCol(startTxtMoveTd_ID);
  var endRowAndCol = getTdIdRowAndCol(endTxtMoveTd_ID);
  startRow = startRowAndCol.row;
  startCol = startRowAndCol.col;
  endRow = endRowAndCol.row;
  endCol = endRowAndCol.col;
  var startRowspan = getRowSpan(startTd);
  var startColspan = getColSpan(startTd);
  if (startRowspan != null) {
    startRow = startRow + startRowspan - 1;
    //endCol=endCol+endColspan-1;
  }
  if (startColspan != null) {
    startCol = startCol + startColspan - 1;
    //startRow=startRow+startRowspan-1;
  }
  /*
  if(typeof(startTd.attr("rowspan"))!="undefined"){
    var rowspan=endTd.attr("rowspan");
    startRow=parseInt(startRow)+parseInt(rowspan)-1;
  }
  if(typeof(startTd.attr("colspan"))!="undefined"){
    var colspan=endTd.attr("colspan");
    startCol=parseInt(startCol)+parseInt(colspan)-1;
  }*/
  for (var i = 0; i < allTd.length; i++) {
    var tdId = $(allTd[i]).attr('id');
    var tdRowAndCol = getTdIdRowAndCol(tdId);
    var tdRow = tdRowAndCol.row;
    var tdCol = tdRowAndCol.col;
    var rowspan = 0;
    var colspan = 0;
    var flag = false;
    var curTdRowspan = getRowSpan($(allTd[i]));
    var curTdColspan = getColSpan($(allTd[i]));
    if (curTdRowspan != null) {
      rowspan = curTdRowspan;
    }
    if (curTdColspan != null) {
      colspan = curTdColspan;
    } /*
      if(typeof($(allTd[i]).attr("rowspan"))!="undefined"){
       rowspan=parseInt($(allTd[i]).attr("rowspan"));
      }
      if(typeof($(allTd[i]).attr("colspan"))!="undefined"){
       colspan=parseInt($(allTd[i]).attr("colspan"));
      }*/
    //判断当前td的的行和列数是否在当前选中的表格范围内（如果当前td是合并过的，判断此td拆分后的四个点的td的行和列是否在范围内）
    if (tdRow >= endRow && tdRow <= startRow && tdCol >= endCol && tdCol <= startCol) {
      flag = true;
    } else if (rowspan != 0 && tdRow + rowspan - 1 >= endRow && tdRow + rowspan - 1 <= startRow && tdCol >= endCol && tdCol <= startCol) {
      flag = true;
    } else if (colspan != 0 && tdRow >= endRow && tdRow <= startRow && tdCol + colspan - 1 >= endCol && tdCol + colspan - 1 <= startCol) {
      flag = true;
    } else if (rowspan != 0 && colspan != 0 && tdRow + rowspan - 1 >= endRow && tdRow + rowspan - 1 <= startRow && tdCol + colspan - 1 >= endCol && tdCol + colspan - 1 <= startCol) {
      flag = true;
    }
    //如果td在范围内，判断开始、结束行，开始、结束列是否需要改变
    if (flag) {
      //td的行数小于选中范围的结束行，重新赋值选中的结束行
      if (tdRow < endRow) {
        endRow = tdRow;
      }
      //td的列数小于选中范围的结束列，重新赋值选中的结束列
      if (tdCol < endCol) {
        endCol = tdCol;
      }
      //td的行数加上合并行数大于选中范围的开始行，重新赋值选中的开始行
      if (tdRow + rowspan - 1 > startRow) {
        startRow = tdRow + rowspan - 1;
      }
      //td的列数加上合并行数大于选中范围的开始列，重新赋值选中的开始列
      if (tdCol + colspan - 1 > startCol) {
        startCol = tdCol + colspan - 1;
      }
    }
  }
  for (var i = 0; i < allTd.length; i++) {
    var tdId = $(allTd[i]).attr('id');
    var tdRowAndCol = getTdIdRowAndCol(tdId);
    var tdRow = tdRowAndCol.row;
    var tdCol = tdRowAndCol.col;
    //判断当前td所属的行和列数，在选中的行列数内，改变td和textarea的背景色
    if (tdRow >= endRow && tdRow <= startRow && tdCol >= endCol && tdCol <= startCol) {
      changeColorForChose($(allTd[i]));
      //$(allTd[i]).attr("bgcolor","blue");
      //$($(allTd[i]).find("textarea")).attr("style","background-color:blue");
      chosedTdArr.push($(allTd[i]));
    }
  }
}
//设置table鼠标移动到的td的背景色（鼠标往左下方移动）
function tableMoveLowerLeft(startTxtMoveTd_ID, endTxtMoveTd_ID) {
  //console.log("往左下移动");
  chosedTdArr = [];
  var startTd = $("#" + startTxtMoveTd_ID);
  var endTd = $("#" + endTxtMoveTd_ID);
  var startRowAndCol = getTdIdRowAndCol(startTxtMoveTd_ID);
  var endRowAndCol = getTdIdRowAndCol(endTxtMoveTd_ID);
  startRow = startRowAndCol.row;
  startCol = startRowAndCol.col;
  endRow = endRowAndCol.row;
  endCol = endRowAndCol.col;
  var startColspan = getColSpan(startTd);
  var endRowspan = getRowSpan(endTd);
  if (startColspan != null) {
    startCol = startCol + startColspan - 1;
  }
  if (endRowspan != null) {
    endRow = endRow + endRowspan - 1;
  }
  /*if(typeof(startTd.attr("colspan"))!="undefined"){
    var colspan=startTd.attr("colspan");
    startCol=parseInt(startCol)+parseInt(colspan)-1;
  }
  if(typeof(endTd.attr("rowspan"))!="undefined"){
    var rowspan=endTd.attr("rowspan");
    endRow=parseInt(endRow)+parseInt(rowspan)-1;
  }*/
  for (var i = 0; i < allTd.length; i++) {
    var tdId = $(allTd[i]).attr('id');
    var tdRowAndCol = getTdIdRowAndCol(tdId);
    var tdRow = tdRowAndCol.row;
    var tdCol = tdRowAndCol.col;
    var rowspan = 0;
    var colspan = 0;
    var flag = false;
    var curTdRowspan = getRowSpan($(allTd[i]));
    var curTdColspan = getColSpan($(allTd[i]));
    if (curTdRowspan != null) {
      rowspan = curTdRowspan;
    }
    if (curTdColspan != null) {
      colspan = curTdColspan;
    } /*
      if(typeof($(allTd[i]).attr("rowspan"))!="undefined"){
       rowspan=parseInt($(allTd[i]).attr("rowspan"));
      }
      if(typeof($(allTd[i]).attr("colspan"))!="undefined"){
       colspan=parseInt($(allTd[i]).attr("colspan"));
      }*/
    //判断当前td的的行和列数是否在当前选中的表格范围内（如果当前td是合并过的，判断此td拆分后的四个点的td的行和列是否在范围内）
    if (tdRow >= startRow && tdRow <= endRow && tdCol >= endCol && tdCol <= startCol) {
      flag = true;
    } else if (rowspan != 0 && tdRow + rowspan - 1 >= startRow && tdRow + rowspan - 1 <= endRow && tdCol >= endCol && tdCol <= startCol) {
      flag = true;
    } else if (colspan != 0 && tdRow >= endRow && tdRow <= startRow && tdCol + colspan - 1 >= endCol && tdCol + colspan - 1 <= startCol) {
      flag = true;
    } else if (rowspan != 0 && colspan != 0 && tdRow + rowspan - 1 >= startRow && tdRow + rowspan - 1 <= endRow && tdCol + colspan - 1 >= endCol && tdCol + colspan - 1 <= startCol) {
      flag = true;
    }
    //如果td在范围内，判断开始、结束行，开始、结束列是否需要改变
    if (flag) {
      //td的行数小于选中范围的开始行，重新赋值选中的开始行
      if (tdRow < startRow) {
        startRow = tdRow;
      }
      //td的列数小于选中范围的结束列，重新赋值选中的结束列
      if (tdCol < endCol) {
        endCol = tdCol;
      }
      //td的行数加上合并行数大于选中范围的结束行，重新赋值选中的结束行
      if (tdRow + rowspan - 1 > endRow) {
        endRow = tdRow + rowspan - 1;
      }
      //td的列数加上合并列数大于选中范围的开始列，重新赋值选中的开始列
      if (tdCol + colspan - 1 > startCol) {
        startCol = tdCol + colspan - 1;
      }
    }
  }
  for (var i = 0; i < allTd.length; i++) {
    var tdId = $(allTd[i]).attr('id');
    var tdRowAndCol = getTdIdRowAndCol(tdId);
    var tdRow = tdRowAndCol.row;
    var tdCol = tdRowAndCol.col;
    //判断当前td所属的行和列数，在选中的行列数内，改变td和textarea的背景色
    if (tdRow >= startRow && tdRow <= endRow && tdCol >= endCol && tdCol <= startCol) {
      changeColorForChose($(allTd[i]));
      //$(allTd[i]).attr("bgcolor","blue");
      //$($(allTd[i]).find("textarea")).attr("style","background-color:blue");
      chosedTdArr.push($(allTd[i]));
    }
  }
}
//拆分单元格是只有行合并的时候
function revertTdOnlyRow(table, startRow, startCol, rowspan) {
  var tr = table.find("tr");
  //只有行合并
  for (var i = 1; i < rowspan; i++) {
    //需要拆分的单元格式第一列的
    /*if(startCol==1){
      var afterId=(startRow+i)+"_"+(startCol+1);
      var insertId=(startRow+i)+"_"+startCol;
      var td=$("<td>").attr("id",insertId).append($("<textarea rows='1'>"));
      $("#"+afterId).before(td);
    }else{*/
    //需要插入的td之前的td的id
    var beforeId = startRow + i + "_" + (startCol - 1);
    //需要插入的td的id
    var insertId = startRow + i + "_" + startCol;
    var td = $("<td>").attr("id", insertId).append($("<textarea rows='1'>"));
    //需要插入的td前id的td不存在
    if ($("#" + beforeId).length == 0) {
      //找出当前td所在行的所有td
      var currTdArr = $(tr[startRow + i - 1]).find("td");
      if (currTdArr.length > 0) {
        //当前行只有一个td
        if (currTdArr.length == 1) {
          var id = $(currTdArr[0]).attr("id");
          var col = id.split("_")[1];
          //td的列数大于拆分的单元格的列数
          if (col < startCol) {
            //将需要插入的td插入到id所代表的td的后面
            $("#" + id).after(td);
          } else {
            //将需要插入的td插入到id所代表的td的前面
            $("#" + id).before(td);
          }
        } else {
          for (var j = 0; j < currTdArr.length - 1; j++) {
            //当前循环的td的id
            var bId = $(currTdArr[j]).attr("id");
            //当前循环数组下一个的td的id
            var aId = $(currTdArr[j + 1]).attr("id");
            var bcol = bId.split("_")[1];
            var acol = aId.split("_")[1];
            //数组中的所有td的列数都大于需要插入开始列数
            if (bcol > startCol && j == 0) {
              $("#" + bId).before(td);
              break;
            } else if (bcol < startCol && acol > startCol) {
              //需要插入开始列数在数组中前后两个td的列数的中间
              $("#" + bId).after(td);
              break;
            } else if (bcol < startCol && acol < startCol && j + 1 == currTdArr.length - 1) {
              //需要插入开始列数大于数组中的所有列数
              $("#" + aId).after(td);
            }
          }
        }
      } else {
        $(tr[startRow + i - 1]).append(td);
      }
    } else {
      $("#" + beforeId).after(td);
    }
    //}
  }
}
//拆分单元格是只有列合并的时候
function revertTdOnlyCol(table, startRow, startCol, colspan) {
  var tr = table.find("tr");
  for (var i = 0; i < colspan - 1; i++) {
    var beforeId = startRow + "_" + (startCol + i);
    var insertId = startRow + "_" + (startCol + i + 1);
    var td = $("<td>").attr("id", insertId).append($("<textarea rows='1'>"));
    $("#" + beforeId).after(td);
  }
}
//拆分单元格是只有列合并的时候
function revertTdRowAndCol(table, startRow, startCol, rowspan, colspan) {
  var tr = table.find("tr");
  for (var i = 1; i < parseInt(rowspan) + 1; i++) {
    for (var j = 0; j <= colspan - 1; j++) {
      //拆分后第一个单元格不需要插入
      if (i == 1 && j == 0) {} else {
        //当拆分的单元格的起始列为1时做特殊处理
        if (startCol == 1) {
          //处理拆分的单元格的第一个需要拆分的行
          if (i == 1) {
            var beforeId = startRow + "_" + (startCol + j - 1);
            var insertId = startRow + "_" + (startCol + j);
            var td = $("<td>").attr("id", insertId).append($("<textarea rows='1'>"));
            $("#" + beforeId).after(td);
          } else {
            //第一列时的情况
            if (j == 0) {
              //需要插入的当前行
              var currTr = tr[startRow + i - 1 - 1];
              var insertId = startRow + i - 1 + "_" + "1";
              var td = $("<td>").attr("id", insertId).append($("<textarea rows='1'>"));
              var tdArr = $(currTr).find("td");
              //当前行有td
              if (tdArr.length > 0) {
                $(tdArr[0]).before(td);
              } else {
                $(currTr).append(td);
              }
            } else {
              var beforeId = startRow + i - 1 + "_" + (startCol + j - 1);
              var insertId = startRow + i - 1 + "_" + (startCol + j);
              var td = $("<td>").attr("id", insertId).append($("<textarea rows='1'>"));
              $("#" + beforeId).after(td);
            }
          }
        } else {
          //需要插入的td之前的td的id
          var beforeId = startRow + i - 1 + "_" + (startCol + j - 1);
          //需要插入的td的id
          var insertId = startRow + i - 1 + "_" + (startCol + j);
          var td = $("<td>").attr("id", insertId).append($("<textarea rows='1'>"));
          //需要插入的td前id的td不存在
          if ($("#" + beforeId).length == 0) {
            //找出当前td所在行的所有td
            var currTdArr = $(tr[startRow + i - 1 - 1]).find("td");
            if (currTdArr.length > 0) {
              //当前行只有一个td
              if (currTdArr.length == 1) {
                var id = $(currTdArr[0]).attr("id");
                var col = id.split("_")[1];
                //td的列数大于拆分的单元格的列数
                if (col < startCol) {
                  //将需要插入的td插入到id所代表的td的后面
                  $("#" + id).after(td);
                } else {
                  //将需要插入的td插入到id所代表的td的前面
                  $("#" + id).before(td);
                }
              } else {
                for (var k = 0; k < currTdArr.length - 1; k++) {
                  //当前循环的td的id
                  var bId = $(currTdArr[k]).attr("id");
                  //当前循环数组下一个的td的id
                  var aId = $(currTdArr[k + 1]).attr("id");
                  var bcol = bId.split("_")[1];
                  var acol = aId.split("_")[1];
                  //数组中的所有td的列数都大于需要插入开始列数
                  if (bcol > startCol && k == 0) {
                    $("#" + bId).before(td);
                    break;
                  } else if (bcol < startCol && acol > startCol) {
                    //需要插入开始列数在数组中前后两个td的列数的中间
                    $("#" + bId).after(td);
                    break;
                  } else if (bcol < startCol && acol < startCol && k + 1 == currTdArr.length - 1) {
                    //需要插入开始列数大于数组中的所有列数
                    $("#" + aId).after(td);
                  }
                }
              }
            } else {
              //直接在需要插入的行生成td
              $(tr[startRow + i - 1 - 1]).append(td);
            }
          } else {
            //在找到的td后插入生成的td
            $("#" + beforeId).after(td);
          }
        }
      }
    }
  }
}
function hideRCMenu() {
  $("#tableRCMenu").css('visibility', 'hidden');
}
function showRCMenu(e) {
  console.log(e);
  var menu = $("#tableRCMenu");
  menu.css("left", e.clientX + "px");
  menu.css("top", parseInt(e.clientY) - 100 + "px");
  menu.css('visibility', 'visible');
}
//获取变化后的table的所有信息更新到存储层
function getTableInfoToStore(tableEle) {
  tableEleBo.row = tableCountRow;
  tableEleBo.col = tableCountCol;
  tableEleBo.width = tableEle.width();
  tableEleBo.height = tableEle.height();
  tableEleBo.tr = [];
  var alltr = tableEle.find("tr");

  for (var i = 0; i < alltr.length > 0; i++) {
    var trElement = {
      td: [],
      height: null
    };
    var trTdArr = $(alltr[i]).find("td");
    for (var j = 0; j < trTdArr.length; j++) {
      var tdElement = {
        width: null,
        inerHtml: "",
        rowspan: null,
        colspan: null,
        id: ""
      };
      tdElement.id = $(trTdArr[j]).attr("id");
      var rowspan = getRowSpan($(trTdArr[j]));
      var colspan = getColSpan($(trTdArr[j]));
      if (rowspan != null) {
        tdElement.rowspan = rowspan;
      }
      if (colspan != null) {
        tdElement.colspan = colspan;
      }
      var textareaVal = $(trTdArr[j]).find("textarea").val();
      $(trTdArr[j]).find("textarea").html(textareaVal);
      tdElement.inerHtml = $(trTdArr[j]).html();
      trElement.td.push(tdElement);
    }
    tableEleBo.tr.push(trElement);
  }
  console.log(tableEleBo);
  _EditAreaStore2.default.updateTableData(tableEleBo);
}
var TableService = {
  createTableByStoreData: function createTableByStoreData(props) {
    hideRCMenu();
    var eleId = props.id + "table";
    var tableEle = $('#' + eleId);
    tableEle.empty();
    if (props.isNewTable) {
      console.log("新增");
      for (var i = 0; i < props.tableRow; i++) {
        var tr = $("<tr>");
        for (var j = 0; j < props.tableCol; j++) {
          var id = i + 1 + "_" + (j + 1);
          tr.append($("<td>").attr("id", id).append($("<textarea row='1'>")));
        }
        tableEle.append(tr);
      }
    } else {
      console.log("更新");
      var trArr = props.tr;
      for (var i = 0; i < trArr.length; i++) {
        var tr = $("<tr>");
        var tdArr = trArr[i].td;
        for (var j = 0; j < tdArr.length; j++) {
          var td = $("<td>").attr("id", tdArr[j].id);
          if (tdArr[j].rowspan != null) {
            td.attr("rowspan", tdArr[j].rowspan);
          }
          if (tdArr[j].colspan != null) {
            td.attr("colspan", tdArr[j].colspan);
          }
          td.html(tdArr[j].inerHtml);
          tr.append(td);
        }
        tableEle.append(tr);
      }
    }
    TableService.bindEvent(tableEle);
    TableService.inintTableInfo(props);
  },
  txtmouseDown: function txtmouseDown() {
    var e = window.event || arguments[0];
    e.stopPropagation();
    hideRCMenu();
    if (3 == e.which) {
      console.log("右击");
      return;
    }
    isTxtDown = true;
    isCellMoveSize = false;
    //console.log(isTxtDown);
    var tempEle = $(getEvetTarget(e));
    var startTxtMoveTd = tempEle.parent();
    var table = tempEle.parent().parent().parent();
    startTxtMoveTd_ID = startTxtMoveTd.attr('id');
    currMoveTxt_ID = startTxtMoveTd_ID;
    chosedTdArr = [];
    chosedTdArr.push($("#" + startTxtMoveTd_ID));
    table.find('td').removeAttr("bgcolor");
    table.find("textarea").removeAttr("style");
    getTableInfoToStore(table);
  },
  txtmouseMove: function txtmouseMove() {
    //console.log(isCellMoveSize)
    if (isCellMoveSize) {
      // setCursorStyle();
      // setTdNoEdit();
      return;
    }
    console.log(isTxtDown);
    var e = window.event || arguments[0];
    e.stopPropagation();
    //console.log(e);
    //文本移动 
    if (isTxtDown) {

      var tempEle = $(getEvetTarget(e));
      var tempTxtEle = tempEle.parent();
      var tempId = tempTxtEle.attr('id');
      var table = tempTxtEle.parent().parent().parent();
      allTd = table.find('td');
      allTd.removeAttr("bgcolor");
      table.find("textarea").removeAttr("style");
      //不一致
      console.log(startTxtMoveTd_ID + "  " + tempId);
      if (startTxtMoveTd_ID != tempId) {
        //debugger;
        //console.log(startTxtMoveTd_ID+"  "+tempId);
        var startTdX = $("#" + startTxtMoveTd_ID).offset().left;
        var startTdY = $("#" + startTxtMoveTd_ID).offset().top;
        var currmouseX = e.clientX;
        var currmouseY = e.clientY;
        //设置鼠标移动到的td的背景色（以每个td的id为基准设置符合要求的td改变背景色）
        //往右下移动
        if (currmouseX - startTdX > 0 && currmouseY - startTdY > 0) {
          tableMoveLowerRight(startTxtMoveTd_ID, tempId);
        } //往右上移动
        else if (currmouseX - startTdX > 0 && currmouseY - startTdY < 0) {
            tableMoveUpperRight(startTxtMoveTd_ID, tempId);
          } //往左上移动
          else if (currmouseX - startTdX < 0 && currmouseY - startTdY < 0) {
              tableMoveUpperLeft(startTxtMoveTd_ID, tempId);
            } //往左下移动
            else if (currmouseX - startTdX < 0 && currmouseY - startTdY > 0) {
                tableMoveLowerLeft(startTxtMoveTd_ID, tempId);
              }
      } else {
        chosedTdArr = [];
        chosedTdArr.push($("#" + startTxtMoveTd_ID));
      }
    }
  },
  txtmouseUp: function txtmouseUp() {
    isTxtDown = false;
  },
  tdMouseMove: function tdMouseMove() {
    var e = window.event || arguments[0];
    if (isSizePre == false) {
      //console.log("tdMouseMove");
      isSizePre = true;
      tdMouseDownBody(e);
    }
  },
  tdMouseOut: function tdMouseOut() {
    isSizePre = false;
    // isCellMoveSize=false;
    var mhEle = $('#moveHelp');
  },
  tdMouseDown: function tdMouseDown() {
    var e = window.event || arguments[0];
    currStartTd = $(getEvetTarget(e));
    // console.log('hello'+$('#table').css('top'));
    tdMouseDownBody(e);
    hideRCMenu();
    // 在范围类
    if (isSizePre) {

      isCellMoveSize = true;
      //console.log(currStartTd);
      moveStartx = e.pageX;
      moveStartY = e.pageY;
      if (moveType == 'l' || moveType == 'r') {
        var mhEle = $('#moveHelp');
        mhEle.css('left', e.pageX + 'px');
        mhEle.css('top', $('#table').css('top'));
        mhEle.css('height', $('#table').height() + 'px');
        mhEle.css('width', '2px');
        var tableEle = $('#table');
        //console.log("tableEleWidth>>"+tableEle.css('width'));
        var moveHelpDiv = $('#moveHelpDiv');
        //moveHelpDiv.css('left', tableEle.css('left'));
        moveHelpDiv.css('left', 0);
        //moveHelpDiv.css('top', tableEle.css('top'));
        moveHelpDiv.css('top', 0);
        //moveHelpDiv.css('width', parseInt(tableEle.css('width'))+30+"px");
        //moveHelpDiv.css('height', tableEle.css('height'));
        moveHelpDiv.css('width', $(window).width());
        moveHelpDiv.css('height', $(window).height());
        showHelp();
      } else if (moveType == 't' || moveType == 'b') {
        var mhEle = $('#moveHelp');
        mhEle.css('left', $('#table').css('left'));
        mhEle.css('top', e.pageY);
        mhEle.css('height', '2px');
        mhEle.css('width', $('#table').width() + 'px');

        var tableEle = $('#table');
        var moveHelpDiv = $('#moveHelpDiv');
        //moveHelpDiv.css('left', tableEle.css('left'));
        moveHelpDiv.css('left', 0);
        //moveHelpDiv.css('top', tableEle.css('top'));
        moveHelpDiv.css('top', 0);
        //moveHelpDiv.css('width', parseInt(tableEle.css('width'))+30);
        //moveHelpDiv.css('width', parseInt(tableEle.css('width'))+30+"px");
        //moveHelpDiv.css('height', parseInt(tableEle.css('height'))+30);
        //moveHelpDiv.css('height', parseInt(tableEle.css('height'))+30+"px");
        moveHelpDiv.css('width', $(window).width());
        moveHelpDiv.css('height', $(window).height());
        showHelp();
      }
    }
  },
  //拆分单元格
  revertTd: function revertTd() {
    var currTd = $("#" + startTxtMoveTd_ID);
    hideRCMenu();
    //没有选中的td时
    if (currTd.length == 0) {
      return;
    }
    var table = currTd.parent().parent();
    var startRowAndCol = getTdIdRowAndCol(startTxtMoveTd_ID);
    var startRow = startRowAndCol.row;;
    var startCol = startRowAndCol.col;
    var rowspan = 0;
    var colspan = 0;
    var curTdRowspan = getRowSpan(currTd);
    var curTdColspan = getColSpan(currTd);
    if (curTdRowspan != null) {
      rowspan = curTdRowspan;
    }
    if (curTdColspan != null) {
      colspan = curTdColspan;
    }
    /*
    if(typeof(currTd.attr("rowspan"))!="undefined"){
      rowspan=currTd.attr("rowspan");
    }
    if(typeof(currTd.attr("colspan"))!="undefined"){
      colspan=currTd.attr("colspan");
    }*/
    if (rowspan == 0 && colspan == 0) {
      return;
    } else if (rowspan != 0 && colspan == 0) {
      //只有行合并
      revertTdOnlyRow(table, startRow, startCol, rowspan);
    } else if (rowspan == 0 && colspan != 0) {
      //只有列合并
      revertTdOnlyCol(table, startRow, startCol, colspan);
    } else {
      //都有
      revertTdRowAndCol(table, startRow, startCol, rowspan, colspan);
    }
    //删除拆分的单元格的rowspan和colspan属性
    $("#" + startTxtMoveTd_ID).removeAttr("rowspan");
    $("#" + startTxtMoveTd_ID).removeAttr("colspan");
    chosedTdArr = [];
    //给新生成的td重新绑定事件
    TableService.bindEvent(table);
    getTableInfoToStore(table);
  },
  //合并单元格
  combineTd: function combineTd() {
    hideRCMenu();
    if (chosedTdArr.length <= 1) {
      return;
    }
    var table;
    var afterCombineTdId;
    var rowspan = 0;
    var colspan = 0;
    var minRow = 1;
    var maxRow = 1;
    var minCol = 1;
    var maxCol = 1;
    for (var i = 0; i < chosedTdArr.length; i++) {
      var id = chosedTdArr[i].attr("id");
      var currRowAndCol = getTdIdRowAndCol(id);
      var currRow = currRowAndCol.row;;
      var currCol = currRowAndCol.col;
      //当第一次循环时选中范围的最小行和列的就是当前的行和列
      if (i == 0) {
        table = chosedTdArr[i].parent().parent().parent();
        minRow = currRow;
        minCol = currCol;
      }
      //当前的行大于选中范围的的最大行
      if (currRow > maxRow) {
        maxRow = currRow;
      }
      var choseTdRowspan = getRowSpan(chosedTdArr[i]);
      //当前的td有行合并时
      if (choseTdRowspan != null) {
        //当前td的最大真实行
        var realRow = currRow + choseTdRowspan - 1;
        //当前的真实行大于选中范围的的最大行
        if (realRow > maxRow) {
          maxRow = realRow;
        }
      }
      //当前的列数大于选中范围的的最大行
      if (currCol > maxCol) {
        maxCol = currCol;
      }
      var choseTdColspan = getColSpan(chosedTdArr[i]);
      //当前的td有列合并时
      if (choseTdColspan != null) {
        //当前td的最大真实列
        var realCOl = currCol + choseTdColspan - 1;
        //当前的真实列大于选中范围的的最大列
        if (realCOl > maxCol) {
          maxCol = realCOl;
        }
      }
    }
    //计算rowspan和colspan
    rowspan = maxRow - minRow + 1;
    colspan = maxCol - minCol + 1;
    for (var i = 0; i < chosedTdArr.length; i++) {
      //给选中的第一个td加rowspan和colspan
      if (i == 0) {
        if (rowspan > 1) {
          chosedTdArr[i].attr("rowspan", rowspan);
        }
        if (colspan > 1) {
          chosedTdArr[i].attr("colspan", colspan);
        }
      } else {

        console.log(33);
        //删除选中其他td
        chosedTdArr[i].remove();
      }
    }
    table.find('td').removeAttr("bgcolor");
    table.find("textarea").removeAttr("style");
    chosedTdArr = [];
    //给新生成的td重新绑定事件
    TableService.bindEvent(table);
    getTableInfoToStore(table);
  },
  textRightCliCK: function textRightCliCK() {
    var e = window.event;
    showRCMenu(e);
    return false;
    //e.preventDefault(); //阻止事件
    //alert("右击");
  },
  bindEvent: function bindEvent(tableEle) {
    var txtArr = tableEle.find("td").find("textarea");
    // alert(tdArr.length);
    for (var i = 0; i < txtArr.length; i++) {
      var tdTxt = txtArr[i];

      $(tdTxt).bind('mousedown', this.txtmouseDown);
      $(tdTxt).bind('mouseover', this.txtmouseMove);
      $(tdTxt).bind('mouseup', this.txtmouseUp);
      $(tdTxt).bind('contextmenu', this.textRightCliCK);
      //$(tdTxt).hover(txtmouseMove,null);
    }

    var tdArr = tableEle.find('tr').children();

    // alert(tdArr.length);
    for (var i = 0; i < tdArr.length; i++) {
      var tdtemp = tdArr[i];
      $(tdtemp).bind('mousemove', this.tdMouseMove);
      $(tdtemp).bind('mouseout', this.tdMouseOut);
      $(tdtemp).bind('mousedown', this.tdMouseDown);
    }
  },
  inintTableInfo: function inintTableInfo(tableProps) {
    tableCountRow = tableProps.tableRow;
    tableCountCol = tableProps.tableCol;
    tableEleBo = tableProps;
  },
  //向上插入一行
  insertTrBefore: function insertTrBefore() {
    hideRCMenu();
    //选中的td所在的tr
    var currentTr = $("#" + startTxtMoveTd_ID).parent();
    //当前的table对象
    var tableEle = currentTr.parent();
    //当前行的后面的所有行
    var nextAllTr = currentTr.nextAll();
    //当前的行数
    var currRow = getTdIdRowAndCol(startTxtMoveTd_ID).row;
    //在当前的行的上面插入一行，行里的td数是table的最大列数
    var insertTrEle = $("<tr>");
    for (var i = 1; i <= tableCountCol; i++) {
      var id = currRow + "_" + i;
      insertTrEle.append($("<td>").attr("id", id).append($("<textarea row='1' value='插入的行'>")));
    }
    currentTr.before(insertTrEle);
    nextAllTr = insertTrEle.nextAll();
    console.log(nextAllTr);
    //改变插入的行后面的行的所td的id(依次加1)
    for (var i = 1; i <= nextAllTr.length; i++) {
      var tdArr = $(nextAllTr[i - 1]).find("td");
      if (tdArr.length != 0) {
        var tdRow = currRow + i;
        for (var j = 0; j < tdArr.length; j++) {
          var tdCol = getTdIdRowAndCol($(tdArr[j]).attr("id")).col;
          var id = tdRow + "_" + tdCol;
          $(tdArr[j]).attr("id", id);
        }
      }
    }
    //去除插入的不需要的td
    //如果插入td的所在范围是在之前合并过后的范围内,需要删除此td，并且将之前合并的替代的rowspan加1
    var allTdArr = $(currentTr).parent().find("td");
    for (var i = 0; i < allTdArr.length; i++) {
      var rowspan = getRowSpan($(allTdArr[i]));
      var colspan = getColSpan($(allTdArr[i]));
      var tdRowAndCol = getTdIdRowAndCol($(allTdArr[i]).attr("id"));
      var rowVal = tdRowAndCol.row;
      var colVal = tdRowAndCol.col;

      if (rowspan != null) {
        if (rowVal <= currRow && rowVal + rowspan - 1 >= currRow) {
          if (colspan != null) {
            for (var j = 0; j < colspan; j++) {
              var id = currRow + "_" + (colVal + j);
              $("#" + id).remove();
            }
          } else {
            var id = currRow + "_" + colVal;
            $("#" + id).remove();
          }
          $(allTdArr[i]).attr("rowspan", rowspan + 1);
        }
      }
    }
    //将表格行数加1
    tableCountRow = tableCountRow + 1;
    //给新生成的td重新绑定事件
    TableService.bindEvent($(currentTr).parent());
    //将改变后的数据存在存储层中
    getTableInfoToStore(tableEle);
  },
  //向下插入一行
  insertTrAfter: function insertTrAfter() {
    hideRCMenu();
    var currentTr = $("#" + startTxtMoveTd_ID).parent();
    var tableEle = currentTr.parent();
    var currRow = getTdIdRowAndCol(startTxtMoveTd_ID).row;
    var nextAllTr = currentTr.nextAll();
    var rowspan = getRowSpan($("#" + startTxtMoveTd_ID));
    if (rowspan != null) {
      currRow = currRow + rowspan - 1;
      currentTr = $(nextAllTr[rowspan - 2]);
      nextAllTr = $(nextAllTr[rowspan - 2]).nextAll();
    }
    var insertTrEle = $("<tr>");
    for (var i = 1; i <= tableCountCol; i++) {
      var id = currRow + 1 + "_" + i;
      insertTrEle.append($("<td>").attr("id", id).append($("<textarea row='1' value='插入的行'>")));
    }
    console.log(nextAllTr);
    for (var i = 1; i <= nextAllTr.length; i++) {
      var tdArr = $(nextAllTr[i - 1]).find("td");
      if (tdArr.length != 0) {
        var tdRow = currRow + i + 1;
        for (var j = 0; j < tdArr.length; j++) {
          var tdCol = getTdIdRowAndCol($(tdArr[j]).attr("id")).col;
          var id = tdRow + "_" + tdCol;
          $(tdArr[j]).attr("id", id);
        }
      }
    }
    currentTr.after(insertTrEle);
    //去除插入的不需要的td
    var allTdArr = $(currentTr).parent().find("td");
    for (var i = 0; i < allTdArr.length; i++) {
      var rowspan = getRowSpan($(allTdArr[i]));
      var colspan = getColSpan($(allTdArr[i]));
      var tdRowAndCol = getTdIdRowAndCol($(allTdArr[i]).attr("id"));
      var rowVal = tdRowAndCol.row;
      var colVal = tdRowAndCol.col;
      if (rowspan != null && rowVal < currRow + 1 && rowVal + rowspan - 1 >= currRow + 1) {
        if (colspan != null) {
          for (var j = 0; j < colspan; j++) {
            var id = currRow + 1 + "_" + (colVal + j);
            $("#" + id).remove();
          }
        } else {
          var id = currRow + 1 + "_" + colVal;
          $("#" + id).remove();
        }
        $(allTdArr[i]).attr("rowspan", rowspan + 1);
      }
    }
    tableCountRow = tableCountRow + 1;
    //给新生成的td重新绑定事件
    TableService.bindEvent($(currentTr).parent());
    getTableInfoToStore(tableEle);
  },
  //向右插入单元格
  insertColAfter: function insertColAfter() {
    hideRCMenu();
    //选中td所在的表格行
    var currentTr = $("#" + startTxtMoveTd_ID).parent();
    //当前表格
    var tableEle = currentTr.parent();
    //选中td的列数
    var currCol = getTdIdRowAndCol(startTxtMoveTd_ID).col;
    //选中td的colspan值
    var colspan = getColSpan($("#" + startTxtMoveTd_ID));
    //当colspan值不为空，将当前列数加上colspan-1(即将插入的td的列数要往后推colspan的值)
    if (colspan != null) {
      currCol = currCol + colspan - 1;
    }
    //获取当前table的所有行
    var alltr = $(currentTr).parent().find("tr");
    //在每行的正确位置插入一个td并且把插入的位置后面的td的ID中的col值加1
    for (var i = 1; i <= tableCountRow; i++) {
      //生成需要插入的td
      var insertTd = $("<td>").attr("id", i + "_" + (currCol + 1)).append($("<textarea row='1' value='插入的行'>"));
      //找到每行需要的插入的位置的td(从插入的td的列数开始往前推)
      for (var j = currCol; j >= 1; j--) {
        var tdId = i + "_" + j;
        var afterTd = $("#" + tdId);
        var nextTdArr;
        if (afterTd.length > 0) {
          nextTdArr = afterTd.nextAll();
          afterTd.after(insertTd);
          for (var k = 0; k < nextTdArr.length; k++) {
            var row = getTdIdRowAndCol($(nextTdArr[k]).attr("id")).row;
            var col = getTdIdRowAndCol($(nextTdArr[k]).attr("id")).col;
            var changeId = row + "_" + (col + 1);
            $(nextTdArr[k]).attr("id", changeId);
          }
          break;
        } else if (j == 1) {
          nextTdArr = $(alltr[i - 1]).find("td");
          if (nextTdArr.length > 0) {
            $(nextTdArr[0]).before(insertTd);
            for (var k = 0; k < nextTdArr.length; k++) {
              var row = getTdIdRowAndCol($(nextTdArr[k]).attr("id")).row;
              var col = getTdIdRowAndCol($(nextTdArr[k]).attr("id")).col;
              var changeId = row + "_" + (col + 1);
              $(nextTdArr[k]).attr("id", changeId);
            }
          } else {
            $(alltr[i - 1]).append(insertTd);
          }
        }
      }
    }
    //有td有合并并且之前插入的td的位置在合并的范围内，删除多出的td
    var allTd = $(currentTr).parent().find("td");
    for (var i = 0; i < allTd.length; i++) {
      var colspan = getColSpan($(allTd[i]));
      var rowspan = getRowSpan($(allTd[i]));
      var tdRowAndCol = getTdIdRowAndCol($(allTd[i]).attr("id"));
      var tdCol = tdRowAndCol.col;
      var tdRow = tdRowAndCol.row;
      if (colspan != null) {
        if (tdCol < currCol + 1 && tdCol + colspan - 1 >= currCol + 1) {
          var id = tdRow + "_" + (currCol + 1);
          $("#" + id).remove();
          if (rowspan != null) {
            for (var j = 1; j < rowspan; j++) {
              id = tdRow + j + "_" + (currCol + 1);
              $("#" + id).remove();
            }
          }
          $(allTd[i]).attr("colspan", colspan + 1);
        }
      }
    }
    //将table的列数加1
    tableCountCol = tableCountCol + 1;
    //给新生成的td重新绑定事件
    TableService.bindEvent($(currentTr).parent());
    getTableInfoToStore(tableEle);
  },
  //向左插入单元格
  insertColBefore: function insertColBefore() {
    hideRCMenu();
    //
    var currentTr = $("#" + startTxtMoveTd_ID).parent();
    var tableEle = currentTr.parent();
    var currCol = getTdIdRowAndCol(startTxtMoveTd_ID).col;
    var alltr = $(currentTr).parent().find("tr");
    for (var i = 1; i <= tableCountRow; i++) {
      var insertTd = $("<td>").attr("id", i + "_" + currCol).append($("<textarea row='1' value='插入的行'>"));
      for (var j = currCol; j >= 1; j--) {
        var tdId = i + "_" + j;
        var beforeTd = $("#" + tdId);
        var nextTdArr;
        if (beforeTd.length > 0) {
          nextTdArr = beforeTd.nextAll();
          if (j == currCol) {
            beforeTd.before(insertTd);
            beforeTd.attr("id", i + "_" + (j + 1));
          } else {
            beforeTd.after(insertTd);
          }
          for (var k = 0; k < nextTdArr.length; k++) {
            var row = getTdIdRowAndCol($(nextTdArr[k]).attr("id")).row;
            var col = getTdIdRowAndCol($(nextTdArr[k]).attr("id")).col;
            var changeId = row + "_" + (col + 1);
            $(nextTdArr[k]).attr("id", changeId);
          }

          break;
        } else if (j == 1) {
          nextTdArr = $(alltr[i - 1]).find("td");
          if (nextTdArr.length > 0) {
            $(nextTdArr[0]).before(insertTd);
            for (var k = 0; k < nextTdArr.length; k++) {
              var row = getTdIdRowAndCol($(nextTdArr[k]).attr("id")).row;
              var col = getTdIdRowAndCol($(nextTdArr[k]).attr("id")).col;
              var changeId = row + "_" + (col + 1);
              $(nextTdArr[k]).attr("id", changeId);
            }
          } else {
            $(alltr[i - 1]).append(insertTd);
          }
        }
      }
    }
    //有合并时取出多出的td
    var allTd = $(currentTr).parent().find("td");
    for (var i = 0; i < allTd.length; i++) {
      var colspan = getColSpan($(allTd[i]));
      var rowspan = getRowSpan($(allTd[i]));
      var tdRowAndCol = getTdIdRowAndCol($(allTd[i]).attr("id"));
      var tdCol = tdRowAndCol.col;
      var tdRow = tdRowAndCol.row;
      if (colspan != null) {
        if (tdCol < currCol && tdCol + colspan - 1 >= currCol) {
          var id = tdRow + "_" + currCol;
          $("#" + id).remove();
          if (rowspan != null) {
            for (var j = 1; j < rowspan; j++) {
              id = tdRow + j + "_" + currCol;
              $("#" + id).remove();
            }
          }
          $(allTd[i]).attr("colspan", colspan + 1);
        }
      }
    }
    tableCountCol = tableCountCol + 1;
    //给新生成的td重新绑定事件
    TableService.bindEvent($(currentTr).parent());
    getTableInfoToStore(tableEle);
  },
  //删除选中的行
  deleteChoiceRow: function deleteChoiceRow() {
    hideRCMenu();
    if (chosedTdArr.length == 0) {
      return;
    }
    var choiceRow = {};
    var tableEle;
    var minRow;
    var maxRow;
    for (var i = 0; i < chosedTdArr.length; i++) {
      var tdEle = chosedTdArr[i];
      tableEle = chosedTdArr[i].parent().parent();
      var tdRowAndCol = getTdIdRowAndCol(tdEle.attr("id"));
      var row = tdRowAndCol.row;
      var col = tdRowAndCol.col;
      var rowspan = getRowSpan(tdEle);
      choiceRow[row] = 1;
      if (rowspan != null) {
        for (var j = 1; j < rowspan; j++) {
          choiceRow[row + j] = 1;
        }
      }
    }
    var allTr = tableEle.find("tr");
    var allTd = tableEle.find("td");
    var flag = 1;
    Object.keys(choiceRow).map(function (row) {
      if (flag == 1) {
        minRow = row;
        maxRow = row;
      } else if (row > maxRow) {
        maxRow = row;
      }
      flag++;
    });
    for (var i = 0; i < allTd.length; i++) {
      var rowspan = getRowSpan($(allTd[i]));
      var colspan = getColSpan($(allTd[i]));
      var tdRow = getTdIdRowAndCol($(allTd[i]).attr("id")).row;
      var tdMaxRow = tdRow + rowspan - 1;
      if (rowspan != null && tdRow < minRow && tdMaxRow >= minRow) {
        var delRowVal;
        if (tdMaxRow > maxRow) {
          delRowVal = maxRow - minRow + 1;
        } else {
          delRowVal = tdMaxRow - minRow + 1;
        }
        if (rowspan - delRowVal == 1) {
          $(allTd[i]).removeAttr("rowspan");
        } else {
          $(allTd[i]).attr("rowspan", rowspan - delRowVal);
        }
      } else if (rowspan != null && tdRow >= minRow && tdRow <= maxRow && tdMaxRow > maxRow) {
        var delRowVal = maxRow - tdRow + 1;
        var row = parseInt(maxRow) + 1;
        var col = getTdIdRowAndCol($(allTd[i]).attr("id")).col;
        if (rowspan - delRowVal == 1) {
          $(allTd[i]).removeAttr("rowspan");
        } else {
          $(allTd[i]).attr("rowspan", rowspan - delRowVal);
        }
        //var newTdEle=$("<td>").attr("id",row+"_"+col).attr("rowspan",rowspan-delRowVal).attr("").append($("<textarea row='1' value='新的行'>"));
        //$(allTd[i]).attr("id",row+"_"+col).attr("rowspan",rowspan-delRowVal);
        for (var j = col; j <= tableCountCol; j++) {
          var id = row + "_" + j;
          var currTd = $("#" + id);
          if (currTd.length > 0) {
            currTd.before($(allTd[i]));
            break;
          } else if (j == tableCountCol) {
            $(allTr[row - 1]).appned($(allTd[i]));
          }
        }
      }
    }
    Object.keys(choiceRow).map(function (row) {
      $(allTr[row - 1]).remove();
    });
    var needChangeTrArr;
    if (minRow == 1) {
      needChangeTrArr = tableEle.find("tr");
    } else {
      allTr = tableEle.find("tr");
      needChangeTrArr = $(allTr[minRow - 2]).nextAll("tr");
    }
    //=$(allTr[minRow-2]).nextAll();
    console.log(needChangeTrArr);
    for (var i = 0; i < needChangeTrArr.length; i++) {
      var changeRow = parseInt(minRow) + i;
      var tdArr = $(needChangeTrArr[i]).find("td");
      for (var j = 0; j < tdArr.length; j++) {
        var col = getTdIdRowAndCol($(tdArr[j]).attr("id")).col;
        $(tdArr[j]).attr("id", changeRow + "_" + col);
      }
    }
    tableCountRow = tableCountRow - (parseInt(maxRow) - parseInt(minRow) + 1);
    getTableInfoToStore(tableEle);
  },
  //删除选中的列
  deleteChoiceCol: function deleteChoiceCol() {
    hideRCMenu();
    if (chosedTdArr.length == 0) {
      return;
    }
    var choiceCol = {};
    var tableEle;
    var minCol;
    var maxCol;
    for (var i = 0; i < chosedTdArr.length; i++) {
      var tdEle = chosedTdArr[i];
      tableEle = chosedTdArr[i].parent().parent();
      var tdRowAndCol = getTdIdRowAndCol(tdEle.attr("id"));
      var row = tdRowAndCol.row;
      var col = tdRowAndCol.col;
      var colspan = getColSpan(tdEle);
      choiceCol[col] = 1;
      if (colspan != null) {
        for (var j = 1; j < colspan; j++) {
          choiceCol[col + j] = 1;
        }
      }
    }
    console.log(choiceCol);
    var allTd = tableEle.find("td");
    var flag = 1;
    Object.keys(choiceCol).map(function (col) {
      if (flag == 1) {
        minCol = col;
        maxCol = col;
      } else if (col > maxCol) {
        maxCol = col;
      }
      flag++;
    });
    for (var i = 0; i < allTd.length; i++) {
      var rowspan = getRowSpan($(allTd[i]));
      var colspan = getColSpan($(allTd[i]));
      var tdCol = getTdIdRowAndCol($(allTd[i]).attr("id")).col;
      var tdRow = getTdIdRowAndCol($(allTd[i]).attr("id")).row;
      if (colspan == null && tdCol >= minCol && tdCol <= maxCol) {
        $(allTd[i]).remove();
      } else if (colspan != null) {
        var tdMaxCol = tdCol + colspan - 1;
        var delColVal;
        if (tdCol < minCol && tdMaxCol >= minCol) {
          if (tdMaxCol <= maxCol) {
            delColVal = tdMaxCol - minCol + 1;
          } else {
            delColVal = maxCol - minCol + 1;
          }
          $(allTd[i]).attr("colspan", colspan - delColVal);
        } else if (tdCol >= minCol && tdCol <= maxCol && tdMaxCol > maxCol) {
          delColVal = maxCol - tdCol + 1;
          var id = tdRow + "_" + (parseInt(maxCol) + 1);
          var cloneTd = $(allTd[i]).clone(true);
          cloneTd.attr("colspan", colspan - delColVal).attr("id", id);
          $(allTd[i]).after(cloneTd);
          $(allTd[i]).remove();
        } else if (tdCol >= minCol && tdMaxCol <= maxCol) {
          $(allTd[i]).remove();
        }
      }
    }
    var delColNum = parseInt(maxCol) - parseInt(minCol) + 1;
    //修改改变后的td的id
    var allTr = tableEle.find("tr");
    for (var i = 0; i < allTr.length; i++) {
      var allTd = $(allTr[i]).find("td");
      for (var j = 0; j < allTd.length; j++) {
        var rowAndCol = getTdIdRowAndCol($(allTd[j]).attr("id"));
        var row = rowAndCol.row;
        var col = rowAndCol.col;
        if (col > minCol) {
          var id = row + "_" + (col - delColNum);
          $(allTd[j]).attr("id", id);
        }
      }
    }
    tableCountCol = tableCountCol - delColNum;
    getTableInfoToStore(tableEle);
  }
};
exports.default = TableService;

/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

var _TxtService = __webpack_require__(10);

var _TxtService2 = _interopRequireDefault(_TxtService);

var _CpRundata = __webpack_require__(13);

var _CpRundata2 = _interopRequireDefault(_CpRundata);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var TxtBase = function (_Component) {
  _inherits(TxtBase, _Component);

  function TxtBase() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, TxtBase);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = TxtBase.__proto__ || Object.getPrototypeOf(TxtBase)).call.apply(_ref, [this].concat(args))), _this), _this.init = function () {
      /*var eleId = this.props.id;
      var txtEle = $('#eleId').children(".txt_AreaText");
      txtEle[0].style.height = 'auto';
      txtEle[0].crollTop = 0; 
      txtEle.css('width',this.props.tw);
      //txtEle.css('height',this.props.th);
      txtEle.css('height', txtEle[0].scrollHeight + 'px');*/

      var eleId = _this.props.id;
      var parentDivEle = $('#' + eleId);

      //边框没有计算在内
      //currTxtAreaEle.css('width', this.props.width + 'px');
      //currTxtAreaEle.css('height', this.props.height + 'px');

      parentDivEle[0].style.width = _this.props.width + 'px';
      parentDivEle[0].style.height = _this.props.height + 'px';
    }, _this.getEvetTarget = function (event) {
      return event.srcElement ? event.srcElement : event.target;
    }, _this.oninput = function (event) {
      //console.log("come  in"+CpConst.txt_help_width);
      event.preventDefault(); //阻止事件
      event.stopPropagation();
      var currTxtAreaEle = $(_this.getEvetTarget(event));
      var paretEle = currTxtAreaEle.parent();
      _TxtService2.default.setTxtSize(currTxtAreaEle, paretEle);
    }, _this.onmousemove = function (event) {
      //event.preventDefault(); //阻止事件
      event.stopPropagation();
    }, _this.onmouseDown = function (event) {
      event.stopPropagation();
      _CpRundata2.default.txtDownByMove = true;
      _this.props.onSelectCanvas(_this.props.id);
      _CpRundata2.default.shapeOriginalData = [];
      var tempData = _this.props.getCanvasBySelected();
      for (var i in tempData) {
        _CpRundata2.default.shapeOriginalData.push(_extends({}, tempData[i]));
      }
    }, _this.onmouseDownByDiv = function (event) {
      event.stopPropagation();
      _CpRundata2.default.txtDownByMove = false;
      _this.props.onSelectCanvas(_this.props.id);
      _CpRundata2.default.shapeOriginalData = [];
      var tempData = _this.props.getCanvasBySelected();
      for (var i in tempData) {
        _CpRundata2.default.shapeOriginalData.push(_extends({}, tempData[i]));
      }
    }, _this.onmouseUp = function (event) {
      _CpRundata2.default.txtDownByMove = false;
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(TxtBase, [{
    key: 'componentDidMount',


    //this.props //获取当前传递过来的数据

    //初始执行函数
    value: function componentDidMount() {
      setTimeout(this.init, 0);
    }
  }, {
    key: 'render',
    value: function render() {
      return (0, _preact.h)(
        'div',
        { id: this.props.id, className: 'txt_Div', onMouseUp: this.onmouseUp, onMouseDown: this.onmouseDownByDiv },
        (0, _preact.h)('textarea', { contenteditable: 'true', 'class': 'txt_AreaText', style: { fontWeight: this.props.fontWeight },
          onInput: this.oninput, onMouseMove: this.onmousemove, onMouseDown: this.onmouseDown, onMouseUp: this.onmouseUp })
      );
    }
  }]);

  return TxtBase;
}(_preact.Component);

exports.default = TxtBase;

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _preact = __webpack_require__(0);

var _Outer = __webpack_require__(28);

var _Outer2 = _interopRequireDefault(_Outer);

var _top = __webpack_require__(30);

var _top2 = _interopRequireDefault(_top);

var _Left = __webpack_require__(27);

var _Left2 = _interopRequireDefault(_Left);

var _Center = __webpack_require__(26);

var _Center2 = _interopRequireDefault(_Center);

var _Right = __webpack_require__(29);

var _Right2 = _interopRequireDefault(_Right);

var _LayoutStore = __webpack_require__(3);

var _LayoutStore2 = _interopRequireDefault(_LayoutStore);

var _EditAreaStore = __webpack_require__(2);

var _EditAreaStore2 = _interopRequireDefault(_EditAreaStore);

var _MarqueeStore = __webpack_require__(25);

var _MarqueeStore2 = _interopRequireDefault(_MarqueeStore);

var _NavPageStore = __webpack_require__(15);

var _NavPageStore2 = _interopRequireDefault(_NavPageStore);

var _Event = __webpack_require__(16);

var _Event2 = _interopRequireDefault(_Event);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var getState = {
  layout: _LayoutStore2.default.getState(), // 界面布局数据
  canvas: _EditAreaStore2.default.getState(), // 画布数据,
  marquee: _MarqueeStore2.default.getState(), // 画布->选取框数据
  navePageList: _NavPageStore2.default.getState() };

var getStores = {
  getCanvasById: _EditAreaStore2.default.getCanvasById, //根据id获取组件，类似于getElementById
  getCanvasBySelected: _EditAreaStore2.default.getCanvasBySelected,
  getCanvasIdBySelected: _EditAreaStore2.default.getCanvasIdBySelected,
  getAllCanvasBySelected: null, //获取选中的全部组件，返回id数组

  onUpdataLayout: _LayoutStore2.default.updataLayout, //更新页面布局
  onUpdataCanvasById: _EditAreaStore2.default.updataCanvasById, //更新一个组件
  onUpdataSelectedCanvasByValue: _EditAreaStore2.default.updataSelectedCanvasByVaule, //更新选中的组件，参数是计算值
  onUpdataSelectedCanvasByDiff: _EditAreaStore2.default.updataSelectedCanvasByDiff, //更新选中的组件，参数是差值
  onAddCanvas: _EditAreaStore2.default.addCanvas, //添加一个组件
  onDeleteCanvas: _EditAreaStore2.default.deleteCanvas, //删除选中的组件
  onSelectCanvas: _EditAreaStore2.default.selectCanvas, //选中一个组件
  onSelectCanvasByRect: _EditAreaStore2.default.selectCanvasByRect, //选中矩形内的组件
  onCancelSelected: _EditAreaStore2.default.cancelSelected, // 取消选中的组件

  onUpdataMarquee: _MarqueeStore2.default.updataMarquee
};

var MainView = function (_Component) {
  _inherits(MainView, _Component);

  function MainView() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, MainView);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = MainView.__proto__ || Object.getPrototypeOf(MainView)).call.apply(_ref, [this].concat(args))), _this), _this._onChange = function () {
      _this.setState(getState);
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(MainView, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      _LayoutStore2.default.addChangeListener(this._onChange);
    }
  }, {
    key: 'componentWillUnmount',
    value: function componentWillUnmount() {
      _LayoutStore2.default.removeChangeListener(this._onChange);
    }
  }, {
    key: 'render',
    value: function render(_ref2) {
      var _ref2$props = _ref2.props,
          props = _ref2$props === undefined ? _extends({}, getStores, getState) : _ref2$props;

      return (0, _preact.h)(
        _Outer2.default,
        props,
        (0, _preact.h)(_top2.default, props),
        (0, _preact.h)(_Left2.default, props),
        (0, _preact.h)(_Center2.default, props),
        (0, _preact.h)(_Right2.default, props)
      );
    }
  }]);

  return MainView;
}(_preact.Component);

exports.default = MainView;

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Marquee2 = function () {
  function Marquee2() {
    _classCallCheck(this, Marquee2);

    this.state = {
      canvasPosition: { x: 0, y: 0 },
      originalCursorPosition: { x: 0, y: 0 },
      marqueeRect: { x: 0, y: 0, width: 0, height: 0 }
    };
    this.block = {
      domElement: $('#mainEditArea')
    };
    this.render();
    this.bind();
    this.layout();
  }

  _createClass(Marquee2, [{
    key: 'render',
    value: function render() {
      this.domElement = $('<div>');
    }
  }, {
    key: 'destroy',
    value: function destroy() {}
  }, {
    key: 'bind',
    value: function bind() {
      this.onMouseDown = this.onMouseDown.bind(this);
      this.onMouseMove = this.onMouseMove.bind(this);
      this.onMouseUp = this.onMouseUp.bind(this);
      this.block.domElement.on('mousedown', this.onMouseDown);
    }
  }, {
    key: 'show',
    value: function show() {
      this.domElement.appendTo(this.block.domElement);
    }
  }, {
    key: 'hide',
    value: function hide() {}
  }, {
    key: 'layout',
    value: function layout() {
      this.domElement.css({
        width: this.state.marqueeRect.width,
        height: this.state.marqueeRect.height,
        left: this.state.marqueeRect.x,
        top: this.state.marqueeRect.y,
        backgroundColor: '#ccc',
        position: 'absolute'
      });
    }
  }, {
    key: 'onMouseDown',
    value: function onMouseDown(e) {
      $(document).on('mousemove', this.onMouseMove);
      $(document).on('mouseup', this.onMouseUp);

      var canvasOffset = $('.edit-area-canvas').offset();

      this.state.canvasPosition.x = canvasOffset.left;
      this.state.canvasPosition.y = canvasOffset.top;

      this.state.originalCursorPosition.x = e.clientX;
      this.state.originalCursorPosition.y = e.clientY;
      this.show();
    }
  }, {
    key: 'onMouseMove',
    value: function onMouseMove(e) {
      this.state.marqueeRect.x = this.state.originalCursorPosition.x;
      this.state.marqueeRect.y = this.state.originalCursorPosition.y;
      this.state.marqueeRect.width = e.clientX - this.state.originalCursorPosition.x;
      this.state.marqueeRect.height = e.clientY - this.state.originalCursorPosition.y;

      console.log(this.state.marqueeRect.x);
      this.layout();
    }
  }, {
    key: 'onMouseUp',
    value: function onMouseUp(e) {
      $(document).off('mousemove', this.onMouseMove);
      $(document).off('mouseup', this.onMouseUp);
    }
  }]);

  return Marquee2;
}();

exports.default = Marquee2;

/***/ }),
/* 21 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "index.html";

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

function EventEmitter() {
  this._events = this._events || {};
  this._maxListeners = this._maxListeners || undefined;
}
module.exports = EventEmitter;

// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;

EventEmitter.prototype._events = undefined;
EventEmitter.prototype._maxListeners = undefined;

// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
EventEmitter.defaultMaxListeners = 10;

// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function (n) {
  if (!isNumber(n) || n < 0 || isNaN(n)) throw TypeError('n must be a positive number');
  this._maxListeners = n;
  return this;
};

EventEmitter.prototype.emit = function (type) {
  var er, handler, len, args, i, listeners;

  if (!this._events) this._events = {};

  // If there is no 'error' event listener then throw.
  if (type === 'error') {
    if (!this._events.error || isObject(this._events.error) && !this._events.error.length) {
      er = arguments[1];
      if (er instanceof Error) {
        throw er; // Unhandled 'error' event
      } else {
        // At least give some kind of context to the user
        var err = new Error('Uncaught, unspecified "error" event. (' + er + ')');
        err.context = er;
        throw err;
      }
    }
  }

  handler = this._events[type];

  if (isUndefined(handler)) return false;

  if (isFunction(handler)) {
    switch (arguments.length) {
      // fast cases
      case 1:
        handler.call(this);
        break;
      case 2:
        handler.call(this, arguments[1]);
        break;
      case 3:
        handler.call(this, arguments[1], arguments[2]);
        break;
      // slower
      default:
        args = Array.prototype.slice.call(arguments, 1);
        handler.apply(this, args);
    }
  } else if (isObject(handler)) {
    args = Array.prototype.slice.call(arguments, 1);
    listeners = handler.slice();
    len = listeners.length;
    for (i = 0; i < len; i++) {
      listeners[i].apply(this, args);
    }
  }

  return true;
};

EventEmitter.prototype.addListener = function (type, listener) {
  var m;

  if (!isFunction(listener)) throw TypeError('listener must be a function');

  if (!this._events) this._events = {};

  // To avoid recursion in the case that type === "newListener"! Before
  // adding it to the listeners, first emit "newListener".
  if (this._events.newListener) this.emit('newListener', type, isFunction(listener.listener) ? listener.listener : listener);

  if (!this._events[type])
    // Optimize the case of one listener. Don't need the extra array object.
    this._events[type] = listener;else if (isObject(this._events[type]))
    // If we've already got an array, just append.
    this._events[type].push(listener);else
    // Adding the second element, need to change to array.
    this._events[type] = [this._events[type], listener];

  // Check for listener leak
  if (isObject(this._events[type]) && !this._events[type].warned) {
    if (!isUndefined(this._maxListeners)) {
      m = this._maxListeners;
    } else {
      m = EventEmitter.defaultMaxListeners;
    }

    if (m && m > 0 && this._events[type].length > m) {
      this._events[type].warned = true;
      console.error('(node) warning: possible EventEmitter memory ' + 'leak detected. %d listeners added. ' + 'Use emitter.setMaxListeners() to increase limit.', this._events[type].length);
      if (typeof console.trace === 'function') {
        // not supported in IE 10
        console.trace();
      }
    }
  }

  return this;
};

EventEmitter.prototype.on = EventEmitter.prototype.addListener;

EventEmitter.prototype.once = function (type, listener) {
  if (!isFunction(listener)) throw TypeError('listener must be a function');

  var fired = false;

  function g() {
    this.removeListener(type, g);

    if (!fired) {
      fired = true;
      listener.apply(this, arguments);
    }
  }

  g.listener = listener;
  this.on(type, g);

  return this;
};

// emits a 'removeListener' event iff the listener was removed
EventEmitter.prototype.removeListener = function (type, listener) {
  var list, position, length, i;

  if (!isFunction(listener)) throw TypeError('listener must be a function');

  if (!this._events || !this._events[type]) return this;

  list = this._events[type];
  length = list.length;
  position = -1;

  if (list === listener || isFunction(list.listener) && list.listener === listener) {
    delete this._events[type];
    if (this._events.removeListener) this.emit('removeListener', type, listener);
  } else if (isObject(list)) {
    for (i = length; i-- > 0;) {
      if (list[i] === listener || list[i].listener && list[i].listener === listener) {
        position = i;
        break;
      }
    }

    if (position < 0) return this;

    if (list.length === 1) {
      list.length = 0;
      delete this._events[type];
    } else {
      list.splice(position, 1);
    }

    if (this._events.removeListener) this.emit('removeListener', type, listener);
  }

  return this;
};

EventEmitter.prototype.removeAllListeners = function (type) {
  var key, listeners;

  if (!this._events) return this;

  // not listening for removeListener, no need to emit
  if (!this._events.removeListener) {
    if (arguments.length === 0) this._events = {};else if (this._events[type]) delete this._events[type];
    return this;
  }

  // emit removeListener for all listeners on all events
  if (arguments.length === 0) {
    for (key in this._events) {
      if (key === 'removeListener') continue;
      this.removeAllListeners(key);
    }
    this.removeAllListeners('removeListener');
    this._events = {};
    return this;
  }

  listeners = this._events[type];

  if (isFunction(listeners)) {
    this.removeListener(type, listeners);
  } else if (listeners) {
    // LIFO order
    while (listeners.length) {
      this.removeListener(type, listeners[listeners.length - 1]);
    }
  }
  delete this._events[type];

  return this;
};

EventEmitter.prototype.listeners = function (type) {
  var ret;
  if (!this._events || !this._events[type]) ret = [];else if (isFunction(this._events[type])) ret = [this._events[type]];else ret = this._events[type].slice();
  return ret;
};

EventEmitter.prototype.listenerCount = function (type) {
  if (this._events) {
    var evlistener = this._events[type];

    if (isFunction(evlistener)) return 1;else if (evlistener) return evlistener.length;
  }
  return 0;
};

EventEmitter.listenerCount = function (emitter, type) {
  return emitter.listenerCount(type);
};

function isFunction(arg) {
  return typeof arg === 'function';
}

function isNumber(arg) {
  return typeof arg === 'number';
}

function isObject(arg) {
  return (typeof arg === 'undefined' ? 'undefined' : _typeof(arg)) === 'object' && arg !== null;
}

function isUndefined(arg) {
  return arg === void 0;
}

/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ElementBo2 = __webpack_require__(12);

var _ElementBo3 = _interopRequireDefault(_ElementBo2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var TableEleBo = function (_ElementBo) {
  _inherits(TableEleBo, _ElementBo);

  //新建的表格
  function TableEleBo() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, TableEleBo);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = TableEleBo.__proto__ || Object.getPrototypeOf(TableEleBo)).call.apply(_ref, [this].concat(args))), _this), _this.tableRow = 0, _this.tableCol = 0, _this.tr = [], _this.isNewTable = true, _temp), _possibleConstructorReturn(_this, _ret);
  } //表格组件的行数
  //表格组件的列数
  //表格中的数据


  return TableEleBo;
}(_ElementBo3.default);

exports.default = TableEleBo;

/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _RootStore2 = __webpack_require__(8);

var _RootStore3 = _interopRequireDefault(_RootStore2);

var _EditAreaStore = __webpack_require__(2);

var _EditAreaStore2 = _interopRequireDefault(_EditAreaStore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                * 画布框选类
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                * author 马君保
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                */

var MarqueeStore = function (_RootStore) {
  _inherits(MarqueeStore, _RootStore);

  function MarqueeStore() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, MarqueeStore);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = MarqueeStore.__proto__ || Object.getPrototypeOf(MarqueeStore)).call.apply(_ref, [this].concat(args))), _this), _this.getState = function () {
      return _this._marquee;
    }, _this.updataMarquee = function (marqueeArray) {
      // 绘出选取框
      for (var key in marqueeArray) {
        _this._marquee[key] = marqueeArray[key];
      }

      _this.emit();
      // 选取矩形内的canvas
    }, _this._marquee = {
      x: 0,
      y: 0,
      width: 0,
      height: 0
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  // 私有变量


  return MarqueeStore;
}(_RootStore3.default);

exports.default = new MarqueeStore();

/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _EditAreaPage = __webpack_require__(53);

var _EditAreaPage2 = _interopRequireDefault(_EditAreaPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Center(props) {

  var style = {
    bottom: 0,
    top: props.layout.top,
    right: props.layout.right,
    left: props.layout.left,
    cursor: props.layout.editAreaCursor
  };

  return (0, _preact.h)(
    'div',
    { className: 'cp-view', style: style },
    (0, _preact.h)(_EditAreaPage2.default, props)
  );
}

exports.default = Center;

/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _preact = __webpack_require__(0);

var _NavPage = __webpack_require__(62);

var _NavPage2 = _interopRequireDefault(_NavPage);

var _DragCore = __webpack_require__(5);

var _DragCore2 = _interopRequireDefault(_DragCore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var style = {
  bottom: 0,
  left: 0
};

function Left(props) {
  var onNavPageResize = function onNavPageResize(data) {
    // 导航宽度 150~300
    var navWidth = props.layout.left + data.dx;
    var minWidth = 150,
        maxWidth = 300;
    navWidth < minWidth && (navWidth = minWidth);
    navWidth > maxWidth && (navWidth = maxWidth);
    props.onUpdataLayout({
      left: navWidth
    });
  };

  var onNavPageResizeStart = function onNavPageResizeStart(data) {};

  var onNavPageResizeStop = function onNavPageResizeStop(data) {};

  return (0, _preact.h)(
    'div',
    { className: 'cp-view', style: _extends({}, style, { width: props.layout.left, top: props.layout.top }) },
    (0, _preact.h)(_NavPage2.default, props),
    (0, _preact.h)(
      _DragCore2.default,
      { onDrag: onNavPageResize, onDragStart: onNavPageResizeStart, onDragStop: onNavPageResizeStop },
      (0, _preact.h)('div', { className: 'nav-page-resize' })
    )
  );
}

exports.default = Left;

/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _NavPageService = __webpack_require__(7);

var _NavPageService2 = _interopRequireDefault(_NavPageService);

var _HeaderPageService = __webpack_require__(6);

var _HeaderPageService2 = _interopRequireDefault(_HeaderPageService);

var _TableService = __webpack_require__(17);

var _TableService2 = _interopRequireDefault(_TableService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Outer(props) {
  return (0, _preact.h)(
    'div',
    { onclick: _HeaderPageService2.default.hiddenAllPopUp },
    props.children,
    (0, _preact.h)(
      'div',
      { id: 'menu', 'class': 'rmenu cp-view' },
      (0, _preact.h)(
        'div',
        { 'class': 'menuitems' },
        (0, _preact.h)(
          'a',
          { onclick: _NavPageService2.default.addNavePageByNewMenu },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-add' }),
          '\u65B0\u5EFA\u5E7B\u706F\u7247'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _NavPageService2.default.delNavPageByRightClick },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-delete' }),
          '\u5220\u9664\u5E7B\u706F\u7247'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _NavPageService2.default.pasteNavPage },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-copy' }),
          '\u7C98\u8D34'
        )
      )
    ),
    (0, _preact.h)(
      'div',
      { id: 'navEleRmenu', 'class': 'rmenu cp-view' },
      (0, _preact.h)(
        'div',
        { 'class': 'menuitems' },
        (0, _preact.h)(
          'a',
          { onclick: _NavPageService2.default.addNavePageByNewMenu },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-add' }),
          '\u65B0\u5EFA\u5E7B\u706F\u7247'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _NavPageService2.default.delNavPageByRightClick },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-delete' }),
          '\u5220\u9664\u5E7B\u706F\u7247'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _NavPageService2.default.copyCurrNavPage },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-copy' }),
          '\u62F7\u8D1D'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _NavPageService2.default.cutCurrNavPage },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-copy' }),
          '\u526A\u5207'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _NavPageService2.default.pasteNavPage },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-copy' }),
          '\u7C98\u8D34'
        )
      )
    ),
    (0, _preact.h)(
      'div',
      { id: 'tableRCMenu', 'class': 'rmenu cp-view' },
      (0, _preact.h)(
        'div',
        { 'class': 'menuitems' },
        (0, _preact.h)(
          'a',
          { onclick: _TableService2.default.combineTd },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-add' }),
          '\u5408\u5E76\u5355\u5143\u683C'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _TableService2.default.revertTd },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-delete' }),
          '\u62C6\u5206\u5355\u5143\u683C'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _TableService2.default.insertTrBefore },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-copy' }),
          '\u4E0A\u65B9\u63D2\u5165\u884C'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _TableService2.default.insertTrAfter },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-copy' }),
          '\u4E0B\u65B9\u63D2\u5165\u884C'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _TableService2.default.insertColBefore },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-copy' }),
          '\u5DE6\u4FA7\u63D2\u5165\u5217'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _TableService2.default.insertColAfter },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-copy' }),
          '\u53F3\u4FA7\u63D2\u5165\u5217'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _TableService2.default.deleteChoiceRow },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-copy' }),
          '\u5220\u9664\u884C'
        ),
        (0, _preact.h)(
          'a',
          { onclick: _TableService2.default.deleteChoiceCol },
          (0, _preact.h)('i', { 'class': 'menu-icon ricon-copy' }),
          '\u5220\u9664\u5217'
        )
      )
    )
  );
}

exports.default = Outer;

/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _preact = __webpack_require__(0);

var _AttrPage = __webpack_require__(31);

var _AttrPage2 = _interopRequireDefault(_AttrPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var style = {
  top: '60px',
  right: 0,
  bottom: 0,
  background: '#F6F6F6'
};

function Right(props) {
  return (0, _preact.h)(
    'div',
    { className: 'cp-view', style: _extends({}, style, { top: props.layout.top, width: props.layout.right }) },
    (0, _preact.h)(_AttrPage2.default, props)
  );
}

exports.default = Right;

/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _preact = __webpack_require__(0);

var _HeaderPage = __webpack_require__(55);

var _HeaderPage2 = _interopRequireDefault(_HeaderPage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var style = {
  top: 0,
  right: 0,
  bottom: 0,
  left: 0
};

function Top(props) {
  return (0, _preact.h)(
    'div',
    { className: 'cp-view', style: _extends({}, style, { height: props.layout.top, overflow: 'visible' }) },
    (0, _preact.h)(_HeaderPage2.default, props)
  );
}

exports.default = Top;

/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _AttrPageService = __webpack_require__(32);

var _AttrPageService2 = _interopRequireDefault(_AttrPageService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// let selectedCanvasId = props.getCanvasBySelected();

/**
 * 属性区布局
 * author 马君保，臧文玉
 */

function AttrPage(props) {
  var updata = function updata(canvasObj) {
    props.onUpdataSelectedCanvasByValue(canvasObj);
  };

  /* $function() {
              $(".tab-header ul li").each(function (index) {
                  $(this).click(function () {
                      hiddenall();
                      $(this).addClass("now");
                      $(".tab-content:eq(" + index + ")").css("display", "");
                  });
              });
              function hiddenall() {
                  $(".tab-content").css("display", "none");
                  $(".tab-header ul li").removeClass();
              };
          });*/
  return (0, _preact.h)(
    'div',
    { className: 'attr-page' },
    (0, _preact.h)(
      'div',
      { className: 'attr-tab' },
      (0, _preact.h)(
        'ul',
        { className: 'tab-header border-bottom' },
        (0, _preact.h)(
          'li',
          null,
          (0, _preact.h)(
            'a',
            null,
            '\u6837\u5F0F'
          )
        ),
        (0, _preact.h)(
          'li',
          null,
          (0, _preact.h)(
            'a',
            null,
            '\u6587\u672C'
          )
        ),
        (0, _preact.h)(
          'li',
          { className: 'now' },
          (0, _preact.h)(
            'a',
            null,
            '\u6392\u5217'
          )
        )
      ),
      (0, _preact.h)(
        'div',
        { className: 'tab-content' },
        (0, _preact.h)(
          'div',
          { className: 'attr-shap-style' },
          (0, _preact.h)(
            'div',
            { className: 'attr-shap-main' },
            (0, _preact.h)('a', { className: 'attr-shap-icon attr-shap-icon-left' }),
            (0, _preact.h)(
              'ul',
              { className: 'attr-shap-ul' },
              (0, _preact.h)(
                'li',
                { className: 'shap-blue' },
                '\u6587\u672C'
              ),
              (0, _preact.h)(
                'li',
                { className: 'shap-green' },
                '\u6587\u672C'
              ),
              (0, _preact.h)(
                'li',
                { className: 'shap-yellow' },
                '\u6587\u672C'
              ),
              (0, _preact.h)(
                'li',
                { className: 'shap-red' },
                '\u6587\u672C'
              ),
              (0, _preact.h)(
                'li',
                { className: 'shap-gray' },
                '\u6587\u672C'
              ),
              (0, _preact.h)(
                'li',
                { className: 'shap-border' },
                '\u6587\u672C'
              )
            ),
            (0, _preact.h)('a', { className: 'attr-shap-icon attr-shap-icon-right-on' })
          ),
          (0, _preact.h)(
            'span',
            { className: 'attr-shap-name' },
            '\u5F62\u72B6\u6837\u5F0F'
          ),
          (0, _preact.h)(
            'span',
            { className: 'attr-shap-point' },
            (0, _preact.h)('i', { className: 'attr-shap-icon-point-on' }),
            (0, _preact.h)('i', { className: 'attr-shap-icon-point' })
          )
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-cont' },
          (0, _preact.h)(
            'div',
            { className: 'attr-line' },
            (0, _preact.h)(
              'span',
              { className: 'attr-head-title' },
              (0, _preact.h)('i', { className: 'icon-right' }),
              '\u884C\u4E0E\u5217\u7684\u5927\u5C0F'
            )
          ),
          (0, _preact.h)('div', { className: 'clear' }),
          (0, _preact.h)(
            'div',
            { className: 'attr-line-none', id: 'attr-cell' },
            (0, _preact.h)(
              'div',
              { className: 'attr-sider' },
              (0, _preact.h)(
                'span',
                { className: 'count-icon attr-count-icon' },
                (0, _preact.h)('i', { className: 'icon-add' }),
                (0, _preact.h)('i', { className: 'icon-plus' })
              ),
              (0, _preact.h)(
                'span',
                { className: 'attr-font' },
                '\u9AD8'
              ),
              (0, _preact.h)(
                'span',
                { className: 'attr-select attr-select-smaller-none' },
                (0, _preact.h)('input', { type: 'text', defaultValue: '12.15\u5398\u7C73', className: 'attr-input attr-input-small-none' })
              )
            ),
            (0, _preact.h)(
              'div',
              { className: 'attr-sider' },
              (0, _preact.h)(
                'span',
                { className: 'attr-font' },
                '\u884C'
              ),
              (0, _preact.h)(
                'span',
                { className: 'count-icon attr-count-icon' },
                (0, _preact.h)('i', { className: 'icon-add' }),
                (0, _preact.h)('i', { className: 'icon-plus' })
              ),
              (0, _preact.h)(
                'span',
                { className: 'attr-select attr-select-smaller-none' },
                (0, _preact.h)('input', { type: 'text', defaultValue: '12.15\u5398\u7C73', className: 'attr-input attr-input-small-none' })
              )
            )
          ),
          (0, _preact.h)('div', { className: 'clear' }),
          (0, _preact.h)(
            'div',
            { className: 'attr-line' },
            (0, _preact.h)('div', { className: 'attr-line-boeder' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line-none', id: 'attr-button-cell' },
            (0, _preact.h)(
              'span',
              { className: 'attr-select' },
              (0, _preact.h)(
                'em',
                { className: 'attr-button-text' },
                '\u5408\u5E76\u5355\u5143\u683C'
              )
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-select attr-mleft' },
              (0, _preact.h)(
                'em',
                { className: 'attr-button-text' },
                '\u62C6\u5206\u5355\u5143\u683C'
              )
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line' },
            (0, _preact.h)('div', { className: 'attr-line-boeder' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line clear', id: 'attr-color-fill' },
            (0, _preact.h)(
              'span',
              { className: 'attr-head-title', id: 'attr-fill-color' },
              (0, _preact.h)('i', { className: 'attr-title-icon' }),
              '\u586B\u5145'
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-right-info' },
              (0, _preact.h)(
                'span',
                { className: 'attr-text-radius' },
                (0, _preact.h)('span', { className: 'attr-text-bias' })
              )
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line' },
            (0, _preact.h)(
              'span',
              { className: 'attr-head-title' },
              '\u5E38\u7528\u989C\u8272'
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line', id: 'attr-color-list' },
            (0, _preact.h)(
              'div',
              { className: 'attr-fill-color' },
              (0, _preact.h)(
                'i',
                { className: 'attr-fill-color-icon' },
                (0, _preact.h)('em', { className: 'attr-fill-color-bias' })
              ),
              (0, _preact.h)('i', { className: 'attr-fill-color-icon attr-fill-color-white' }),
              (0, _preact.h)('i', { className: 'attr-fill-color-icon attr-fill-color-red' }),
              (0, _preact.h)('i', { className: 'attr-fill-color-icon attr-fill-color-orangered' }),
              (0, _preact.h)('i', { className: 'attr-fill-color-icon attr-fill-color-croci' }),
              (0, _preact.h)('i', { className: 'attr-fill-color-icon attr-fill-color-yellow' }),
              (0, _preact.h)('i', { className: 'attr-fill-color-icon attr-fill-color-lightgreen' }),
              (0, _preact.h)('i', { className: 'attr-fill-color-icon attr-fill-color-green' }),
              (0, _preact.h)('i', { className: 'attr-fill-color-icon attr-fill-color-lightblue' }),
              (0, _preact.h)('i', { className: 'attr-fill-color-icon attr-fill-color-blue' }),
              (0, _preact.h)('i', { className: 'attr-fill-color-icon attr-fill-color-darkblue' })
            )
          ),
          (0, _preact.h)('div', { className: 'attr-line-boeder' }),
          (0, _preact.h)(
            'div',
            { className: 'attr-line', id: 'attr-boder' },
            (0, _preact.h)(
              'span',
              { className: 'attr-head-title' },
              (0, _preact.h)('i', { className: 'attr-title-icon' }),
              '\u8FB9\u6846'
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-right-info' },
              (0, _preact.h)(
                'span',
                { className: 'attr-text-radius' },
                (0, _preact.h)('em', { className: 'attr-text-line' })
              )
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line-none', id: 'attr-line-border' },
            (0, _preact.h)(
              'div',
              { className: 'attr-select attr-select-large' },
              (0, _preact.h)('input', { type: 'text', defaultValue: '\u7EBF\u6761', className: 'attr-input attr-input-large' }),
              (0, _preact.h)('i', { className: 'attr-select-icon-blue' })
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line-none' },
            (0, _preact.h)(
              'span',
              { className: 'attr-select attr-select-small', id: 'attr-line-shap' },
              (0, _preact.h)('input', { type: 'text', defaultValue: '---------', className: 'attr-input attr-input-smaller attr-input-shap' }),
              (0, _preact.h)('i', { className: 'attr-select-icon-gray' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-select attr-select-small', id: 'attr-color' },
              (0, _preact.h)('input', { type: 'text', defaultValue: '', className: 'attr-input attr-select-color' }),
              (0, _preact.h)('i', { className: 'attr-icon-color' })
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line' },
            (0, _preact.h)('div', { className: 'attr-line-boeder' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line', id: 'attr-opaqueness' },
            (0, _preact.h)(
              'span',
              { className: 'attr-head-title' },
              (0, _preact.h)('i', { className: 'attr-title-icon-right' }),
              '\u4E0D\u900F\u660E\u5EA6'
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line' },
            (0, _preact.h)(
              'span',
              { className: 'attr-opaqueness' },
              (0, _preact.h)(
                'em',
                { className: 'attr-opaqueness-blue' },
                (0, _preact.h)('i', { className: 'attr-opaqueness-icon' })
              )
            ),
            (0, _preact.h)(
              'span',
              { className: 'count-icon attr-count-icon' },
              (0, _preact.h)('i', { className: 'icon-add' }),
              (0, _preact.h)('i', { className: 'icon-plus' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-select attr-select-smaller attr-opaqueness-num' },
              (0, _preact.h)('input', { type: 'text', defaultValue: '70%', className: 'attr-input attr-input-smaller' })
            )
          ),
          (0, _preact.h)('div', { className: 'clear' }),
          (0, _preact.h)(
            'div',
            { className: 'attr-line' },
            (0, _preact.h)('div', { className: 'attr-line-boeder' })
          )
        )
      ),
      (0, _preact.h)('div', { className: 'clear' }),
      (0, _preact.h)(
        'div',
        { className: 'tab-content' },
        (0, _preact.h)(
          'div',
          { className: 'line-cont' },
          (0, _preact.h)(
            'div',
            { className: 'line-title' },
            '\u5927\u6807\u9898',
            (0, _preact.h)('i', { className: 'icon icon-down' })
          )
        ),
        (0, _preact.h)('div', { className: 'clear' }),
        (0, _preact.h)(
          'div',
          { className: 'attr-cont' },
          (0, _preact.h)(
            'ul',
            { className: 'attr-tab-main border' },
            (0, _preact.h)(
              'li',
              { className: 'on border-right' },
              '\u6837\u5F0F'
            ),
            (0, _preact.h)(
              'li',
              null,
              '\u5E03\u5C40'
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'line-tips' },
            '\u5B57\u4F53'
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-select attr-select-large', id: 'attr-font' },
            (0, _preact.h)('input', { type: 'text', defaultValue: 'Helvetica', className: 'attr-input attr-input-large' }),
            (0, _preact.h)('i', { className: 'attr-select-icon-blue' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line-none', id: 'attr-font-style' },
            (0, _preact.h)(
              'div',
              { className: 'attr-select attr-select-medium' },
              (0, _preact.h)('input', { type: 'text', defaultValue: '\u7EC6\u4F53', className: 'attr-input attr-input-medium' }),
              (0, _preact.h)('i', { className: 'attr-select-icon-blue' })
            ),
            (0, _preact.h)(
              'div',
              { className: 'attr-location' },
              (0, _preact.h)(
                'span',
                { className: 'count-icon attr-count-icon' },
                (0, _preact.h)('i', { className: 'icon-add' }),
                (0, _preact.h)('i', { className: 'icon-plus' })
              ),
              (0, _preact.h)(
                'span',
                { className: 'attr-select attr-select-smaller-none' },
                (0, _preact.h)('input', { type: 'text', defaultValue: '80\u78C5', className: 'attr-input attr-input-small-none' })
              )
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'line-font-style' },
            (0, _preact.h)(
              'span',
              { className: 'font-style' },
              (0, _preact.h)('em', { id: 'font_style_b', className: 'b', onClick: _AttrPageService2.default.selectFontStyle }),
              (0, _preact.h)('em', { id: 'font_style_i', className: 'i on' }),
              (0, _preact.h)('em', { id: 'font_style_u', className: 'u' }),
              (0, _preact.h)('em', { className: 'k' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'select-color' },
              (0, _preact.h)('i', { className: 'icon-color', onClick: _AttrPageService2.default.changeEleColor })
            ),
            (0, _preact.h)('div', { className: 'clear' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line' },
            (0, _preact.h)('div', { className: 'attr-line-boeder' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'line-tips' },
            '\u5BF9\u9F50'
          ),
          (0, _preact.h)(
            'div',
            { className: 'tab-main-text' },
            (0, _preact.h)('em', { className: 'tl on' }),
            (0, _preact.h)('em', { className: 'tc' }),
            (0, _preact.h)('em', { className: 'tr' }),
            (0, _preact.h)('em', { className: 'ta' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'tab-main-style' },
            (0, _preact.h)('em', { className: 'tl on' }),
            (0, _preact.h)('em', { className: 'tr' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'tab-main-font' },
            (0, _preact.h)('em', { className: 'tl' }),
            (0, _preact.h)('em', { className: 'tc on' }),
            (0, _preact.h)('em', { className: 'tr' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line' },
            (0, _preact.h)('div', { className: 'attr-line-boeder' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'line-tips' },
            (0, _preact.h)('i', { className: 'icon-right' }),
            '\u95F4\u8DDD'
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-select attr-select-large', id: 'attr-font-space' },
            (0, _preact.h)('input', { type: 'text', defaultValue: '1.0--\u500D\u6570', className: 'attr-input attr-input-large' }),
            (0, _preact.h)('i', { className: 'attr-select-icon-blue' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line-none', id: 'atrr-space' },
            (0, _preact.h)(
              'div',
              { className: 'attr-select attr-select-medium' },
              (0, _preact.h)('input', { type: 'text', defaultValue: '\u884C\u8DDD', className: 'attr-input attr-input-medium' }),
              (0, _preact.h)('i', { className: 'attr-select-icon-blue' })
            ),
            (0, _preact.h)(
              'div',
              { className: 'attr-location' },
              (0, _preact.h)(
                'span',
                { className: 'count-icon attr-count-icon' },
                (0, _preact.h)('i', { className: 'icon-add' }),
                (0, _preact.h)('i', { className: 'icon-plus' })
              ),
              (0, _preact.h)(
                'span',
                { className: 'attr-select attr-select-smaller-none' },
                (0, _preact.h)('input', { type: 'text', defaultValue: 1, className: 'attr-input attr-input-small-none' })
              )
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line-none' },
            (0, _preact.h)(
              'div',
              { className: 'left-info' },
              '\u6BB5\u524D'
            ),
            (0, _preact.h)(
              'div',
              { className: 'attr-location' },
              (0, _preact.h)(
                'span',
                { className: 'count-icon attr-count-icon' },
                (0, _preact.h)('i', { className: 'icon-add' }),
                (0, _preact.h)('i', { className: 'icon-plus' })
              ),
              (0, _preact.h)(
                'span',
                { className: 'attr-select attr-select-smaller-none' },
                (0, _preact.h)('input', { type: 'text', defaultValue: 1, className: 'attr-input attr-input-small-none' })
              )
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-line-none' },
            (0, _preact.h)(
              'div',
              { className: 'left-info' },
              '\u6BB5\u540E'
            ),
            (0, _preact.h)(
              'div',
              { className: 'attr-location' },
              (0, _preact.h)(
                'span',
                { className: 'count-icon attr-count-icon' },
                (0, _preact.h)('i', { className: 'icon-add' }),
                (0, _preact.h)('i', { className: 'icon-plus' })
              ),
              (0, _preact.h)(
                'span',
                { className: 'attr-select attr-select-smaller-none' },
                (0, _preact.h)('input', { type: 'text', defaultValue: 1, className: 'attr-input attr-input-small-none' })
              )
            )
          ),
          (0, _preact.h)('div', { className: 'clear' }),
          (0, _preact.h)(
            'div',
            { className: 'attr-line-none' },
            (0, _preact.h)('div', { className: 'attr-line-boeder' })
          ),
          (0, _preact.h)('div', { className: 'clear' }),
          (0, _preact.h)(
            'div',
            { className: 'attr-line-none' },
            (0, _preact.h)(
              'div',
              { className: 'left-info' },
              (0, _preact.h)('i', { className: 'icon-right' }),
              '\u9879\u76EE\u7B26\u53F7'
            ),
            (0, _preact.h)(
              'div',
              { className: 'attr-select attr-select-large', id: 'attr-letter' },
              (0, _preact.h)('input', { type: 'text', defaultValue: '\u5B57\u6BCD', className: 'attr-input attr-input-large' }),
              (0, _preact.h)('i', { className: 'attr-select-icon-blue' })
            )
          ),
          (0, _preact.h)('div', { className: 'clear' }),
          (0, _preact.h)(
            'div',
            { className: 'attr-line' },
            (0, _preact.h)('div', { className: 'attr-line-boeder' })
          ),
          (0, _preact.h)('div', { className: 'clear' })
        ),
        (0, _preact.h)('div', { className: 'clear' })
      )
    ),
    (0, _preact.h)(
      'div',
      { className: 'tab-content now' },
      (0, _preact.h)(
        'div',
        { className: 'attr-cont' },
        (0, _preact.h)(
          'div',
          { className: 'attr-line' },
          (0, _preact.h)(
            'span',
            { className: 'attr-head-title' },
            (0, _preact.h)('i', { className: 'attr-title-icon' }),
            '\u6587\u672C\u7ED5\u6392'
          )
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-line-none' },
          (0, _preact.h)(
            'div',
            { className: 'attr-select attr-select-large', id: 'attr-surround' },
            (0, _preact.h)(
              'em',
              { className: 'attr-input attr-input-large' },
              (0, _preact.h)('i', { className: 'attr-public-icon attr-surround-icon' }),
              '\u73AF\u7ED5'
            ),
            (0, _preact.h)('i', { className: 'attr-select-icon-blue' })
          )
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-line' },
          (0, _preact.h)('div', { className: 'attr-line-boeder' })
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-line-none', id: 'attr-arrange' },
          (0, _preact.h)(
            'div',
            { className: 'attr-arrange-border' },
            (0, _preact.h)(
              'span',
              { className: 'attr-arrange-button attr-border-right' },
              (0, _preact.h)(
                'i',
                { className: 'attr-arrange-icon attr-arrange-icon-end' },
                ' '
              )
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-arrange-button' },
              (0, _preact.h)(
                'i',
                { className: 'attr-arrange-icon attr-arrange-icon-first' },
                ' '
              )
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-arrange-border attr-mleft' },
            (0, _preact.h)(
              'span',
              { className: 'attr-arrange-button attr-border-right' },
              (0, _preact.h)(
                'i',
                { className: 'attr-arrange-icon attr-arrange-icon-backwards' },
                ' '
              )
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-arrange-button' },
              (0, _preact.h)(
                'i',
                { className: 'attr-arrange-icon attr-arrange-icon-forward' },
                ' '
              )
            )
          )
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-line-none', id: 'attr-arrange-text' },
          (0, _preact.h)(
            'span',
            { className: 'attr-arrange-text' },
            '\u6700\u540E'
          ),
          (0, _preact.h)(
            'span',
            { className: 'attr-arrange-text' },
            '\u6700\u524D'
          ),
          (0, _preact.h)(
            'span',
            { className: 'attr-arrange-text attr-mleft' },
            '\u5411\u540E'
          ),
          (0, _preact.h)(
            'span',
            { className: 'attr-arrange-text' },
            '\u5411\u524D'
          )
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-line' },
          (0, _preact.h)('div', { className: 'attr-line-boeder' })
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-line-none' },
          (0, _preact.h)(
            'span',
            { className: 'attr-select', id: 'attr-align' },
            (0, _preact.h)('input', { type: 'text', defaultValue: '\u5BF9\u9F50', className: 'attr-input attr-input-middle' }),
            (0, _preact.h)('i', { className: 'attr-select-icon-blue' })
          ),
          (0, _preact.h)(
            'span',
            { className: 'attr-select attr-mleft', id: 'attr-distribution' },
            (0, _preact.h)('input', { type: 'text', defaultValue: '\u5206\u5E03', className: 'attr-input attr-input-middle' }),
            (0, _preact.h)('i', { className: 'attr-select-icon-gray' })
          )
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-line' },
          (0, _preact.h)('div', { className: 'attr-line-boeder' })
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-line-none', id: 'attr-location' },
          (0, _preact.h)(
            'span',
            { className: 'attr-location-title' },
            '\u4F4D\u7F6E'
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-location' },
            (0, _preact.h)(
              'span',
              { className: 'count-icon attr-count-icon' },
              (0, _preact.h)('i', { className: 'icon-add' }),
              (0, _preact.h)('i', { className: 'icon-plus' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-select attr-select-smaller-none' },
              (0, _preact.h)('input', { type: 'text', defaultValue: '12.15\u5398\u7C73', className: 'attr-input attr-input-small-none' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-location-x' },
              'y'
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-location' },
            (0, _preact.h)(
              'span',
              { className: 'count-icon attr-count-icon' },
              (0, _preact.h)('i', { className: 'icon-add' }),
              (0, _preact.h)('i', { className: 'icon-plus' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-select attr-select-smaller-none' },
              (0, _preact.h)('input', { type: 'text', defaultValue: '12.15\u5398\u7C73', className: 'attr-input attr-input-small-none' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-location-x' },
              'x'
            )
          )
        ),
        (0, _preact.h)('div', { className: 'clear' }),
        (0, _preact.h)(
          'div',
          { className: 'attr-line' },
          (0, _preact.h)('div', { className: 'attr-line-boeder' })
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-line-none', id: 'attr-roate' },
          (0, _preact.h)(
            'span',
            { className: 'attr-location-title' },
            '\u65CB\u8F6C'
          ),
          (0, _preact.h)(
            'em',
            { className: 'attr-public-icon attr-roate-icon' },
            (0, _preact.h)('i', { className: 'attr-roate-icon-point' })
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-location' },
            (0, _preact.h)(
              'span',
              { className: 'attr-select attr-select-smallerr' },
              (0, _preact.h)('i', { className: 'attr-public-icon attr-roate-icon-right' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-select attr-select-smallerr' },
              (0, _preact.h)('i', { className: 'attr-public-icon attr-roate-icon-up' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-location-x attr-mleft' },
              '\u65CB\u8F6C'
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'attr-location' },
            (0, _preact.h)(
              'span',
              { className: 'count-icon attr-count-icon' },
              (0, _preact.h)('i', { className: 'icon-add' }),
              (0, _preact.h)('i', { className: 'icon-plus' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-select attr-select-smaller-none' },
              (0, _preact.h)('input', { type: 'text', defaultValue: '355.1\u5EA6', className: 'attr-input attr-input-small-none' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'attr-location-x' },
              '\u89D2\u5EA6'
            )
          )
        ),
        (0, _preact.h)('div', { className: 'clear' }),
        (0, _preact.h)(
          'div',
          { className: 'attr-line' },
          (0, _preact.h)('div', { className: 'attr-line-boeder' })
        ),
        (0, _preact.h)(
          'div',
          { className: 'attr-line' },
          (0, _preact.h)(
            'span',
            { className: 'attr-select' },
            (0, _preact.h)(
              'em',
              { className: 'attr-button-text' },
              '\u6210\u7EC4'
            )
          ),
          (0, _preact.h)(
            'span',
            { className: 'attr-select attr-mleft' },
            (0, _preact.h)(
              'em',
              { className: 'attr-button-text' },
              '\u53D6\u6D88\u6210\u7EC4'
            )
          )
        ),
        (0, _preact.h)('div', { className: 'clear' }),
        (0, _preact.h)(
          'div',
          { className: 'attr-line' },
          (0, _preact.h)('div', { className: 'attr-line-boeder' })
        )
      )
    )
  );
}

exports.default = AttrPage;

/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _EditAreaStore = __webpack_require__(2);

var _EditAreaStore2 = _interopRequireDefault(_EditAreaStore);

var _EditAreaPageService = __webpack_require__(11);

var _EditAreaPageService2 = _interopRequireDefault(_EditAreaPageService);

var _CpConst = __webpack_require__(9);

var _CpConst2 = _interopRequireDefault(_CpConst);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 按钮元素对应的样式操作
var id_styleArr = _CpConst2.default.id_styleArr;

function getStyleValue(styleKey, currSelEleData) {
  var val = getStyleValueByFirst(styleKey, currSelEleData);
  return val;
}

// 关于点击，样式添加或取消的类别
function getStyleValueByFirst(styleKey, currSelEleData) {
  var val = null;
  if (styleKey == 'fontWeight') {
    var tempVal = currSelEleData.fontWeight;
    if (tempVal == 'normal') {
      tempVal = 'bold';
    } else {
      tempVal = 'normal';
    }
    val = tempVal;
  }
  return val;
}

function getEvetTarget(event) {
  return event.srcElement ? event.srcElement : event.target;
}

function getStyleKey(id) {
  for (var i in id_styleArr) {
    var obj = id_styleArr[i];
    if (obj.id == id) {
      return obj.styleKey;
    }
  }
}
/**
 * 属性区业务
 * author 马君保
 */
var AttrPageService = {

  selectFontStyle: function selectFontStyle(event) {
    var currEle = getEvetTarget(event);
    var id = currEle.id; //获取当期按钮的id编码
    var styleKey = getStyleKey(id);

    //后面会选择多个
    var currSelEleDataArr = _EditAreaStore2.default.getCanvasBySelected();
    for (var i in currSelEleDataArr) {
      var currSelEleData = currSelEleDataArr[i];
      console.log(currSelEleData);
      var styleVal = getStyleValue(styleKey, currSelEleData);
      currSelEleData[styleKey] = styleVal;
      // EditAreaStore.updataCanvasById(currSelEleData.id, currSelEleData);
      console.log(currSelEleData.id + "改变样式：" + currSelEleData[styleKey]);

      // 触发文本框大小调整
      if (currSelEleData.type == 'txt') {
        _EditAreaPageService2.default.setTxtStyleBychangePrp(currSelEleData.id);
      }
    }
  },
  //测试改变线条的粗细和颜色
  changeEleColor: function changeEleColor(e) {
    var currentEle = _EditAreaStore2.default.getCanvasBySelected();
    if (currentEle.length != 0) {
      for (var i = 0; i < currentEle.length; i++) {
        var type = currentEle[i].type;
        if (type.indexOf("ine") > 0) {
          currentEle[i].fill = '#000000';
          currentEle[i].strokeWidth = 5;
        }
      }
      _EditAreaStore2.default.updataSelectedCanvasByDiff(currentEle);
    } else {}
  }
};

exports.default = AttrPageService;

/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.addEvent = addEvent;
exports.removeEvent = removeEvent;
exports.prefixCssProp = prefixCssProp;
exports.prefixCssVal = prefixCssVal;
exports.addClass = addClass;
function addEvent(el, event, handler) {
  if (!el) {
    return;
  };
  el.addEventListener(event, handler, false);
}

function removeEvent(el, event, handler) {
  if (!el) {
    return;
  };
  el.removeEventListener(event, handler, false);
}

function prefixCssProp(prop) {
  var prefixes = ['moz', 'webkit', 'o', 'ms'];
  var styles = document.createElement('div').style;
  if (prop in styles) return prop;
  for (var i = 0; i < prefixes.length; i++) {
    var nowProp = prefixes[i] + prop.charAt(0).toUpperCase() + prop.slice(1);
    if (nowProp in styles) {
      return nowProp;
    }
  }
}

function prefixCssVal() {
  var prefixes = ['Moz', 'Webkit', 'O', 'ms'];
}

function addClass(oldClass, newClass) {
  if (oldClass || newClass) return;
  var resultClass = void 0;
  // 去空格
  oldClass = oldClass.replace(/(^\s+)|(\s+$)/g, '');
  newClass = newClass.replace(/(^\s+)|(\s+$)/g, '');

  // 去除newClass
  resultClass = oldClass.replace(new RegExp('^\\s?' + newClass + '\\s?$'), '');
  // 添加newClass
  resultClass = resultClass + ' ' + newClass;
  // 去空格
  resultClass = resultClass.replace(/(^\s+)|(\s+$)/g, '');

  return resultClass;
}

/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; /**
                                                                                                                                                                                                                                                                   * 调整大小类
                                                                                                                                                                                                                                                                   *
                                                                                                                                                                                                                                                                   * @module  ResizeCore
                                                                                                                                                                                                                                                                   * 
                                                                                                                                                                                                                                                                   * @author Ma Junbao <mlive@live.cn>
                                                                                                                                                                                                                                                                   */

var _preact = __webpack_require__(0);

var _DragCore = __webpack_require__(5);

var _DragCore2 = _interopRequireDefault(_DragCore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function ResizeCore(props) {
  var RESIZE_POINTS = "topLeft topCenter topRight centerLeft centerRight bottomLeft bottomCenter bottomRight";

  // 八个点样式
  var style = {
    left: -1,
    top: -1,
    width: parseInt(props.width) + 'px',
    height: parseInt(props.height) + 'px',
    position: 'absolute',
    border: props.hideResizeStroke == 'true' ? '' : '1px solid #95B6FF'
  };

  // 配置八个点
  var resizePoints = props.resizePoints || RESIZE_POINTS;

  var resizeHandleStyle = {
    width: 5 + 'px',
    height: 5 + 'px',
    border: 1 + 'px solid #0079FF',
    backgroundColor: '#FEFEFF',
    position: 'absolute',
    zIndex: 1
  };

  var resizeHandleStyleAbsolute = -3 + 'px';

  var returnDataback = {
    width: parseInt(props.width),
    height: parseInt(props.height),
    x: props.x,
    y: props.y
  };

  var returnData = function returnData(data) {
    return data;
  };

  var onResizeStart = function onResizeStart(data) {};

  var onResize = function onResize(data) {
    typeof props.onResize == 'function' && props.onResize(data);
  };

  var onTopLeft = function onTopLeft(data) {
    handleTop(data);
    handleLeft(data);
    handleResize(data);
  };

  var onTopCenter = function onTopCenter(data) {
    handleTop(data);
    handleResize(data);
  };

  var onTopRight = function onTopRight(data) {
    handleTop(data);
    handleRight(data);
    handleResize(data);
  };

  var onCenterRight = function onCenterRight(data) {
    handleRight(data);
    handleResize(data);
  };

  var onCenterLeft = function onCenterLeft(data) {
    handleLeft(data);
    handleResize(data);
  };

  var onBottomLeft = function onBottomLeft(data) {
    handleBottom(data);
    handleLeft(data);
    handleResize(data);
  };

  var onBottomCenter = function onBottomCenter(data) {
    handleBottom(data);
    handleResize(data);
  };

  var onBottomRight = function onBottomRight(data) {
    handleBottom(data);
    handleRight(data);
    handleResize(data);
  };

  var onMove = function onMove(data) {
    handleMove(data);
    typeof props.onMove == 'function' && props.onMove(data);
  };

  var onMouseDown = function onMouseDown() {
    typeof props.onMouseDown == 'function' && props.onMouseDown(props.id);
  };

  // Top Right Bottom Left Move handle
  var handleTop = function handleTop(data) {
    data.top = true;
  };
  var handleRight = function handleRight(data) {
    data.right = true;
  };
  var handleBottom = function handleBottom(data) {
    data.bottom = true;
  };
  var handleLeft = function handleLeft(data) {
    data.left = true;
  };

  var handleMove = function handleMove(data) {};

  var handleResize = function handleResize(data) {
    typeof props.onResize == 'function' && props.onResize(returnData(data));
  };

  var handleResizeStop = function handleResizeStop(data) {
    typeof props.onResizeStop == 'function' && props.onResizeStop(returnData(data));
  };

  var handleResizeStart = function handleResizeStart(data) {
    typeof props.onResizeStart == 'function' && props.onResizeStart(returnData(data));
  };

  var handleUpdataLayoutCursor = function handleUpdataLayoutCursor() {
    var cursor = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'default';

    props.onUpdataLayout({ editAreaCursor: cursor });
  };

  var _hasPoint = function _hasPoint(point) {
    if (resizePoints == RESIZE_POINTS) {
      return true;
    };

    if (resizePoints.indexOf(point) > -1) {
      return true;
    };

    return false;
  };

  return props.isSelected ? (0, _preact.h)(
    'div',
    { style: style, onMouseDown: function onMouseDown(e) {
        e.stopPropagation();
      } },
    _hasPoint('topLeft') ? (0, _preact.h)(
      _DragCore2.default,
      { onDrag: onTopLeft, onDragStop: handleResizeStop, onDragStart: handleResizeStart },
      (0, _preact.h)('div', { style: _extends({}, resizeHandleStyle, { cursor: 'nwse-resize', top: resizeHandleStyleAbsolute, left: resizeHandleStyleAbsolute }) })
    ) : null,
    _hasPoint('topCenter') ? (0, _preact.h)(
      _DragCore2.default,
      { onDrag: onTopCenter, onDragStop: handleResizeStop, onDragStart: handleResizeStart },
      (0, _preact.h)('div', { style: _extends({}, resizeHandleStyle, { cursor: 'ns-resize', top: resizeHandleStyleAbsolute, left: '50%', marginLeft: resizeHandleStyleAbsolute }) })
    ) : null,
    _hasPoint('topRight') ? (0, _preact.h)(
      _DragCore2.default,
      { onDrag: onTopRight, onDragStop: handleResizeStop, onDragStart: handleResizeStart },
      (0, _preact.h)('div', { style: _extends({}, resizeHandleStyle, { cursor: 'nesw-resize', top: resizeHandleStyleAbsolute, right: resizeHandleStyleAbsolute }) })
    ) : null,
    _hasPoint('centerLeft') ? (0, _preact.h)(
      _DragCore2.default,
      { onDrag: onCenterLeft, onDragStop: handleResizeStop, onDragStart: handleResizeStart },
      (0, _preact.h)('div', { style: _extends({}, resizeHandleStyle, { cursor: 'ew-resize', top: '50%', marginTop: resizeHandleStyleAbsolute, left: resizeHandleStyleAbsolute }) })
    ) : null,
    _hasPoint('centerRight') ? (0, _preact.h)(
      _DragCore2.default,
      { onDrag: onCenterRight, onDragStop: handleResizeStop, onDragStart: handleResizeStart },
      (0, _preact.h)('div', { style: _extends({}, resizeHandleStyle, { cursor: 'ew-resize', top: '50%', marginTop: resizeHandleStyleAbsolute, right: resizeHandleStyleAbsolute }) })
    ) : null,
    _hasPoint('bottomLeft') ? (0, _preact.h)(
      _DragCore2.default,
      { onDrag: onBottomLeft, onDragStop: handleResizeStop, onDragStart: handleResizeStart },
      (0, _preact.h)('div', { style: _extends({}, resizeHandleStyle, { cursor: 'nesw-resize', bottom: resizeHandleStyleAbsolute, left: resizeHandleStyleAbsolute }) })
    ) : null,
    _hasPoint('bottomCenter') ? (0, _preact.h)(
      _DragCore2.default,
      { onDrag: onBottomCenter, onDragStop: handleResizeStop, onDragStart: handleResizeStart },
      (0, _preact.h)('div', { style: _extends({}, resizeHandleStyle, { cursor: 'ns-resize', bottom: resizeHandleStyleAbsolute, left: '50%', marginLeft: resizeHandleStyleAbsolute }) })
    ) : null,
    _hasPoint('bottomRight') ? (0, _preact.h)(
      _DragCore2.default,
      { onDrag: onBottomRight, onDragStop: handleResizeStop, onDragStart: handleResizeStart },
      (0, _preact.h)('div', { style: _extends({}, resizeHandleStyle, { cursor: 'nwse-resize', bottom: resizeHandleStyleAbsolute, right: resizeHandleStyleAbsolute }) })
    ) : null
  ) : null;
}
exports.default = ResizeCore;

/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (props) {
  var style = {
    width: '10px',
    height: '10px',
    backgroundColor: 'red',
    position: 'absolute',
    top: '-20px',
    left: '50%',
    marginLeft: '-5px'
  };

  var onRotateStart = function onRotateStart(data) {
    typeof props.onRotateStart == 'function' && props.onRotateStart(data);
  };
  var onRotate = function onRotate(data) {
    typeof props.onRotate == 'function' && props.onRotate(data);
  };
  var onRotateEnd = function onRotateEnd(data) {
    typeof props.onRotateEnd == 'function' && props.onRotateEnd(data);
  };

  return (0, _preact.h)(
    _DragCore2.default,
    { onDragStart: onRotateStart, onDrag: onRotate, onDragEnd: onRotateEnd },
    (0, _preact.h)('div', { style: style })
  );
};

var _preact = __webpack_require__(0);

var _DragCore = __webpack_require__(5);

var _DragCore2 = _interopRequireDefault(_DragCore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Circle(props) {
  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: props.width, height: props.height, style: { position: 'absolute' } },
      (0, _preact.h)('ellipse', { cx: props.width / 2, cy: props.height / 2, rx: props.width / 2, ry: props.height / 2, fill: props.fill })
    )
  );
}

exports.default = Circle;

/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
* 线条组件
* @author 邬宗俊 
*/
function Line(props) {
	var rightArrow = function rightArrow() {
		var td = [];
		for (var i = 0; i < props.row; i++) {
			td.push((0, _preact.h)(
				'td',
				{ style: tdStyle, onclick: EditAreaPageService.tableTdClick },
				(0, _preact.h)('input', { style: inputStyle, className: 'hidden', onblur: EditAreaPageService.inputBlur }),
				(0, _preact.h)('span', { style: span })
			));
		};
		return td;
	};

	var leftArrow = function leftArrow() {
		(0, _preact.h)(
			'defs',
			null,
			(0, _preact.h)(
				'marker',
				{ id: 'arrowLeft',
					markerUnits: 'strokeWidth',
					viewBox: '0 0 12 12',
					refX: '4',
					refY: '6',
					orient: 'auto' },
				(0, _preact.h)('path', { d: 'M 10 2 L 2 6 L 10 10 L 6 6 L 10 2', style: { fill: props.fill } })
			)
		);
	};
	var line = function line() {
		var x2 = props.width;
		if (props.strokeWidth >= 5) {
			x2 = x2 - props.strokeWidth * (props.strokeWidth - 3);
		} else if (props.strokeWidth >= 3) {
			x2 = x2 - props.strokeWidth * (props.strokeWidth - 1);
		}
		if (props.type == 'line') {
			return (0, _preact.h)('line', { x1: '0', y1: props.height / 2, x2: props.width, y2: props.height / 2, stroke: props.fill, 'stroke-width': props.strokeWidth });
		} else if (props.type == 'arrowLine') {
			return (0, _preact.h)('line', { x1: '0', y1: props.height / 2, x2: x2 - 8, y2: props.height / 2, stroke: props.fill, 'stroke-width': props.strokeWidth, 'marker-end': 'url(#arrowRight)' });
		} else {
			return (0, _preact.h)('line', { x1: '6', y1: props.height / 2, x2: x2 - 8, y2: props.height / 2, stroke: props.fill, 'stroke-width': props.strokeWidth, 'marker-end': 'url(#arrowRight)', 'marker-start': 'url(#arrowLeft)' });
		}
	};
	var svg = function svg() {
		return (0, _preact.h)(
			'svg',
			{ width: props.width, height: props.height, style: { position: 'absolute' } },
			rightArrow(),
			leftArrow(),
			line()
		);
	};
	return (0, _preact.h)(
		_Transform2.default,
		props,
		svg()
	);
}

exports.default = Line;

/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Pentagon(props) {
  var oxw = props.width; //x轴坐标
  var oyh = props.height; //y轴坐标
  var radians = 36 * Math.PI / 180;
  var ow = oxw / (2 * Math.cos(radians)); //边长
  var oya = Math.sin(radians) * oxw / (2 * Math.cos(radians)); //根据正弦和余弦推出y轴坐标
  var oxa = (oxw - ow) / 2; // x轴值
  var oxb = oxa + ow; // x轴值
  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: props.width, height: props.height, style: { position: 'absolute' } },
      (0, _preact.h)('polygon', { points: oxw / 2 + ',0 ' + oxw + ',' + oya + ' ' + oxb + ',' + oyh + ' ' + oxa + ',' + oyh + ' 0,' + oya, fill: props.fill })
    )
  );
}

exports.default = Pentagon;

/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

var _TxtBase = __webpack_require__(18);

var _TxtBase2 = _interopRequireDefault(_TxtBase);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Rect(props) {
  var oW = props.width;
  var oH = props.height;
  var oSW = props.strokeWidth;
  // 绘制边框
  if (oSW > 0) {
    oW = oW + oSW;
    oH = oH + oSW;
  }
  var rotate = {
    width: 5,
    height: 5,
    position: 'absolute',
    let: '50%',
    top: '-10px',
    background: '#def'
  };
  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: oW, height: oH, style: { position: 'absolute' } },
      (0, _preact.h)('rect', { width: '100%', height: '100%', fill: props.fill })
    ),
    (0, _preact.h)(
      'div',
      { style: rotate },
      's'
    )
  );
} /**
   * 图形 - 四边形
   * 正方形
   * 矩形
   * 菱形
   * 等腰梯形
   * 平行四边形
   * 
   * @author Ma Junbao <mlive@live.cn>
   * @deprecated 2016-12-12
   */

exports.default = Rect;

/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Rect = __webpack_require__(39);

var _Rect2 = _interopRequireDefault(_Rect);

var _roundedRectangle = __webpack_require__(50);

var _roundedRectangle2 = _interopRequireDefault(_roundedRectangle);

var _Txt = __webpack_require__(44);

var _Txt2 = _interopRequireDefault(_Txt);

var _Circle = __webpack_require__(36);

var _Circle2 = _interopRequireDefault(_Circle);

var _Triangle = __webpack_require__(43);

var _Triangle2 = _interopRequireDefault(_Triangle);

var _Pentagon = __webpack_require__(38);

var _Pentagon2 = _interopRequireDefault(_Pentagon);

var _TestLine = __webpack_require__(42);

var _TestLine2 = _interopRequireDefault(_TestLine);

var _Line = __webpack_require__(37);

var _Line2 = _interopRequireDefault(_Line);

var _rhombus = __webpack_require__(48);

var _rhombus2 = _interopRequireDefault(_rhombus);

var _oblique = __webpack_require__(47);

var _oblique2 = _interopRequireDefault(_oblique);

var _hexagon = __webpack_require__(46);

var _hexagon2 = _interopRequireDefault(_hexagon);

var _start = __webpack_require__(51);

var _start2 = _interopRequireDefault(_start);

var _trapezoid = __webpack_require__(52);

var _trapezoid2 = _interopRequireDefault(_trapezoid);

var _right = __webpack_require__(49);

var _right2 = _interopRequireDefault(_right);

var _cross = __webpack_require__(45);

var _cross2 = _interopRequireDefault(_cross);

var _Table = __webpack_require__(41);

var _Table2 = _interopRequireDefault(_Table);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

var Shape = function Shape(_ref) {
  var children = _ref.children,
      props = _objectWithoutProperties(_ref, ['children']);

  switch (props.type) {
    case 'rect':
      return (0, _preact.h)(_Rect2.default, props);
    case 'roundedRectangle':
      return (0, _preact.h)(_roundedRectangle2.default, props);
    case 'circle':
      return (0, _preact.h)(_Circle2.default, props);
    case 'triangle':
      return (0, _preact.h)(_Triangle2.default, props);
    case 'pentagon':
      return (0, _preact.h)(_Pentagon2.default, props);
    case 'rhombus':
      return (0, _preact.h)(_rhombus2.default, props);
    case 'oblique':
      return (0, _preact.h)(_oblique2.default, props);
    case 'hexagon':
      return (0, _preact.h)(_hexagon2.default, props);
    case 'start':
      return (0, _preact.h)(_start2.default, props);
    case 'trapezoid':
      return (0, _preact.h)(_trapezoid2.default, props);
    case 'right':
      return (0, _preact.h)(_right2.default, props);
    case 'cross':
      return (0, _preact.h)(_cross2.default, props);
    case 'txt':
      return (0, _preact.h)(_Txt2.default, props);
    case 'testLine':
      return (0, _preact.h)(_TestLine2.default, props);
    case 'line':
      return (0, _preact.h)(_Line2.default, props);
    case 'arrowLine':
      return (0, _preact.h)(_Line2.default, props);
    case 'dArrowLine':
      return (0, _preact.h)(_Line2.default, props);
    case 'table':
      return (0, _preact.h)(_Table2.default, props);
    default:
      return null;
  }
};

exports.default = Shape;

/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

var _TableService = __webpack_require__(17);

var _TableService2 = _interopRequireDefault(_TableService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Table = function (_Component) {
  _inherits(Table, _Component);

  function Table() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Table);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Table.__proto__ || Object.getPrototypeOf(Table)).call.apply(_ref, [this].concat(args))), _this), _this.init = function () {
      /*var eleId = this.props.id;
      var txtEle = $('#eleId').children(".txt_AreaText");
      txtEle[0].style.height = 'auto';
      txtEle[0].crollTop = 0; 
      txtEle.css('width',this.props.tw);
      //txtEle.css('height',this.props.th);
      txtEle.css('height', txtEle[0].scrollHeight + 'px');*/
      _TableService2.default.createTableByStoreData(_this.props);
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Table, [{
    key: 'componentDidMount',

    //初始执行函数
    value: function componentDidMount() {
      setTimeout(this.init, 0);
    }
  }, {
    key: 'componentDidUpdate',
    value: function componentDidUpdate() {
      setTimeout(this.init, 0);
    }
  }, {
    key: 'render',
    value: function render(props) {
      return (0, _preact.h)(
        _Transform2.default,
        props,
        (0, _preact.h)('table', { 'class': 'tableView', id: props.id + "table", style: { width: props.width, height: props.height } })
      );
    }
  }]);

  return Table;
}(_preact.Component);

exports.default = Table;

/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Circle = function (_Component) {
  _inherits(Circle, _Component);

  function Circle() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Circle);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Circle.__proto__ || Object.getPrototypeOf(Circle)).call.apply(_ref, [this].concat(args))), _this), _this.state = {
      _x1: 0,
      _y1: _this.props.height - 2,
      _x2: _this.props.width,
      _y2: 0 + 2,
      _resizePoints: 'bottomLeft topRight'
    }, _this.handleResize = function (data) {
      console.log(data);
      if (data.mx < 0 && data.mx + _this._w < 0) {
        _this.setState({
          _x1: 0,
          _y1: 0,
          _x2: _this.props.width,
          _y2: _this.props.height,
          _resizePoints: 'topLeft bottomRight'
        });
      } else if (data.my > 0 && data.my - _this._h > 0) {
        _this.setState({
          _x1: 0,
          _y1: 0,
          _x2: _this.props.width,
          _y2: _this.props.height,
          _resizePoints: 'topLeft bottomRight'
        });
      } else {
        _this.setState({
          _x1: 0,
          _y1: _this.props.height - 2,
          _x2: _this.props.width,
          _y2: 0 + 2,
          _resizePoints: 'bottomLeft topRight'
        });
      }
    }, _this.handleResizeStart = function (data) {
      _this._w = _this.props.width;
      _this._h = _this.props.height;
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Circle, [{
    key: 'render',
    value: function render(props, state) {
      return (0, _preact.h)(
        _Transform2.default,
        _extends({}, this.props, { resizePoints: state._resizePoints, hideResizeStroke: 'true', onResizeStart: this.handleResizeStart, onResize: this.handleResize }),
        (0, _preact.h)(
          'svg',
          { width: this.props.width, height: this.props.height, style: { position: 'absolute' } },
          (0, _preact.h)('line', { x1: state._x1, y1: state._y1, x2: state._x2, y2: state._y2, stroke: '#ddd', 'stroke-width': this.props.strokeWidth })
        )
      );
    }
  }]);

  return Circle;
}(_preact.Component);

exports.default = Circle;

/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Triangle(props) {
  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: props.width, height: props.height, style: { position: 'absolute' } },
      (0, _preact.h)('polygon', { points: props.width / 2 + ',0 ' + props.width + ',' + props.height + ' 0,' + props.height, fill: props.fill })
    )
  );
}

exports.default = Triangle;

/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

var _TxtService = __webpack_require__(10);

var _TxtService2 = _interopRequireDefault(_TxtService);

var _CpRundata = __webpack_require__(13);

var _CpRundata2 = _interopRequireDefault(_CpRundata);

var _TxtBase = __webpack_require__(18);

var _TxtBase2 = _interopRequireDefault(_TxtBase);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Txt = function (_Component) {
  _inherits(Txt, _Component);

  function Txt() {
    _classCallCheck(this, Txt);

    return _possibleConstructorReturn(this, (Txt.__proto__ || Object.getPrototypeOf(Txt)).apply(this, arguments));
  }

  _createClass(Txt, [{
    key: 'componentDidMount',


    //this.props //获取当前传递过来的数据

    //初始执行函数
    value: function componentDidMount() {}
    //setTimeout(this.init, 0)


    /*init = () => {
      var eleId = this.props.id;
    var parentDivEle = $('#'+eleId);
     //边框没有计算在内
    //currTxtAreaEle.css('width', this.props.width + 'px');
    //currTxtAreaEle.css('height', this.props.height + 'px');
     parentDivEle[0].style.width =  this.props.width + 'px';
    parentDivEle[0].style.height =  this.props.height + 'px';
    }
     getEvetTarget = (event) => {
     return event.srcElement ? event.srcElement : event.target;
    }
     oninput = (event) => {
     //console.log("come  in"+CpConst.txt_help_width);
     event.preventDefault(); //阻止事件
     event.stopPropagation();
     var currTxtAreaEle = $(this.getEvetTarget(event));
     var paretEle = currTxtAreaEle.parent();
     TxtService.setTxtSize(currTxtAreaEle, paretEle);
    }
    onmousemove = (event) => {
       //event.preventDefault(); //阻止事件
     event.stopPropagation();
    }
    onmouseDown= (event) => {
     event.stopPropagation();
     CpRundata.txtDownByMove=true;
     this.props.onSelectCanvas(this.props.id);
     CpRundata.shapeOriginalData = [];
     let tempData = this.props.getCanvasBySelected();
     for(let i in tempData) {
       CpRundata.shapeOriginalData.push({...tempData[i]});
     }
    }
    onmouseUp= (event) => {
     CpRundata.txtDownByMove=false;
    }*/

  }, {
    key: 'render',
    value: function render() {
      return (

        /*<DragCore onDrag = { this.onDrag }
          onDragStart = { this.onDragStart } >
           <div id = { this.props.id} className = "txt_Div"
               style = {{ left: this.props.x, top: this.props.y, position: 'absolute' } } >
              <textarea rows = "1" class = "txt_AreaText" style = {{ fontWeight: this.props.fontWeight } }
                onInput = { this.oninput } onMouseMove = { this.onmousemove } >
              </textarea>
           </div>
        </DragCore>
          <div id = { this.props.id} className = "txt_Div" onMouseUp= { this.onmouseUp}>
              <textarea   contenteditable="true" class = "txt_AreaText" style = {{ fontWeight: this.props.fontWeight } }
                onInput = { this.oninput } onMouseMove = { this.onmousemove } onMouseDown= { this.onmouseDown } onMouseUp= { this.onmouseUp } >
              </textarea>
           </div>
           */
        (0, _preact.h)(
          _Transform2.default,
          this.props,
          (0, _preact.h)(_TxtBase2.default, this.props)
        )
      );
    }
  }]);

  return Txt;
}(_preact.Component);

exports.default = Txt;

/***/ }),
/* 45 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Cross(props) {
  var blank = 1 / 6; // 四周留白

  var ow = props.width;
  var oh = props.height;
  var blankX = blank * ow;
  var blankY = blank * oh;
  var x1 = blankX;
  var y1 = blankY;
  var x2 = props.width - blankX;
  var y2 = props.height - blankY;

  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: props.width, height: props.height, style: { position: 'absolute' } },
      (0, _preact.h)('path', { d: 'M' + x1 + ',' + y1 + ' L' + x2 + ',' + y2 + ' M' + x2 + ',' + y1 + ' L' + x1 + ',' + y2, stroke: props.stroke, 'stroke-width': props.strokeWidth })
    )
  );
}

exports.default = Cross;

/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Hexagon(props) {
  var ow = 0; //边宽
  var oxa = 0; // x轴a坐标
  var oxb = 0; // x轴b坐标
  var oxw = props.width; // 已知x值
  ow = oxw / 2; //根据勾股定理和已知等三角形高算出边长是已知x值的一半
  oxa = oxw / 4; //根据勾股定理和已知等三角形高
  oxb = (oxw - ow) / 2 + ow; //根据勾股定理和已知等三角形高
  var oxy = props.height; // 已知y值
  var oy1 = Math.sqrt(3) / 2;
  var oy2 = Math.sqrt(3) / 4;
  var oya = oxy * oy1; // y轴a坐标
  var oyb = oxy * oy2; // y轴a坐标
  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: props.width, height: props.height, style: { position: 'absolute' } },
      (0, _preact.h)('polygon', { points: oxa + ',0 ' + oxb + ',0 ' + props.width + ',' + oyb + ' ' + oxb + ',' + oya + ' ' + oxa + ',' + oya + ' 0 ,' + oyb, fill: props.fill })
    )
  );
}

exports.default = Hexagon;

/***/ }),
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Oblique(props) {
  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: props.width, height: props.height, style: { position: 'absolute' } },
      (0, _preact.h)('polygon', { points: props.width * 0.25 + ',0 ' + props.width + ',0 ' + props.width * 0.75 + ',' + props.height + ' 0,' + props.height, fill: props.fill })
    )
  );
}

exports.default = Oblique;

/***/ }),
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Rhombus(props) {
  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: props.width, height: props.height, style: { position: 'absolute' } },
      (0, _preact.h)('polygon', { points: props.width / 2 + ',0 ' + props.width + ',' + props.height / 2 + ' ' + props.width / 2 + ',' + props.height + ' 0,' + props.height / 2, fill: props.fill })
    )
  );
}

exports.default = Rhombus;

/***/ }),
/* 49 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Right(props) {
  var ow = props.width;
  var oh = props.height;
  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: props.width, height: props.height, style: { position: 'absolute' } },
      (0, _preact.h)('path', { d: 'M' + ow * 0.08 + ',' + oh * 0.6 + ' L' + ow * 0.4 + ',' + oh * 0.83 + ' L' + ow * 0.9 + ',' + oh / 6, stroke: props.stroke, 'stroke-width': props.strokeWidth, fill: 'none' })
    )
  );
}

exports.default = Right;

/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function RoundedRectangle(props) {
  var oW = props.width;
  var oH = props.height;
  var oSW = props.strokeWidth;
  // 绘制边框
  if (oSW > 0) {
    oW = oW + oSW;
    oH = oH + oSW;
  }
  var rotate = {
    width: 5,
    height: 5,
    position: 'absolute',
    let: '50%',
    top: '-10px',
    background: '#def'
  };
  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: oW, height: oH, style: { position: 'absolute' } },
      (0, _preact.h)('rect', { width: '100%', height: '100%', rx: '50', fill: props.fill })
    ),
    (0, _preact.h)(
      'div',
      { style: rotate },
      's'
    )
  );
}

exports.default = RoundedRectangle;

/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Start(props) {

  var oxw = props.width; //x轴坐标
  var oyh = props.height; //y轴坐标
  var radians18 = 18 * Math.PI / 180;
  var radians36 = 36 * Math.PI / 180;
  var radians54 = 54 * Math.PI / 180;
  var ow = oxw / (2 * Math.cos(radians36)); //边长
  var M = ow / 2 / Math.cos(radians36);
  var x1 = oxw / 2;
  var x2 = oxw - ow / 2 / Math.cos(radians36);
  var x3 = M / Math.cos(radians18);
  var x4 = oxw - M / Math.sin(radians54);
  var x5 = oxw - 2 * M / Math.cos(radians36) / 2;
  var x6 = oxw / 2;
  var x7 = 2 * M / (Math.cos(radians36) / 2);
  var x8 = M / Math.cos(radians36);
  var x9 = 0;
  var x10 = ow / 2 / Math.cos(radians36);
  var y1 = 0;
  var y2 = M / Math.cos(radians18);
  var y3 = M / Math.cos(radians18);
  var y4 = M / Math.sin(radians36) + M / Math.cos(radians18);
  var y5 = oyh;
  var y6 = oyh - M / Math.sin(radians36);
  var y7 = oyh;
  var y8 = M / Math.sin(radians36) + M / Math.cos(radians18);
  var y9 = M / Math.cos(radians18);
  var y10 = 0;

  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: props.width, height: props.height, style: { position: 'absolute' } },
      (0, _preact.h)('polygon', { points: 'x1,y1 x2,y2 x3,y3 x4,y4 x5,y5 x6,y6 x7,y7 x8,y8 x9,y9 x10,y10', fill: props.fill })
    )
  );
}

exports.default = Start;

/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _Transform = __webpack_require__(1);

var _Transform2 = _interopRequireDefault(_Transform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function Trapezoid(props) {
  var oxw = props.width; // 已知x值
  var om = props.width / 4; //变量边长
  var oxa = 0; // x轴a坐标
  var oxb = 0; // x轴b坐标
  var oy = props.height; //已知y值
  oxa = om;
  oxb = oxw - om;
  return (0, _preact.h)(
    _Transform2.default,
    props,
    (0, _preact.h)(
      'svg',
      { width: props.width, height: props.height, style: { position: 'absolute' } },
      (0, _preact.h)('polygon', { points: oxa + ',0 ' + oxb + ',0 ' + oxw + ',' + oy + ' 0,' + oy, fill: props.fill })
    )
  );
}

exports.default = Trapezoid;

/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _preact = __webpack_require__(0);

var _Shape = __webpack_require__(40);

var _Shape2 = _interopRequireDefault(_Shape);

var _Marquee = __webpack_require__(54);

var _Marquee2 = _interopRequireDefault(_Marquee);

var _EditAreaPageService = __webpack_require__(11);

var _EditAreaPageService2 = _interopRequireDefault(_EditAreaPageService);

var _NavPageService = __webpack_require__(7);

var _NavPageService2 = _interopRequireDefault(_NavPageService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var EditAreaPage = function (_Component) {
  _inherits(EditAreaPage, _Component);

  function EditAreaPage() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, EditAreaPage);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = EditAreaPage.__proto__ || Object.getPrototypeOf(EditAreaPage)).call.apply(_ref, [this].concat(args))), _this), _this.canvasStyle = {
      width: _this.props.layout.editAreaWidth,
      height: _this.props.layout.editAreaHeight,
      top: '50%',
      left: '50%',
      overflow: 'visible',
      background: '#fff',
      marginLeft: _this.props.layout.editAreaWidth / -2,
      marginTop: _this.props.layout.editAreaHeight / -2,
      cursor: _this.props.layout.editAreaCursor,
      transform: 'scale(' + _this.props.layout.scale + ')',
      transition: 'transform 0.3s'
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(EditAreaPage, [{
    key: 'componentDidUpdate',
    value: function componentDidUpdate() {
      // try {
      //   html2canvas($('.edit-area-canvas')[0], {
      //     onrendered: function(canvas) {
      //       var url = canvas.toDataURL();
      //       NavPageService.setUrlCurrOperSel(url);
      //     }
      //   });
      // } catch (e) {
      //    alert('生成导航面板信息异常:'+e);
      // }
    }
  }, {
    key: 'render',
    value: function render(props, state) {
      return (0, _preact.h)(
        'div',
        { id: 'mainEditArea', className: 'edit-area-page' },
        (0, _preact.h)(
          'div',
          { className: 'cp-view edit-area-canvas', style: this.canvasStyle },
          Object.keys(props.canvas).map(function (item) {
            return (0, _preact.h)(_Shape2.default, _extends({}, props, props.canvas[item]));
          })
        ),
        (0, _preact.h)(
          'div',
          { className: 'add-table-popup' },
          (0, _preact.h)(
            'div',
            { className: 'head-info' },
            '\u63D2\u5165\u8868\u683C'
          ),
          (0, _preact.h)(
            'div',
            { className: 'td-line-info' },
            (0, _preact.h)(
              'span',
              { className: 'count-info' },
              '\u884C\u6570:',
              (0, _preact.h)('input', { type: 'text', className: 'input-txt', value: '3' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'table-count' },
              (0, _preact.h)('i', { className: 'table-count-icon' }),
              (0, _preact.h)('i', { className: 'table-count-icon  table-count-plus' })
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'td-line-info' },
            (0, _preact.h)(
              'span',
              { className: 'count-info' },
              ' \u5217\u6570:',
              (0, _preact.h)('input', { type: 'text', className: 'input-txt', value: '3' })
            ),
            (0, _preact.h)(
              'span',
              { className: 'table-count' },
              (0, _preact.h)('i', { className: 'table-count-icon' }),
              (0, _preact.h)('i', { className: 'table-count-icon  table-count-plus' })
            )
          ),
          (0, _preact.h)(
            'div',
            { className: 'td-line-info' },
            (0, _preact.h)(
              'a',
              { className: 'button-txt' },
              '\u53D6\u6D88'
            ),
            (0, _preact.h)(
              'a',
              { className: 'button-txt' },
              '\u63D2\u5165 '
            )
          )
        )
      );
    }
  }]);

  return EditAreaPage;
}(_preact.Component);

// function EditAreaPage(props) {
//   let canvasStyle = {
//     width: props.layout.editAreaWidth,
//     height: props.layout.editAreaHeight,
//     top: '50%',
//     left: '50%',
//     overflow: 'visible',
//     background: '#fff',
//     marginLeft: props.layout.editAreaWidth / -2,
//     marginTop: props.layout.editAreaHeight / -2,
//     cursor: props.layout.editAreaCursor,
//     transform: `scale(${props.layout.scale})`
//   }

//   return (
//     <Marquee {...props}>
//       <div id='mainEditArea' className="edit-area-page">
//         <div className="cp-view edit-area-canvas" style={canvasStyle}>
//           {
//             Object.keys(props.canvas).map((item) => {
//               return <Shape {...props} {...props.canvas[item]} />
//             })
//           }
//         </div>

//           <div className="add-table-popup">
//             <div className="head-info">插入表格</div>
//             <div className="td-line-info">
//               <span className="count-info">行数:<input type="text" className="input-txt" value="3"/></span>
//               <span className="table-count">
//                 <i className="table-count-icon"></i>
//                 <i className="table-count-icon  table-count-plus"></i>
//               </span>
//             </div>
//             <div className="td-line-info">
//               <span className="count-info"> 列数:<input type="text" className="input-txt" value="3"/></span>
//               <span className="table-count">
//                 <i className="table-count-icon"></i>
//                 <i className="table-count-icon  table-count-plus"></i>
//               </span>
//             </div>
//              <div className="td-line-info">
//               <a className="button-txt">取消</a>
//               <a className="button-txt">插入 </a>
//             </div>
//          </div>
//       </div>
//     </Marquee>
//   )
// }

exports.default = EditAreaPage;

/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = Marquee;

var _preact = __webpack_require__(0);

var _DragCore = __webpack_require__(5);

var _DragCore2 = _interopRequireDefault(_DragCore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 选取框
function Marquee(props) {
  var style = {
    backgroundColor: 'rgba(0,0,0,0.2)',
    position: 'absolute'
  };

  var width = void 0,
      height = void 0,
      x = void 0,
      y = void 0; // 选框的值
  var marqueeRect = {
    x: 0,
    y: 0,
    width: 0,
    height: 0
  };

  var _deviationScale = function _deviationScale(data) {
    if (props.layout.scale !== 1) {
      data.w = data.w / props.layout.scale;
      data.h = data.h / props.layout.scale;
      data.x = data.x / props.layout.scale;
      data.y = data.y / props.layout.scale;
    }
  };

  // 取消选中
  var cancelSelected = function cancelSelected(data) {
    data.event.which == 1 && props.onCancelSelected();
  };

  // 绘制框选开始
  var marqueeStart = function marqueeStart(data) {
    cancelSelected(data);
    width = 0;
    height = 0;
    x = data.x - props.layout.left;
    y = data.y - props.layout.top;
  };

  // 绘制框选
  var marquee = function marquee(data) {
    var marqueeRect = {};
    marqueeRect.x = Math.min(data.x - props.layout.left, x);
    marqueeRect.y = Math.min(data.y - props.layout.top, y);
    marqueeRect.w = Math.abs(data.x - props.layout.left - x);
    marqueeRect.h = Math.abs(data.y - props.layout.top - y);

    props.onUpdataMarquee({ x: marqueeRect.x, y: marqueeRect.y, width: marqueeRect.w, height: marqueeRect.h });

    // 修正缩放偏移量
    _deviationScale(marqueeRect);

    props.onSelectCanvasByRect({ x: data.canvasX, y: data.canvasY, width: marqueeRect.w, height: marqueeRect.h });
  };

  // 绘制框选结束
  var marqueeStop = function marqueeStop(data) {
    props.onUpdataMarquee({ x: 0, y: 0, width: 0, height: 0 });
  };

  return (0, _preact.h)(
    _DragCore2.default,
    { onDragStart: marqueeStart, onDrag: marquee, onDragStop: marqueeStop },
    (0, _preact.h)(
      'div',
      { style: { height: '100%' } },
      props.children,
      (0, _preact.h)('div', { style: _extends({}, style, { width: props.marquee.width, height: props.marquee.height, left: props.marquee.x, top: props.marquee.y }) })
    )
  );
}

/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _preact = __webpack_require__(0);

var _HeaderPageGroup = __webpack_require__(57);

var _HeaderPageGroup2 = _interopRequireDefault(_HeaderPageGroup);

var _HeaderPageButton = __webpack_require__(56);

var _HeaderPageButton2 = _interopRequireDefault(_HeaderPageButton);

var _HeaderPageSelect = __webpack_require__(58);

var _HeaderPageSelect2 = _interopRequireDefault(_HeaderPageSelect);

var _HeaderPageTool = __webpack_require__(61);

var _HeaderPageTool2 = _interopRequireDefault(_HeaderPageTool);

var _HeaderPageService = __webpack_require__(6);

var _HeaderPageService2 = _interopRequireDefault(_HeaderPageService);

var _HeaderPageShapePopUp = __webpack_require__(59);

var _HeaderPageShapePopUp2 = _interopRequireDefault(_HeaderPageShapePopUp);

var _HeaderPageTablePopUp = __webpack_require__(60);

var _HeaderPageTablePopUp2 = _interopRequireDefault(_HeaderPageTablePopUp);

var _EditAreaPageService = __webpack_require__(11);

var _EditAreaPageService2 = _interopRequireDefault(_EditAreaPageService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function HeaderPage(props) {
  var testAdd = function testAdd(e) {
    var ele = e.target.value;
    switch (ele) {
      case '1':
        _EditAreaPageService2.default.addEle('testLine');
        break;
      default:

    }
  };

  return (0, _preact.h)(
    'div',
    { className: 'header-page' },
    (0, _preact.h)(
      _HeaderPageGroup2.default,
      null,
      (0, _preact.h)(_HeaderPageButton2.default, { icon: 'save', text: '\u4FDD\u5B58' }),
      (0, _preact.h)(_HeaderPageButton2.default, { icon: 'export', text: '\u5BFC\u51FA' }),
      (0, _preact.h)(_HeaderPageSelect2.default, _extends({}, props, { text: '\u7F29\u653E' })),
      (0, _preact.h)(_HeaderPageButton2.default, { icon: 'preview', text: '\u9884\u89C8' }),
      (0, _preact.h)(_HeaderPageButton2.default, { icon: 'preview', text: '\u4F8B\u5B50', onClick: function onClick() {
          _EditAreaPageService2.default.demo();
        } })
    ),
    " ",
    (0, _preact.h)(
      _HeaderPageGroup2.default,
      null,
      (0, _preact.h)(_HeaderPageTool2.default, { icon: 'text', text: '\u6587\u5B57', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('txt');
        } }),
      (0, _preact.h)(_HeaderPageTool2.default, { icon: 'shape', text: '\u5F62\u72B6', onClick: _HeaderPageService2.default.shapeIconClick }),
      (0, _preact.h)(_HeaderPageShapePopUp2.default, null),
      (0, _preact.h)(_HeaderPageTool2.default, { icon: 'table', text: '\u8868\u683C', onClick: _HeaderPageService2.default.tableIconClick }),
      (0, _preact.h)(_HeaderPageTablePopUp2.default, null),
      (0, _preact.h)(_HeaderPageTool2.default, { icon: 'template', text: '\u6559\u5B66\u6A21\u7248' }),
      (0, _preact.h)(_HeaderPageTool2.default, { icon: 'study', text: '\u6559\u5B66\u6A21\u7248' }),
      (0, _preact.h)(_HeaderPageTool2.default, { icon: 'test', text: '\u4E92\u52A8\u8BD5\u9898' }),
      (0, _preact.h)(_HeaderPageTool2.default, { icon: 'file', text: '\u63D2\u5165\u6587\u4EF6' }),
      (0, _preact.h)(_HeaderPageTool2.default, { icon: 'resource', text: '\u8C03\u7528\u8D44\u6E90' })
    ),
    " ",
    (0, _preact.h)(
      _HeaderPageGroup2.default,
      null,
      (0, _preact.h)(_HeaderPageButton2.default, { icon: 'style', text: '\u683C\u5F0F' }),
      (0, _preact.h)(_HeaderPageButton2.default, { icon: 'doc', text: '\u6587\u7A3F' })
    )
  );
}

exports.default = HeaderPage;

/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (props) {
  return (0, _preact.h)(
    'div',
    { onClick: props.onClick, className: 'header-page-button' },
    (0, _preact.h)('a', { className: 'header-page-button-icon-' + props.icon }),
    (0, _preact.h)(
      'span',
      { className: 'header-page-button-text' },
      props.text
    )
  );
};

var _preact = __webpack_require__(0);

;

/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (props) {
  return (0, _preact.h)(
    "div",
    { className: "header-page-group" },
    props.children
  );
};

var _preact = __webpack_require__(0);

;

/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (props) {
  var setEditAreaScale = function setEditAreaScale(e) {
    var scale = e.target.value || '100';
    switch (scale) {
      case 'auto':
        break;
      case '25':
      case '50':
      case '25':
      case '75':
      case '100':
      case '125':
      case '150':
      case '200':
        props.onUpdataLayout({
          'scale': parseFloat(scale / 100)
        });
        break;
    }
  };

  return (0, _preact.h)(
    'div',
    { className: 'header-page-button' },
    (0, _preact.h)(
      'select',
      { onChange: setEditAreaScale },
      (0, _preact.h)(
        'option',
        { value: 'auto' },
        'auto'
      ),
      (0, _preact.h)(
        'option',
        { value: '25' },
        '25%'
      ),
      (0, _preact.h)(
        'option',
        { value: '50' },
        '50%'
      ),
      (0, _preact.h)(
        'option',
        { value: '75' },
        '75%'
      ),
      (0, _preact.h)(
        'option',
        { value: '100', selected: true },
        '100%'
      ),
      (0, _preact.h)(
        'option',
        { value: '125' },
        '125%'
      ),
      (0, _preact.h)(
        'option',
        { value: '150' },
        '150%'
      ),
      (0, _preact.h)(
        'option',
        { value: '200' },
        '200%'
      )
    ),
    (0, _preact.h)(
      'span',
      { className: 'header-page-button-text' },
      props.text
    )
  );
};

var _preact = __webpack_require__(0);

;

/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (props) {

  return (0, _preact.h)(
    'div',
    { className: 'header-page-popup hidden', id: 'shapePopUpDiv', onclick: _HeaderPageService2.default.changeClickFlag },
    (0, _preact.h)('span', { className: 'popup-point' }),
    (0, _preact.h)(
      'div',
      { className: 'header-popup-text' },
      '\u7EBF\u6761'
    ),
    (0, _preact.h)(
      'div',
      { className: 'header-popup-icon' },
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-line' }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-arrow' }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-double-arrow' }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-curve' })
    ),
    (0, _preact.h)(
      'div',
      { className: 'header-popup-text' },
      '\u56FE\u5F62'
    ),
    (0, _preact.h)(
      'div',
      { className: 'header-popup-icon' },
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-square1', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('rect');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-square2', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('roundedRectangle');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-square3', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('circle');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-square4' }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-square5', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('triangle');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-square6' })
    ),
    (0, _preact.h)(
      'div',
      { className: 'header-popup-text' },
      '\u63D0\u793A\u7EC4\u4EF6'
    ),
    (0, _preact.h)(
      'div',
      { className: 'header-popup-icon' },
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-hint1' }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-hint2' })
    ),
    (0, _preact.h)(
      'div',
      { className: 'header-popup-text' },
      '\u5176\u5B83'
    ),
    (0, _preact.h)(
      'div',
      { className: 'header-popup-icon' },
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-other1', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('rhombus');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-other2', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('hexagon');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-other3', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('pentagon');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-other4', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('oblique');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-other5', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('trapezoid');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-other6', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('start');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-other7', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('right');
        } }),
      (0, _preact.h)('span', { className: 'header-popup-tool-icon header-popup-icon-other8', onClick: function onClick() {
          _EditAreaPageService2.default.addEle('cross');
        } })
    )
  );
};

var _preact = __webpack_require__(0);

var _EditAreaPageService = __webpack_require__(11);

var _EditAreaPageService2 = _interopRequireDefault(_EditAreaPageService);

var _HeaderPageService = __webpack_require__(6);

var _HeaderPageService2 = _interopRequireDefault(_HeaderPageService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;

/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (props) {
  var create100Span = function create100Span() {
    var span = [];
    for (var i = 0; i < 90; i++) {
      span.push((0, _preact.h)('span', { className: 'header-table-icon', onmouseleave: _HeaderPageService2.default.tablePopUpMouseOut, onmouseover: _HeaderPageService2.default.tablePopUponMouseover, onClick: _HeaderPageService2.default.tablePopUponTdClick }));
    };
    return span;
  };
  return (0, _preact.h)(
    'div',
    { className: 'header-page-popup hidden', id: 'tablePopUp', onmouseleave: _HeaderPageService2.default.tablePopUpMouseOut, onclick: _HeaderPageService2.default.changeClickFlag },
    (0, _preact.h)('span', { className: 'popup-point' }),
    (0, _preact.h)(
      'div',
      { className: 'header-table-text', id: 'heeaderTableText' },
      '0*0\u8868\u683C'
    ),
    (0, _preact.h)(
      'div',
      { className: 'header-table', id: 'tablePopUpSpan', onmouseleave: _HeaderPageService2.default.tablePopUpMouseOut },
      create100Span()
    ),
    (0, _preact.h)(
      'div',
      { className: 'header-table-add' },
      (0, _preact.h)(
        'span',
        { className: 'header-table-add-icon' },
        '\u63D2\u5165\u8868\u683C...'
      )
    )
  );
};

var _preact = __webpack_require__(0);

var _HeaderPageService = __webpack_require__(6);

var _HeaderPageService2 = _interopRequireDefault(_HeaderPageService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;

/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (props) {
  return (0, _preact.h)(
    'div',
    { onClick: props.onClick, className: 'header-page-tool' },
    (0, _preact.h)('a', { className: 'header-page-tool-icon-' + props.icon }),
    (0, _preact.h)(
      'span',
      { className: 'header-page-tool-text' },
      props.text
    )
  );
};

var _preact = __webpack_require__(0);

;

/***/ }),
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _preact = __webpack_require__(0);

var _NavPageService = __webpack_require__(7);

var _NavPageService2 = _interopRequireDefault(_NavPageService);

var _NavPageChildEle = __webpack_require__(63);

var _NavPageChildEle2 = _interopRequireDefault(_NavPageChildEle);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

//导航面板布局类
var NavPage = function (_Component) {
  _inherits(NavPage, _Component);

  function NavPage() {
    _classCallCheck(this, NavPage);

    return _possibleConstructorReturn(this, (NavPage.__proto__ || Object.getPrototypeOf(NavPage)).apply(this, arguments));
  }

  _createClass(NavPage, [{
    key: 'componentDidMount',
    value: function componentDidMount() {
      setTimeout(_NavPageService2.default.init, 0);
    }
  }, {
    key: 'render',
    value: function render(props, state) {
      return (0, _preact.h)(
        'div',
        { id: 'leftDiv', className: 'nav-page', onClick: _NavPageService2.default.navPageClick },
        (0, _preact.h)(
          'div',
          { id: 'leftMainDiv', onmousemove: _NavPageService2.default.navPageElemousemove, onmouseup: _NavPageService2.default.leftMainDivmouseUp },
          Object.keys(props.navePageList).map(function (item) {
            return (0, _preact.h)(_NavPageChildEle2.default, _extends({}, props, props.navePageList[item]));
          })
        )
      );
    }
  }]);

  return NavPage;
}(_preact.Component);

exports.default = NavPage;

/***/ }),
/* 63 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _preact = __webpack_require__(0);

var _NavPageService = __webpack_require__(7);

var _NavPageService2 = _interopRequireDefault(_NavPageService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function NavPageChildEle(props) {

  function eleoncontextmenu(event) {

    event.preventDefault(); //阻止事件
    _NavPageService2.default.navPageRClick(event);
  }

  return (0, _preact.h)(
    'div',
    { id: props.id, seq: props.seq, className: props.className, onContextMenu: eleoncontextmenu,
      onClick: _NavPageService2.default.navPageEleClick, onMouseDown: _NavPageService2.default.navPageElemousedown,
      onMouseUp: _NavPageService2.default.navPageElemouseup },
    (0, _preact.h)(
      'div',
      { className: 'navPageLeft' },
      props.seq
    ),
    (0, _preact.h)(
      'div',
      { className: 'navPageContent' },
      (0, _preact.h)('img', { src: props.url })
    )
  );
}

exports.default = NavPageChildEle;

/***/ }),
/* 64 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _preact = __webpack_require__(0);

var _MainView = __webpack_require__(19);

var _MainView2 = _interopRequireDefault(_MainView);

__webpack_require__(21);

__webpack_require__(22);

var _Marquee = __webpack_require__(20);

var _Marquee2 = _interopRequireDefault(_Marquee);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

setTimeout(function () {
  new _Marquee2.default();
}, 1);

(0, _preact.render)((0, _preact.h)(_MainView2.default, null), document.body);

/***/ })
/******/ ]);