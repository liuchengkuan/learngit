# ppt

# Watch

Instead of manually building after each change it's possible to automatically recompile the javascript bundle when files change:

```bash
npm start
# open http://localhost:8080 in your browser
# change some file will automatically refresh
```

# Build

```bash
npm run build
# open dist/index.html
```

